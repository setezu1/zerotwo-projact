# Zero Two AI — v14 Changelog

This release upgrades the dashboard UI with the IRIS-style features you
requested, while leaving the entire AI backend (main.py, ai_router.py,
agent/, actions/, memory/, godmode_agent.py, etc.) completely untouched.

Only `ui.py` was changed. Everything else is byte-for-byte identical to v13.

## New Features

### 1. Animated chat — typing indicator + streaming text
- A three-dot "typing..." animation now appears in the transcript while
  Zero Two is thinking, and disappears automatically when a reply arrives
  or the state changes back to LISTENING/SLEEP/MUTED.
- New public method `ZERO_TWOUI.stream_response(text)` reveals an AI
  message character-by-character with a blinking cursor, then renders the
  final message with full markdown formatting. Call this instead of
  `write_log("Zero_Two: ...")` anywhere you want the typing-out effect.

### 2. Markdown rendering in AI bubbles
AI chat bubbles now render:
- `# `, `## `, `### ` headers (in different accent colors)
- `**bold**` and `*italic*`
- `` `inline code` `` with a dark code-style background
- ` ```fenced code blocks``` ` as a styled <pre> block
- `- ` / `* ` bullet lists with a green `>` marker

User bubbles remain plain text (no markdown parsing) for safety/clarity.

### 3. Auto-scroll + "scroll to latest" button
- The transcript auto-scrolls to the newest message as long as you're
  already at the bottom.
- If you scroll up to read history, auto-scroll pauses and a small
  "v Scroll to latest" button appears at the bottom of the panel —
  click it to jump back down and resume auto-scroll.

### 4. Command Palette (Ctrl+K)
- Press **Ctrl+K** anywhere in the app to open a Spotlight-style command
  palette.
- Shows your 5 most recent typed commands at the top (when search is empty).
- Includes ~17 built-in quick actions (status check, switch AI provider,
  open apps, weather, screen monitor toggle, GodMode query, etc.) with
  live fuzzy search.
- Type anything not in the list and hit Enter to run it as a custom
  command — it's sent straight to Zero Two exactly like typing in the
  chat box.
- Use Up/Down to navigate, Enter to run, Esc to close.
- A small "Ctrl+K" hint badge is shown in the title bar and transcript
  header so it's discoverable.

### 5. Memory Bank viewer (new MEMORY tab)
- New "MEMORY" tab in the top nav bar (between DASHBOARD and AGENTS).
- Shows every entry from `memory/long_term.json` in a live table:
  Category | Key | Value.
- Filter by category (identity, preferences, projects, relationships,
  wishes, notes, or All).
- Double-click any Value cell to edit it — changes save to
  `long_term.json` immediately.
- Select one or more rows and click "X Delete selected" to remove
  memory entries.
- "Reload" button re-reads the file from disk (useful if Zero Two's
  memory manager wrote new entries while the UI was open).

## Internal / structural changes
- All emoji and non-ASCII characters in `ui.py` were replaced with plain
  ASCII equivalents for maximum compatibility across terminals/fonts on
  Windows, macOS, and Linux. Visual style is unchanged — same dark
  green-on-black IRIS aesthetic, same layout, same widgets.
- `TranscriptWidget` was rewritten internally to support the typing
  indicator, streaming reveal, and auto-scroll tracking, but its public
  surface (`append_log`, `start_typing`, `stop_typing`) is unchanged so
  `main.py` needs zero modifications.
- `ZERO_TWOUI` gained one new method: `stream_response(text)`. All other
  methods (`write_log`, `set_state`, `update_agent`, `on_text_command`,
  `muted`, `current_file`, `wait_for_api_key`, `start_speaking`,
  `stop_speaking`) are unchanged and fully backward compatible.
- `SettingsPanel` is now wrapped in a scroll area so all options remain
  reachable even on smaller window sizes.

## Verified
- `ui.py` compiles cleanly (`python3 -m py_compile`).
- Imports cleanly with the exact statement `main.py` uses:
  `from ui import ZERO_TWOUI, load_settings, save_settings, ZERO_TWO_VOICE`.
- `MainWindow` and `ZERO_TWOUI` both construct successfully under
  `QT_QPA_PLATFORM=offscreen`.
- Markdown renderer, Memory Viewer (load/filter/edit/persist), Command
  Palette (recent history + fuzzy search + custom run), and the chat
  typing/streaming pipeline were all individually exercised and confirmed
  working.

## Not changed
- main.py, ai_router.py, api_manager.py, agent/*, actions/*, memory/*,
  godmode_agent.py, emotion_agent.py, system_monitor.py, wake_word.py,
  vosk_setup.py, autostart.py, confirm_dialog.py, core/*, config/*,
  setup.py, requirements.txt — all identical to v13.

---

# Zero Two AI — v14.1 Additions

This follow-up patch builds on v14 above. Four files changed this round:
`ui.py`, `wake_word.py`, `main.py`, `system_monitor.py`.

## 1. Wake word -- confirmed intact + "Hello Zero Two"
The v14 UI rewrite never touched the wake-word backend; it was already
fully wired in `wake_word.py` / `main.py` and untouched. `_WAKE_PHRASES`
already included "hello zero two", "hey zero two", "zero two", and
"wake up zero two" -- say any of these to activate. The Settings checkbox
now reads **"Wake word enabled (\"Hello Zero Two\")"** so this is explicit
in the UI.

## 2. Clap-to-activate (double clap)
New `ClapDetector` class in `wake_word.py`:
- Runs its own lightweight mic stream (via `sounddevice`, already a
  dependency) independent of whichever STT backend the wake word engine
  picked -- works even on the bare "energy" fallback.
- Listens for **two sharp amplitude transients within 1.2s** (a double
  clap). Requiring two claps -- not one -- eliminates the vast majority of
  false triggers from a single bump, cough, dropped object, or door.
- Automatically pauses while Zero Two is already active, so a clap
  mid-conversation can't misfire.
- New Settings controls: **"Clap to activate (clap twice)"** checkbox +
  a **sensitivity slider** (0-100%, higher = triggers on quieter claps).
- Fully wired into `main.py`: starts/stops alongside the wake word engine,
  syncs live when settings change, and triggers the same "Yes boss, I am
  here." wake response via `_on_clap_wake()` -> `force_wake()`.

## 3. CPU temperature -- fixed "N/A" bug
Root cause: `CoreMetricsWidget._refresh()` checked `if sm:` (the
`system_monitor` snapshot object) to decide whether to use its temp value
*or* fall back to the older `_SysMetrics` probe -- but `sm` is **always
truthy** once `system_monitor` imports successfully, even when
`sm.temp == -1` (sensor read failed). So the fallback probe never ran.

Fix: now checks `sm.temp < 0` specifically and falls back to the
independent `_SysMetrics._temp()` probe (different psutil sensor-name
order) when the primary probe comes back empty.

Also broadened `system_monitor._read_temp_windows()`:
- LibreHardwareMonitor/OpenHardwareMonitor sensor-name matching now
  catches `Core`, `Package`, `Tdie`, `Tctl` in addition to `CPU` (covers
  more AMD/Intel naming conventions).
- Added a `Get-CimInstance`-based ACPI thermal-zone probe alongside the
  existing `Get-WmiObject` one (newer PowerShell prefers CIM).

## 4. Screen-share crash -- fixed
Root cause: `ScreenFeedWidget._refresh()` built a `QImage` that pointed
directly at a **local numpy array's memory buffer** (`arr.data`). Once
`_refresh()` returned, Python's garbage collector could free that buffer
at any time -- and the next `paintEvent()` would then read **freed
memory**, causing an intermittent segfault/crash. This matches "when I
screen share the app crashes" -- it wasn't deterministic because it
depended on GC timing.

Also fixed a secondary color bug: `mss` returns **BGRA** pixel data, but
the code used `Format_RGBA8888` (wrong byte order -- red/blue channels
would be swapped).

Fix:
- `np.array(img, dtype=np.uint8)` instead of `np.frombuffer(img.raw)...`
  -- this **copies** the data into an array that owns its own memory.
- `QImage.Format.Format_RGB32` instead of `Format_RGBA8888` -- correct for
  BGRA byte order on little-endian systems (which is what `mss` produces).
- `.copy()` on the resulting `QImage` before wrapping in `QPixmap` --
  fully detaches the pixmap from any temporary buffer, so it survives GC.
- Same `.copy()` fix applied to the camera-feed path (`cv2` frames had the
  identical dangling-buffer risk).
- Both paths now log a one-line error on capture failure instead of
  silently swallowing it, making future issues easier to diagnose.

Verified: repeated `_refresh()` + forced `gc.collect()` + `repaint()` no
longer crashes (tested with synthetic BGRA data matching mss's
`__array_interface__` shape).

## 5. PIN lock screen (new security feature)
New `LockScreenDialog` class in `ui.py` -- a numeric-keypad PIN screen
shown **before** the main window/AI becomes accessible.

- **Disabled by default** on a fresh install -- nothing changes unless you
  opt in.
- New **SECURITY** section in Settings: "Require PIN on startup" checkbox
  + "Set PIN" / "Change PIN" button.
- Checking the box with no PIN set forces a **setup flow**: enter a 4-digit
  PIN, then enter it again to confirm. Mismatches show an error and restart
  the flow.
- On every subsequent launch (if enabled), `ZERO_TWOUI.__init__` shows the
  lock screen via a blocking modal (`exec()`) **before** `MainWindow` is
  even constructed -- the AI/dashboard literally does not exist in memory
  until the correct PIN is entered.
- Wrong PIN: dot indicators flash red with an "x", error message shown,
  input clears, user can retry immediately (no lockout/cooldown -- this is
  a convenience lock, not a security boundary against a determined
  attacker with physical access).
- **"Forgot PIN?"** (verify mode only): opens a confirmation dialog with
  two destructive options -- "Create New PIN" (wipes old PIN, opens setup)
  or "Remove PIN Lock" (disables lock, app opens unlocked) -- or Cancel to
  return to the PIN screen unchanged. Both options require this explicit
  step, matching the standard "physical access = reset" tradeoff used by
  most consumer devices.
- **Storage**: PIN is never stored in plaintext. Hashed with
  PBKDF2-HMAC-SHA256 (200,000 iterations) + a random 16-byte per-install
  salt, stored in `config/lock.json`. Verification uses a constant-time
  comparison (`secrets.compare_digest`) to avoid timing side-channels.
- Toggling the checkbox **off** keeps the PIN hash on disk (so re-enabling
  doesn't require re-setup) but the lock is not enforced on startup.

## Verified (this round)
- All four changed files (`ui.py`, `wake_word.py`, `main.py`,
  `system_monitor.py`) compile cleanly.
- `ClapDetector`: instantiation, sensitivity scaling (0/60/100%), and
  graceful no-crash behavior when `sounddevice`/PortAudio is unavailable.
- `LockScreenDialog`: full setup flow (match + mismatch), full verify flow
  (wrong-then-right PIN in the same dialog), forgot-PIN message box (both
  destructive choices + Cancel), and the complete `ZERO_TWOUI` gate with
  lock enabled/disabled.
- Settings panel: enabling lock with no PIN forces setup; toggling
  off/on preserves the stored PIN; "Change PIN" replaces the old hash.
- `ScreenFeedWidget`: repeated refresh + forced GC + repaint with
  synthetic BGRA frames -- no crash, correct pixmap size/validity.
- CPU temp fallback chain logic confirmed (falls through to `_SysMetrics`
  probe when `system_monitor` returns -1).

## Not changed (this round)
Only `ui.py`, `wake_word.py`, `main.py`, `system_monitor.py` were edited.
Everything else (actions/, agent/, memory/, ai_router.py, api_manager.py,
godmode_agent.py, emotion_agent.py, confirm_dialog.py, core/, config/,
etc.) remains identical to v14 above / v13.
