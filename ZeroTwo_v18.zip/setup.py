"""
setup.py — Zero Two one-shot installer
======================================
Installs Python deps from requirements.txt and Playwright browsers.
Run:  python setup.py
"""
import subprocess
import sys

BANNER = r"""
 ______             ______
|__   /  ___   ___ |__  __\____      _____
  / /  / _ \ / __\    | ||  _ \ /\ /\ / _ \
 / /__|  __/| |       | || (_) |\ V /| (_) |
/_____|\___||_|       |_| \___/  \_/  \___/

         Z E R O   T W O   ·   AI ASSISTANT
"""

def run(cmd):
    print(f"\n$ {' '.join(cmd)}")
    subprocess.run(cmd, check=True)

def main():
    print(BANNER)
    print("Installing Python requirements...")
    run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])

    print("\nInstalling Playwright browsers (Chromium)...")
    try:
        run([sys.executable, "-m", "playwright", "install", "chromium"])
    except subprocess.CalledProcessError as e:
        print(f"  ⚠ Playwright install failed ({e}). Browser actions will be limited until you run:")
        print("      python -m playwright install chromium")

    print("\n✅ Setup complete!  Run 'python main.py' to start Zero Two.")

if __name__ == "__main__":
    main()
