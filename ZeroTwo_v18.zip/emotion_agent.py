"""emotion_agent.py — Zero Two emotion detection & proactive response"""
from __future__ import annotations
import random, re, threading, time
from datetime import datetime

_SAD = ["sad","depressed","unhappy","crying","cry","upset","hurt","alone","lonely",
        "lost","hopeless","tired","exhausted","stressed","overwhelmed","anxious",
        "worried","scared","bad day","hate my life","feel awful","feel terrible",
        "feel bad","feel down","everything sucks","i give up","i cant","i failed",
        "worthless","stupid","hate this","frustrated"]
_HAPPY = ["happy","great","amazing","awesome","excited","love this","so good",
          "finally","yes","worked","it works","got it","nailed it","perfect",
          "winning","success","succeeded","promoted","proud","haha","lol",
          "feeling good","feel good","so happy","incredible","fantastic"]
_BORED = ["bored","boring","nothing to do","doing nothing","what to do",
          "suggest something","entertain me","wasting time"]
_STRESSED = ["stressed","stress","deadline","pressure","overwhelmed","cant handle",
             "too much","behind","running out of time","panicking","panic"]

_RESPONSES = {
    "sad": [
        "Hey, I noticed you seem a little down. I am here with you, boss. Want to talk about it?",
        "I can tell something is bothering you. You do not have to deal with it alone.",
        "You seem a bit off today. Want me to play some music, or just sit with you?",
        "I am noticing you are not yourself. Take a breath. I have got you.",
    ],
    "stressed": [
        "Hey — breathe. You seem really stressed. Tell me what is going on and we will figure it out together.",
        "Okay, I can feel the pressure. Let me help. What is the most urgent thing right now?",
        "You seem overwhelmed. Let us break this down — what is the single biggest thing I can take off your plate?",
    ],
    "bored": [
        "Nothing to do, boss? I can suggest something — movie, game, music, or we can just talk.",
        "Sounds like you need something interesting. Want me to find you a new anime, some music, or see what is trending?",
        "I am here — let us do something fun. What sounds good?",
    ],
    "happy": [
        "You are in a good mood today! I love it. Keep that energy going.",
        "That positive energy from you is genuinely great to see. What are we celebrating?",
    ],
}

class EmotionAgent:
    def __init__(self, speak_callback=None, log_callback=None):
        self._speak = speak_callback
        self._log   = log_callback
        self._emotion = "neutral"; self._count = 0
        self._last_response = 0.0; self._COOLDOWN = 120.0
        self._enabled = True; self._lock = threading.Lock()

    def process_transcript(self, text: str):
        if not self._enabled or not text.strip(): return
        t = text.lower()
        scores = {
            "sad":      sum(1 for s in _SAD     if s in t),
            "stressed": sum(1 for s in _STRESSED if s in t),
            "bored":    sum(1 for s in _BORED    if s in t),
            "happy":    sum(1 for s in _HAPPY    if s in t),
        }
        best = max(scores, key=scores.get)
        score = scores[best]
        if score == 0:
            with self._lock: self._count = max(0, self._count - 1)
            return
        with self._lock:
            if best == self._emotion: self._count += 1
            else: self._emotion = best; self._count = 1
            confident = self._count >= 2
        if confident and best != "neutral":
            now = time.time()
            if now - self._last_response > self._COOLDOWN:
                self._last_response = now
                msg = random.choice(_RESPONSES.get(best, []))
                if msg:
                    if self._log: self._log(f"Zero Two: {msg}")
                    if self._speak: threading.Thread(target=self._speak, args=(msg,), daemon=True).start()

    def enable(self):  self._enabled = True
    def disable(self): self._enabled = False
    def current_emotion(self) -> str:
        with self._lock: return self._emotion
