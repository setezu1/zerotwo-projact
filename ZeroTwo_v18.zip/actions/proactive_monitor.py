"""
proactive_monitor.py — Proactive screen check-ins for Zero Two.

While Zero Two is ACTIVE (awake, not asleep/muted), this module periodically
takes a silent screenshot and asks a fast text+vision model ("the scout call")
two things at once:
  1. Is anything on screen worth commenting on right now? (e.g. an error,
     exception, red squiggly, broken test, obvious typo/bug in code the user
     is actively editing -- OR the user looks visibly idle/stuck after a long
     stretch with no interaction)
  2. If yes, what should Zero Two say -- in character, short, casual.

The scout call is TEXT-ONLY output (no audio), so most cycles are completely
silent -- nothing is queued, nothing plays, nothing appears in the transcript.
Only when the scout says "yes, something's worth mentioning" does the main
assistant actually speak (via its normal `speak()` -> live audio session),
producing a normal Zero Two utterance + transcript line exactly like any
other turn.

This two-step design avoids any race with the live audio stream: by the time
`speak()` is called, we already know -- silently, in text -- whether anything
should be said.

Design goals (per user request):
  - Runs every `interval` seconds (default 60 = "every minute") while active.
  - Pauses immediately while the user is mid-conversation; the idle timer
    resets on every user interaction (text or voice), so it's "every minute
    of being left alone with the AI active", not a rigid wall-clock tick.
  - Casual check-ins ("you good boss?", "what are you working on?",
    "you've been quiet, you good?") only fire after several consecutive
    *unchanged* screens (the user looks idle/stuck), not every cycle --
    otherwise it'd be annoying.
  - Bug/error spotting fires as soon as something error-like appears on
    screen the user is actively working in (a real "saves your ass" catch),
    regardless of idle state.
"""
from __future__ import annotations

import io
import json
import sys
import threading
import time
from pathlib import Path


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


_BASE        = _base_dir()
_CONFIG_PATH = _BASE / "config" / "api_keys.json"

try:
    import mss
    import mss.tools
    _MSS = True
except ImportError:
    _MSS = False

try:
    import PIL.Image
    _PIL = True
except ImportError:
    _PIL = False


def _get_api_key() -> str:
    try:
        cfg = json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        cfg = {}
    key = cfg.get("gemini_api_key", "")
    if not key:
        raise RuntimeError("gemini_api_key not found in config.")
    return key


# Small/cheap image -- this is a frequent background call, keep it light.
_IMG_MAX_W = 720
_IMG_MAX_H = 405
_JPEG_Q    = 55

# Vision-capable, fast/cheap model for the silent "scout" call.
_SCOUT_MODEL = "gemini-2.5-flash"

_SCOUT_PROMPT = """You are the silent "scout" function for Zero Two, an AI \
desktop assistant. You will be shown a screenshot of the user's screen. \
Your ONLY job is to decide whether Zero Two should proactively say \
something right now, and if so, what.

Two situations are worth speaking up for:

1. BUG/ERROR SPOTTED -- the user is clearly working (code editor, terminal, \
IDE, notebook, etc.) and you can see something that looks like a real \
problem: a syntax error, an exception/traceback, a red error squiggly, a \
failing test, an obviously wrong variable name/typo, a broken import, an \
off-by-one, mismatched brackets/quotes, etc. If you spot this, Zero Two \
should point it out -- briefly, casually, in character (a little playful/ \
teasing is fine, like a sharp friend looking over your shoulder -- but \
never mean-spirited or insulting). Be SPECIFIC about what's wrong and \
roughly where, so it's actually useful.

2. USER LOOKS IDLE/STUCK -- `idle_streak` (given below) tells you how many \
consecutive checks (roughly one per minute) the screen has looked basically \
unchanged, with no error visible. If idle_streak is 3 or more, Zero Two MAY \
check in casually -- "you good boss?", "what are you working on?", "you've \
been staring at that for a while, everything okay?" etc. Vary the phrasing; \
don't repeat the same line. Keep it light and not naggy.

In ALL other cases -- the user is actively working, nothing looks wrong, and \
idle_streak is low -- Zero Two should stay completely silent. Silence is the \
DEFAULT and CORRECT answer most of the time. Do not comment just because you \
can; only when it's genuinely useful (a real bug) or genuinely warranted \
(the user has been idle for a while).

idle_streak = {idle_streak}

Respond with ONLY a JSON object, no other text, no markdown fences:
{{"should_speak": true or false, "message": "what Zero Two would say, in \
character, 1-2 short sentences, casual tone, address the user as 'boss'" or \
"" if should_speak is false, "looks_idle": true or false}}

"looks_idle" should be true if the screen looks basically the same as a \
typical idle/unfocused state (e.g. unchanged for a while, no active typing \
cursor blink visible, same window with no new content) -- this is used to \
track idle_streak across calls regardless of whether should_speak is true."""


def _capture_screen_bytes(monitor_index: int = 1) -> tuple[bytes, str]:
    """Capture + downscale the primary screen to a small JPEG. Raises on failure."""
    raw_png = None
    if _MSS:
        with mss.mss() as sct:
            monitors = sct.monitors
            idx = min(monitor_index, len(monitors) - 1)
            if idx < 1 and len(monitors) > 1:
                idx = 1
            elif idx < 0:
                idx = 0
            shot = sct.grab(monitors[idx])
        try:
            raw_png = mss.tools.to_png(shot.rgb, shot.size)
        except Exception:
            if _PIL:
                img = PIL.Image.frombytes("RGB", shot.size, shot.rgb)
                buf = io.BytesIO()
                img.save(buf, format="PNG")
                raw_png = buf.getvalue()
            else:
                raise
    elif _PIL:
        from PIL import ImageGrab
        img = ImageGrab.grab()
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        raw_png = buf.getvalue()
    else:
        raise RuntimeError("Neither mss nor PIL available for screen capture.")

    if _PIL:
        img = PIL.Image.open(io.BytesIO(raw_png)).convert("RGB")
        img.thumbnail((_IMG_MAX_W, _IMG_MAX_H), PIL.Image.BILINEAR)
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=_JPEG_Q, optimize=False)
        return buf.getvalue(), "image/jpeg"
    return raw_png, "image/png"


def _scout_call(image_bytes: bytes, mime_type: str, idle_streak: int) -> dict:
    """
    One-shot text+vision call to Gemini. Returns a dict with
    should_speak / message / looks_idle. Raises on any failure --
    caller treats failures as "stay silent this cycle".
    """
    from google import genai
    from google.genai import types as gtypes

    client = genai.Client(api_key=_get_api_key())
    prompt = _SCOUT_PROMPT.format(idle_streak=idle_streak)

    response = client.models.generate_content(
        model=_SCOUT_MODEL,
        contents=[
            gtypes.Content(
                role="user",
                parts=[
                    gtypes.Part.from_bytes(data=image_bytes, mime_type=mime_type),
                    gtypes.Part.from_text(text=prompt),
                ],
            )
        ],
        config=gtypes.GenerateContentConfig(
            max_output_tokens=200,
            temperature=0.8,
            response_mime_type="application/json",
        ),
    )

    text = (response.text or "").strip()
    # Strip accidental markdown fences just in case
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
        text = text.strip()

    data = json.loads(text)
    return {
        "should_speak": bool(data.get("should_speak", False)),
        "message": str(data.get("message", "") or "").strip(),
        "looks_idle": bool(data.get("looks_idle", False)),
    }


class ProactiveMonitor:
    """
    Background thread that periodically scouts the screen and, when
    warranted, calls `on_speak(message)` so the main assistant can voice it.

    Usage:
        mon = ProactiveMonitor(
            on_speak=assistant.speak,
            is_active=lambda: assistant._wake_active,
            interval=60,
            enabled=False,
        )
        mon.start()
        ...
        mon.notify_user_active()   # call on any user text/voice interaction
        mon.set_interval(90)
        mon.set_enabled(True)
        mon.stop()
    """

    MIN_INTERVAL = 20    # seconds -- floor, even if settings say lower
    IDLE_STREAK_THRESHOLD = 3  # consecutive "looks_idle" cycles before a casual check-in

    def __init__(
        self,
        on_speak,
        is_active,
        interval: int = 60,
        enabled: bool = False,
        log=None,
    ):
        self._on_speak  = on_speak
        self._is_active = is_active
        self._log       = log or (lambda *_: None)
        self._enabled   = enabled
        self.set_interval(interval)

        self._running   = False
        self._thread    = None
        self._lock      = threading.Lock()

        self._last_user_activity = time.time()
        self._idle_streak = 0
        self._last_speak_time = 0.0

        # Cooldown after speaking so we don't immediately re-trigger on the
        # same issue/idle state the very next cycle (gives the user a moment
        # to react / the screen a moment to change).
        self._POST_SPEAK_COOLDOWN = 45  # seconds

    # ── public controls ──────────────────────────────────────────────────────
    def set_interval(self, seconds: int):
        self._interval = max(self.MIN_INTERVAL, int(seconds))

    def set_enabled(self, enabled: bool):
        was = self._enabled
        self._enabled = bool(enabled)
        if self._enabled and not was:
            self.notify_user_active()  # don't fire immediately on enable
            self._log("SYS: Proactive check-ins enabled -- I'll glance at your screen now and then, boss.")
        elif not self._enabled and was:
            self._log("SYS: Proactive check-ins disabled.")

    def notify_user_active(self):
        """Call this on any user text/voice interaction -- resets the idle clock."""
        with self._lock:
            self._last_user_activity = time.time()
            self._idle_streak = 0

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True, name="ProactiveMonitor")
        self._thread.start()

    def stop(self):
        self._running = False

    # ── background loop ──────────────────────────────────────────────────────
    def _loop(self):
        while self._running:
            time.sleep(2)  # check conditions every 2s; act at most every `interval`
            try:
                if not self._enabled:
                    continue
                if not self._is_active():
                    continue

                now = time.time()
                with self._lock:
                    last_activity = self._last_user_activity

                # Don't fire again too soon after our own last comment
                if now - self._last_speak_time < self._POST_SPEAK_COOLDOWN:
                    continue

                # "Idle for `interval` seconds" -> time to scout
                if now - last_activity < self._interval:
                    continue

                self._run_cycle()

                # After a cycle (spoke or not), push the activity timer
                # forward by `interval` so we don't re-scout every 2s while
                # idle -- next scout is ~`interval` seconds from now unless
                # the user interacts (which resets it sooner via
                # notify_user_active()).
                with self._lock:
                    self._last_user_activity = now

            except Exception as e:
                self._log(f"SYS: Proactive monitor error: {e}")
                # back off a bit on repeated errors so we don't spam logs
                time.sleep(5)

    def _run_cycle(self):
        try:
            image_bytes, mime_type = _capture_screen_bytes()
        except Exception as e:
            self._log(f"SYS: Proactive monitor -- screen capture failed: {e}")
            return

        with self._lock:
            idle_streak_for_call = self._idle_streak

        try:
            result = _scout_call(image_bytes, mime_type, idle_streak_for_call)
        except Exception as e:
            # Silent on failure -- scout calls failing shouldn't be noisy.
            self._log(f"SYS: Proactive monitor -- scout call failed: {e}")
            return

        with self._lock:
            if result["looks_idle"]:
                self._idle_streak += 1
            else:
                self._idle_streak = 0

            # Idle-only check-ins additionally require crossing the
            # streak threshold -- the model is told this via idle_streak,
            # but we double-check here so a model hallucination on a single
            # cycle can't trigger a premature "you good boss?".
            is_idle_checkin = result["should_speak"] and result["looks_idle"]
            if is_idle_checkin and self._idle_streak < self.IDLE_STREAK_THRESHOLD:
                result["should_speak"] = False

        if result["should_speak"] and result["message"]:
            self._last_speak_time = time.time()
            self._log(f"SYS: Proactive check-in -- {result['message'][:80]}")
            try:
                self._on_speak(result["message"])
            except Exception as e:
                self._log(f"SYS: Proactive monitor -- speak failed: {e}")
