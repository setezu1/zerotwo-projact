"""
confirm_dialog.py — Confirmation prompt for dangerous PC operations.
Used before: file delete, system shutdown/restart, installs, overwrites.
Thread-safe: posts to Qt main thread, blocks caller thread until answered.
"""
from __future__ import annotations

import threading
from typing import Callable

from PyQt6.QtCore    import Qt, QTimer, pyqtSignal, QObject
from PyQt6.QtGui     import QFont
from PyQt6.QtWidgets import (QDialog, QHBoxLayout, QLabel,
                              QPushButton, QVBoxLayout, QWidget)


# ── Danger levels ─────────────────────────────────────────────────────────────
class Danger:
    LOW    = "low"     # rename, move — just inform
    MEDIUM = "medium"  # overwrite, large copy
    HIGH   = "high"    # delete files, kill processes
    CRITICAL = "critical"  # shutdown, format, system changes


_DANGER_COLORS = {
    Danger.LOW:      ("#00ff88", "#001a0d"),
    Danger.MEDIUM:   ("#ffcc00", "#1a1400"),
    Danger.HIGH:     ("#ff6600", "#1a0800"),
    Danger.CRITICAL: ("#ff3355", "#1a0010"),
}

_DANGER_ICONS = {
    Danger.LOW:      "ℹ",
    Danger.MEDIUM:   "⚠",
    Danger.HIGH:     "🔥",
    Danger.CRITICAL: "☠",
}

# ── Classify action ───────────────────────────────────────────────────────────

_HIGH_WORDS     = ["delete","remove","unlink","rmdir","shutil.rmtree","wipe","erase","format","truncate"]
_CRITICAL_WORDS = ["shutdown","restart","reboot","hibernate","logoff","sign out",
                   "kill process","terminate","registry","sys.exit","os._exit"]
_MEDIUM_WORDS   = ["overwrite","replace","install","uninstall","upgrade","downgrade","move","rename"]

def classify_danger(action_description: str) -> str:
    low = action_description.lower()
    if any(w in low for w in _CRITICAL_WORDS): return Danger.CRITICAL
    if any(w in low for w in _HIGH_WORDS):     return Danger.HIGH
    if any(w in low for w in _MEDIUM_WORDS):   return Danger.MEDIUM
    return Danger.LOW


# ── Dialog widget ─────────────────────────────────────────────────────────────

class ConfirmDialog(QDialog):
    def __init__(self, title: str, message: str, danger: str = Danger.HIGH, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Dialog)
        self.setModal(True)
        self.setMinimumWidth(400)

        fg, bg = _DANGER_COLORS.get(danger, _DANGER_COLORS[Danger.HIGH])
        icon   = _DANGER_ICONS.get(danger, "⚠")

        self.setStyleSheet(f"""
            QDialog {{
                background: {bg};
                border: 1px solid {fg};
                border-radius: 8px;
            }}
        """)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 16, 20, 16)
        lay.setSpacing(12)

        # Header
        hdr = QHBoxLayout()
        icon_lbl = QLabel(icon)
        icon_lbl.setFont(QFont("Segoe UI Emoji", 18))
        icon_lbl.setStyleSheet("background: transparent;")
        title_lbl = QLabel(title)
        title_lbl.setFont(QFont("Courier New", 10, QFont.Weight.Bold))
        title_lbl.setStyleSheet(f"color: {fg}; background: transparent;")
        hdr.addWidget(icon_lbl)
        hdr.addWidget(title_lbl, stretch=1)
        lay.addLayout(hdr)

        # Message
        msg_lbl = QLabel(message)
        msg_lbl.setFont(QFont("Courier New", 8))
        msg_lbl.setStyleSheet(f"color: #cccccc; background: transparent;")
        msg_lbl.setWordWrap(True)
        lay.addWidget(msg_lbl)

        # Danger badge
        badge = QLabel(f"  DANGER LEVEL: {danger.upper()}  ")
        badge.setFont(QFont("Courier New", 7, QFont.Weight.Bold))
        badge.setStyleSheet(f"color: {bg}; background: {fg}; border-radius: 3px; padding: 2px 6px;")
        badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(badge)

        # Buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(10)

        deny_btn = QPushButton("✕  NO, CANCEL")
        deny_btn.setFont(QFont("Courier New", 8, QFont.Weight.Bold))
        deny_btn.setFixedHeight(34)
        deny_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        deny_btn.setStyleSheet(f"""
            QPushButton {{
                background: transparent;
                color: #aaaaaa;
                border: 1px solid #333333;
                border-radius: 5px;
            }}
            QPushButton:hover {{
                background: #1a1a1a;
                color: #ffffff;
                border: 1px solid #555555;
            }}
        """)
        deny_btn.clicked.connect(self.reject)

        confirm_btn = QPushButton("✔  YES, PROCEED")
        confirm_btn.setFont(QFont("Courier New", 8, QFont.Weight.Bold))
        confirm_btn.setFixedHeight(34)
        confirm_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        confirm_btn.setStyleSheet(f"""
            QPushButton {{
                background: transparent;
                color: {fg};
                border: 1px solid {fg};
                border-radius: 5px;
            }}
            QPushButton:hover {{
                background: {bg};
                border: 1px solid {fg};
            }}
        """)
        confirm_btn.clicked.connect(self.accept)

        btn_row.addWidget(deny_btn, stretch=1)
        btn_row.addWidget(confirm_btn, stretch=1)
        lay.addLayout(btn_row)


# ── Thread-safe confirmation gate ─────────────────────────────────────────────

class _ConfirmBridge(QObject):
    """Routes confirmation requests from any thread to Qt main thread."""
    _request_sig = pyqtSignal(str, str, str, object)  # title, msg, danger, event

    def __init__(self):
        super().__init__()
        self._request_sig.connect(self._show)
        self._result: dict[int, bool] = {}

    def _show(self, title: str, message: str, danger: str, payload: object):
        event, uid = payload
        dlg = ConfirmDialog(title, message, danger)
        result = dlg.exec() == QDialog.DialogCode.Accepted
        self._result[uid] = result
        event.set()

    def ask(self, title: str, message: str, danger: str = Danger.HIGH) -> bool:
        """
        Block the calling thread until user answers.
        Safe to call from any thread (background tool executor, etc.)
        Returns True = confirmed, False = denied.
        """
        from PyQt6.QtWidgets import QApplication
        if QApplication.instance() is None:
            return True  # no UI — auto-confirm (CLI mode)

        event = threading.Event()
        uid   = id(event)
        self._request_sig.emit(title, message, danger, (event, uid))
        event.wait(timeout=30)  # auto-deny after 30s
        result = self._result.pop(uid, False)
        return result


# Singleton bridge — created once Qt app exists
_bridge: _ConfirmBridge | None = None

def _get_bridge() -> _ConfirmBridge:
    global _bridge
    if _bridge is None:
        _bridge = _ConfirmBridge()
    return _bridge


# ── Public API ────────────────────────────────────────────────────────────────

def confirm_action(
    action_description: str,
    detail: str = "",
    danger: str | None = None,
) -> bool:
    """
    Ask the user to confirm a potentially dangerous action.

    Args:
        action_description: Short title, e.g. "Delete 47 files"
        detail:             Longer explanation shown in the dialog body
        danger:             Override danger level (auto-classified if None)

    Returns:
        True if user confirmed, False if denied/timed out
    """
    if danger is None:
        danger = classify_danger(action_description + " " + detail)

    if danger == Danger.LOW:
        return True  # Low-danger ops don't need confirmation

    title   = action_description
    message = detail or f"ZERO TWO is about to: {action_description}\n\nThis action may be irreversible."
    return _get_bridge().ask(title, message, danger)


def requires_confirm(danger_level: str = Danger.HIGH):
    """
    Decorator for tool functions that need user confirmation.

    Usage:
        @requires_confirm(Danger.HIGH)
        def delete_files(paths):
            ...
    """
    def decorator(fn: Callable) -> Callable:
        def wrapper(*args, **kwargs):
            action = f"Execute: {fn.__name__}"
            detail = f"Function '{fn.__name__}' with args: {args[:2]}"
            if confirm_action(action, detail, danger_level):
                return fn(*args, **kwargs)
            else:
                return "Action cancelled by user."
        return wrapper
    return decorator
