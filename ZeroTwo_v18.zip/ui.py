"""
ZERO TWO AI -- v15 Zero Two Themed Dashboard
Full UI redesign: deep black / dark crimson / soft pink / glass panels.
All v14 functionality preserved: PIN lock, clap activation, proactive
check-ins, memory viewer, command palette, screen share, streaming chat.
"""
from __future__ import annotations

import json, math, os, platform, random, subprocess, sys, threading, time, re
import hashlib, secrets
from pathlib import Path

import psutil
from PyQt6.QtCore  import QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui   import (QBrush, QColor, QDragEnterEvent, QDropEvent,
                            QFont, QKeySequence, QPainter, QPainterPath,
                            QPen, QRadialGradient, QShortcut, QLinearGradient)
from PyQt6.QtWidgets import (
    QApplication, QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit,
    QMainWindow, QPushButton, QScrollArea, QSizePolicy, QTextEdit,
    QVBoxLayout, QWidget, QProgressBar, QGridLayout, QStackedWidget,
    QSlider, QComboBox, QCheckBox, QDialog, QSystemTrayIcon, QMenu,
    QListWidget, QListWidgetItem, QTableWidget, QTableWidgetItem,
    QHeaderView, QAbstractItemView, QMessageBox,
)

# -- Paths --------------------------------------------------------------------
def _base_dir() -> Path:
    return Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent

BASE_DIR      = _base_dir()
CONFIG_DIR    = BASE_DIR / "config"
API_FILE      = CONFIG_DIR / "api_keys.json"
SETTINGS_FILE = CONFIG_DIR / "settings.json"
MEMORY_FILE   = BASE_DIR  / "memory" / "long_term.json"
LOCK_FILE     = CONFIG_DIR / "lock.json"
_OS           = platform.system()
_W, _H        = 1440, 880
_MIN_W, _MIN_H = 1100, 700

# -- Colour palette  (Zero Two theme: deep black / crimson / soft pink) --------
class C:
    # Backgrounds
    BG       = "#0a0608"   # near-black with warm red tint
    BG2      = "#0d080a"
    NAVY     = "#080508"   # deepest bg for panels
    PANEL    = "#120a0d"   # glass panel base
    PANEL2   = "#180d10"
    CARD     = "#150a0d"   # card surface
    CARD2    = "#1c0f13"
    # Borders
    BORDER   = "#2a1218"
    BORDER_G = "#3d1a22"   # standard border
    BORDER_A = "#5c2430"   # accent/hover border
    # Primary accent -- Zero Two crimson-pink
    GREEN    = "#e8386a"   # primary (was green, now hot crimson-pink)
    GREEN_D  = "#c0284f"   # darker variant
    GREEN_DIM= "#3d0d18"   # very dim fill
    GREEN_GHO= "#1a0509"   # ghost / near-transparent fill
    # Secondary accents
    TEAL     = "#ff7fa0"   # soft pink (was teal)
    CYAN     = "#ffb8cb"   # pale blush pink (was cyan)
    # Status colours
    RED      = "#ff2244"   # error / danger
    ORANGE   = "#ff7040"
    YELLOW   = "#ffd460"
    SUCCESS  = "#ff6b8a"
    # Text
    WHITE    = "#fff0f3"   # warm near-white
    TEXT     = "#c88898"   # mid-tone rose
    TEXT_DIM = "#5a2d38"   # dim/placeholder
    TEXT_MED = "#8a4d5e"   # medium text
    # Extras
    PURPLE   = "#9b3a6e"
    BLUE     = "#c03060"
    BAR_BG   = "#1a0a0d"
    GLASS    = "#160c0f"
    GLASS_B  = "#201218"
    # Theme variants (for theme selector)
    THEMES = {
        "Zero Two Classic":  {"accent": "#e8386a", "accent2": "#ff7fa0"},
        "Dark Red":          {"accent": "#cc1a2a", "accent2": "#ff5566"},
        "Pink Neon":         {"accent": "#ff45a0", "accent2": "#ff99cc"},
        "Cyber Crimson":     {"accent": "#ff0040", "accent2": "#ff6688"},
    }

# Zero Two palette version for version bar
_VERSION = "15.0"
try:
    _v = (__import__("pathlib").Path(__file__).resolve().parent / "VERSION.txt")
    if _v.exists():
        for _line in _v.read_text().splitlines():
            if _line.startswith("Version:"):
                _VERSION = _line.split(":",1)[1].strip(); break
except Exception:
    pass

def qcol(h: str, a: int = 255) -> QColor:
    c = QColor(h); c.setAlpha(a); return c

ZERO_TWO_VOICE = "Aoede"

def _fmt_size(s: int) -> str:
    if s < 1024:       return f"{s} B"
    if s < 1048576:    return f"{s/1024:.1f} KB"
    if s < 1073741824: return f"{s/1048576:.1f} MB"
    return f"{s/1073741824:.1f} GB"

# -- Settings -------------------------------------------------------------------
_DEFAULTS = {
    "voice": "Aoede", "volume": 80, "mic_sensitivity": 70,
    "auto_memory": True, "notifications": True, "startup_greeting": True,
    "wake_word": True, "wake_phrase": "hey zero two", "agent_mode": True,
    "ai_model": "gemini-2.5-flash", "auto_run": False,
    "clap_activation": False, "clap_sensitivity": 60,
    "proactive_checkins": False, "proactive_interval": 60,
    "theme": "Zero Two Classic",
}

def load_settings() -> dict:
    if SETTINGS_FILE.exists():
        try: return {**_DEFAULTS, **json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))}
        except Exception: pass
    return dict(_DEFAULTS)

def save_settings(s: dict):
    os.makedirs(CONFIG_DIR, exist_ok=True)
    SETTINGS_FILE.write_text(json.dumps(s, indent=2), encoding="utf-8")

# -- PIN lock -------------------------------------------------------------------
# The PIN is never stored in plaintext. We use PBKDF2-HMAC-SHA256 with a
# random per-install salt, which is the standard approach for hashing
# low-entropy secrets like PINs (slow enough to resist brute force, but
# instant for the single check this app needs).
_PIN_ITERATIONS = 200_000

def _hash_pin(pin: str, salt: bytes) -> str:
    dk = hashlib.pbkdf2_hmac("sha256", pin.encode("utf-8"), salt, _PIN_ITERATIONS)
    return dk.hex()

def lock_is_enabled() -> bool:
    if not LOCK_FILE.exists(): return False
    try:
        d = json.loads(LOCK_FILE.read_text(encoding="utf-8"))
        return bool(d.get("enabled", False)) and bool(d.get("pin_hash"))
    except Exception:
        return False

def lock_pin_is_set() -> bool:
    if not LOCK_FILE.exists(): return False
    try:
        d = json.loads(LOCK_FILE.read_text(encoding="utf-8"))
        return bool(d.get("pin_hash")) and bool(d.get("salt"))
    except Exception:
        return False

def set_lock_pin(pin: str, enabled: bool = True):
    """Hash and store a new PIN, replacing any existing one."""
    salt = secrets.token_bytes(16)
    data = {
        "enabled": enabled,
        "salt": salt.hex(),
        "pin_hash": _hash_pin(pin, salt),
    }
    os.makedirs(CONFIG_DIR, exist_ok=True)
    LOCK_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")

def verify_lock_pin(pin: str) -> bool:
    if not LOCK_FILE.exists(): return False
    try:
        d = json.loads(LOCK_FILE.read_text(encoding="utf-8"))
        salt = bytes.fromhex(d.get("salt", ""))
        stored = d.get("pin_hash", "")
        if not salt or not stored: return False
        candidate = _hash_pin(pin, salt)
        # Constant-time comparison to avoid timing side-channels
        return secrets.compare_digest(candidate, stored)
    except Exception:
        return False

def set_lock_enabled(enabled: bool):
    """Toggle lock on/off without changing the stored PIN."""
    if not LOCK_FILE.exists():
        return
    try:
        d = json.loads(LOCK_FILE.read_text(encoding="utf-8"))
        d["enabled"] = enabled
        LOCK_FILE.write_text(json.dumps(d, indent=2), encoding="utf-8")
    except Exception:
        pass

def remove_lock():
    """Remove the PIN entirely (disable + forget hash)."""
    try:
        if LOCK_FILE.exists(): LOCK_FILE.unlink()
    except Exception:
        pass

# -- System metrics ---------------------------------------------------------------
class _SysMetrics:
    def __init__(self):
        self.cpu = self.mem = self.net = 0.0; self.gpu = self.tmp = -1.0
        self._lock = threading.Lock()
        self._last_net = psutil.net_io_counters(); self._last_t = time.time()
        self._cpu_hist = [0.0]*40; self._mem_hist = [0.0]*40
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        while True:
            try: self._update()
            except Exception: pass
            time.sleep(1.5)

    def _update(self):
        cpu = psutil.cpu_percent(interval=None)
        mem = psutil.virtual_memory().percent
        nc = psutil.net_io_counters(); now = time.time(); dt = now - self._last_t
        net = ((nc.bytes_sent - self._last_net.bytes_sent) + (nc.bytes_recv - self._last_net.bytes_recv)) / max(dt, 0.001) / 1048576
        self._last_net, self._last_t = nc, now
        gpu = self._gpu(); tmp = self._temp()
        with self._lock:
            self.cpu, self.mem, self.net, self.gpu, self.tmp = cpu, mem, net, gpu, tmp
            self._cpu_hist.append(cpu); self._cpu_hist.pop(0)
            self._mem_hist.append(mem); self._mem_hist.pop(0)

    def _gpu(self) -> float:
        try:
            r = subprocess.run(["nvidia-smi","--query-gpu=utilization.gpu","--format=csv,noheader,nounits"],
                               capture_output=True, text=True, timeout=2)
            if r.returncode == 0:
                vals = [float(v) for v in r.stdout.strip().split("\n") if v.strip()]
                if vals: return sum(vals)/len(vals)
        except Exception: pass
        return -1.0

    def _temp(self) -> float:
        try:
            from system_monitor import get_monitor
            t = get_monitor().snapshot().temp
            if t and t > 0: return float(t)
        except Exception: pass
        try:
            t = psutil.sensors_temperatures()
            for n in ["coretemp","k10temp","cpu_thermal","acpitz","zenpower"]:
                if n in t and t[n]: return t[n][0].current
            for v in t.values():
                if v: return v[0].current
        except Exception: pass
        return -1.0

    def snapshot(self) -> dict:
        with self._lock:
            return {"cpu": self.cpu, "mem": self.mem, "net": self.net,
                    "gpu": self.gpu, "tmp": self.tmp,
                    "cpu_hist": list(self._cpu_hist), "mem_hist": list(self._mem_hist)}

_metrics = _SysMetrics()

# -- Sparkline --------------------------------------------------------------------
class Sparkline(QWidget):
    def __init__(self, color: str = "#00ff88", parent=None):
        super().__init__(parent); self._data = [0.0]*40; self._color = color
        self.setFixedHeight(40)

    def update_data(self, data: list):
        self._data = list(data[-40:]); self.update()

    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), qcol(C.BG2, 0))
        W, H = self.width(), self.height()
        if not self._data or len(self._data) < 2: return
        mn, mx = 0, max(max(self._data), 1); N = len(self._data)
        pts = []
        for i, v in enumerate(self._data):
            x = i*(W/(N-1)) if N > 1 else W/2
            y = H - (v-mn)/(mx-mn)*(H-4) - 2
            pts.append(QPointF(x, y))
        path = QPainterPath(); path.moveTo(pts[0])
        for pt in pts[1:]: path.lineTo(pt)
        path.lineTo(QPointF(W, H)); path.lineTo(QPointF(0, H)); path.closeSubpath()
        grad = QLinearGradient(0, 0, 0, H)
        grad.setColorAt(0.0, qcol(self._color, 60)); grad.setColorAt(1.0, qcol(self._color, 5))
        p.fillPath(path, QBrush(grad))
        p.setPen(QPen(qcol(self._color, 220), 1.5)); p.setBrush(Qt.BrushStyle.NoBrush)
        for i in range(len(pts)-1): p.drawLine(pts[i], pts[i+1])
        if pts:
            lp = pts[-1]; p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(qcol(self._color, 255))); p.drawEllipse(lp, 2.5, 2.5)

# -- Orb Canvas --------------------------------------------------------------------
class OrbCanvas(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.muted = False; self.speaking = False; self.state = "LISTENING"
        self._tick = self._blink_t = 0; self._halo = self._tgt_halo = 60.0
        self._scale = self._tgt_scale = 1.0; self._scan = 0.0; self._scan2 = 180.0
        self._rings = [0.0, 120.0, 240.0]; self._pulses = [0.0, 60.0, 120.0]
        self._blink = True; self._last_t = time.time()
        self._wave = [random.uniform(0.85, 1.0) for _ in range(80)]
        self._particles = [(random.uniform(0,1), random.uniform(0,1), random.uniform(0.3,1.0)) for _ in range(200)]
        self._tmr = QTimer(self); self._tmr.timeout.connect(self._step); self._tmr.start(16)

    def _step(self):
        self._tick += 1; now = time.time()
        if now - self._last_t > (0.10 if self.speaking else 0.45):
            if self.speaking:     self._tgt_halo = random.uniform(150,200); self._tgt_scale = random.uniform(1.05,1.12)
            elif self.muted:      self._tgt_halo = random.uniform(10,25);   self._tgt_scale = random.uniform(0.98,1.0)
            else:                 self._tgt_halo = random.uniform(40,70);   self._tgt_scale = random.uniform(1.0,1.02)
            self._last_t = now
        sp = 0.35 if self.speaking else 0.12
        self._halo  += (self._tgt_halo  - self._halo)  * sp
        self._scale += (self._tgt_scale - self._scale) * sp
        for i, s in enumerate([1.0,-0.6,1.4] if self.speaking else [0.4,-0.25,0.65]):
            self._rings[i] = (self._rings[i]+s) % 360
        self._scan  = (self._scan  + (2.0 if self.speaking else 0.8))  % 360
        self._scan2 = (self._scan2 + (-1.5 if self.speaking else -0.6)) % 360
        fw = min(self.width(), self.height()); lim = fw*0.68; spd = 3.2 if self.speaking else 1.5
        self._pulses = [r+spd for r in self._pulses if r+spd < lim]
        if len(self._pulses) < 4 and random.random() < (0.05 if self.speaking else 0.015):
            self._pulses.append(0.0)
        for i in range(len(self._wave)):
            tgt = random.uniform(0.72,1.0) if self.speaking else random.uniform(0.87,0.97)
            self._wave[i] += (tgt - self._wave[i]) * (0.28 if self.speaking else 0.04)
        self._blink_t += 1
        if self._blink_t >= 35: self._blink = not self._blink; self._blink_t = 0
        self.update()

    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), qcol(C.BG))
        W, H = self.width(), self.height(); cx, cy = W/2, H/2; fw = min(W, H)

        # -- warm particle field (rose-crimson dust) --
        for px, py, alpha in self._particles:
            x = int(px*W); y = int(py*H)
            a = max(0, min(255, int(alpha*160*self._halo/60)))
            col = C.TEAL if alpha > 0.7 else C.GREEN
            p.setPen(QPen(qcol(col if not self.muted else "#666", a), 1))
            p.drawPoint(x, y)

        r_orb = fw*0.26*self._scale

        # -- outer glow halos (crimson atmospheric glow) --
        for i in range(14):
            r = r_orb*(2.3-i*0.09); frc = 1.0-i/14
            a = max(0, min(255, int(self._halo*0.055*frc)))
            glow_col = "#8b0020" if self.muted else ("#c02050" if i < 7 else "#e83870")
            p.setPen(QPen(qcol(glow_col, a), 1.2 if i < 4 else 0.8))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(QRectF(cx-r, cy-r, r*2, r*2))

        # -- expanding pulse rings (crimson) --
        for pr in self._pulses:
            a = max(0, int(180*(1.0-pr/(fw*0.68))))
            pulse_col = "#ff2244" if self.muted else C.GREEN
            p.setPen(QPen(qcol(pulse_col, a), 1.5))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(QRectF(cx-pr, cy-pr, pr*2, pr*2))

        # -- decorative arc rings (dashed crimson/pink) --
        for idx, (rf, wr, al, gap) in enumerate([(0.52,2.2,80,55),(0.42,1.5,60,40),(0.33,1.0,40,30)]):
            rr = fw*rf; base = self._rings[idx]
            av = max(0, min(255, int(self._halo*(0.9-idx*0.2))))
            ring_col = "#ff2244" if self.muted else [C.GREEN, "#c84060", "#ff7fa0"][idx]
            p.setPen(QPen(qcol(ring_col, av), wr))
            p.setBrush(Qt.BrushStyle.NoBrush)
            rect = QRectF(cx-rr, cy-rr, rr*2, rr*2); angle = base
            while angle < base+360:
                p.drawArc(rect, int(angle*16), int(al*16)); angle += al+gap

        # -- scanner arcs (soft pink) --
        sr = fw*0.54; sa = min(255, int(self._halo*1.3)); ex = 60 if self.speaking else 40
        srect = QRectF(cx-sr, cy-sr, sr*2, sr*2)
        p.setPen(QPen(qcol(C.TEAL if not self.muted else "#ff2244", sa), 2.0))
        p.setBrush(Qt.BrushStyle.NoBrush); p.drawArc(srect, int(self._scan*16), int(ex*16))
        p.setPen(QPen(qcol(C.CYAN, sa//3), 1.2))
        p.drawArc(srect, int(self._scan2*16), int(ex*16))

        # -- orb core (deep crimson-black interior, rose edge glow) --
        grad = QRadialGradient(cx, cy, r_orb)
        if self.muted:
            grad.setColorAt(0.0, qcol("#1a0005", 230))
            grad.setColorAt(0.6, qcol("#0d0003", 210))
            grad.setColorAt(1.0, qcol("#080002", 190))
        elif self.speaking:
            grad.setColorAt(0.0, qcol("#3d0015", 235))
            grad.setColorAt(0.5, qcol("#1f000c", 220))
            grad.setColorAt(1.0, qcol("#0d0005", 200))
        else:
            grad.setColorAt(0.0, qcol("#200008", 225))
            grad.setColorAt(0.6, qcol("#110004", 210))
            grad.setColorAt(1.0, qcol("#080002", 190))
        p.setBrush(QBrush(grad)); p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(QRectF(cx-r_orb, cy-r_orb, r_orb*2, r_orb*2))

        # -- wave boundary (Zero Two's horn-like spiky profile) --
        N = len(self._wave)
        for i in range(N):
            a1 = (i/N)*2*math.pi; a2 = ((i+1)/N)*2*math.pi
            r1 = r_orb*self._wave[i]; r2 = r_orb*self._wave[(i+1)%N]
            av = max(0, min(255, int(self._halo*1.8)))
            wave_col = "#ff2244" if self.muted else C.GREEN
            p.setPen(QPen(qcol(wave_col, av), 1.2))
            p.drawLine(QPointF(cx+r1*math.cos(a1), cy+r1*math.sin(a1)),
                       QPointF(cx+r2*math.cos(a2), cy+r2*math.sin(a2)))
            if i%5 == 0:
                p.setPen(QPen(qcol(C.TEAL, av//5), 0.7))
                p.drawLine(QPointF(cx, cy), QPointF(cx+r1*math.cos(a1), cy+r1*math.sin(a1)))

        # -- orb rim (bright crimson-pink circle) --
        rim_col = "#ff2244" if self.muted else C.GREEN
        p.setPen(QPen(qcol(rim_col, min(255, int(self._halo*2.5))), 1.5))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(QRectF(cx-r_orb, cy-r_orb, r_orb*2, r_orb*2))

        # -- state label inside orb --
        state_colors = {
            "LISTENING": C.TEAL, "SPEAKING": C.GREEN, "THINKING": C.YELLOW,
            "PROCESSING": C.ORANGE, "EXECUTION": C.ORANGE, "SLEEP": C.TEXT_DIM, "MUTED": C.RED,
        }
        sc = state_colors.get(self.state, C.TEXT)
        p.setPen(QPen(qcol(sc, 180), 1))
        p.setFont(QFont("Courier New", max(6, int(fw*0.025)), QFont.Weight.Bold))
        label_rect = QRectF(cx - r_orb*0.7, cy + r_orb*0.4, r_orb*1.4, r_orb*0.4)
        p.drawText(label_rect, Qt.AlignmentFlag.AlignCenter, self.state)

        # -- voice equalizer bars (crimson) --
        wy = cy + fw*0.42; N2, bw = 28, 8; wx0 = (W-N2*bw)/2
        for i in range(N2):
            if self.muted:
                hgt, cl = 2, qcol("#ff2244", 80)
            elif self.speaking:
                hgt = random.randint(2,22)
                cl = qcol(C.GREEN, 220) if hgt > 12 else qcol(C.TEAL, 170)
            else:
                hgt = int(2+3*math.sin(self._tick*0.07+i*0.75))
                cl = qcol(C.BORDER_G, 120)
            p.fillRect(QRectF(wx0+i*bw, wy+24-hgt, bw-2, hgt), cl)


# -- Markdown -> HTML helper -----------------------------------------------------
def _md_to_html(text: str) -> str:
    """Lightweight markdown -> rich HTML for chat bubbles (Zero Two theme)."""
    lines = text.split('\n'); out = []; in_code = False; code_buf = []
    for line in lines:
        if line.strip().startswith('```'):
            if in_code:
                in_code = False
                ct = '\n'.join(code_buf).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
                out.append(f'<pre style="background:#1a0508;color:#e8386a;padding:6px 8px;'
                           f'border-radius:6px;font-family:Courier New,monospace;font-size:9pt;'
                           f'margin:4px 0;white-space:pre-wrap;border-left:2px solid #e8386a;">{ct}</pre>')
                code_buf = []
            else:
                in_code = True
            continue
        if in_code: code_buf.append(line); continue
        if   line.startswith('### '): line = f'<b style="color:#e8386a;font-size:10pt;">{line[4:]}</b><br>'
        elif line.startswith('## '):  line = f'<b style="color:#ff7fa0;font-size:11pt;">{line[3:]}</b><br>'
        elif line.startswith('# '):   line = f'<b style="color:#ffb8cb;font-size:12pt;">{line[2:]}</b><br>'
        elif line.strip().startswith(('- ','* ')):
            c = line.strip()[2:]
            c = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', c)
            c = re.sub(r'`(.+?)`', r'<code style="background:#1a0508;color:#e8386a;padding:1px 4px;border-radius:2px;">\1</code>', c)
            line = f'<span style="color:#e8386a;">&#10148;</span> {c}<br>'
        else:
            line = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', line)
            line = re.sub(r'`(.+?)`', r'<code style="background:#1a0508;color:#e8386a;padding:1px 4px;border-radius:2px;">\1</code>', line)
            line = re.sub(r'\*(.+?)\*', r'<i>\1</i>', line)
            if line.strip(): line = line + '<br>'
        out.append(line)
    return ''.join(out).rstrip('<br>')


# -- Typing dots widget ---------------------------------------------------------
class TypingDots(QWidget):
    """Animated typing indicator — three pulsing pink dots."""
    def __init__(self, parent=None):
        super().__init__(parent); self.setFixedSize(44, 20); self._phase = 0
        t = QTimer(self); t.timeout.connect(self._tick); t.start(380)
    def _tick(self): self._phase = (self._phase+1) % 3; self.update()
    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        cols = [C.GREEN, C.TEAL, "#ff99bb"]
        for i in range(3):
            a = 255 if i == self._phase else 60
            col = cols[i] if i == self._phase else C.BORDER_G
            p.setBrush(QBrush(qcol(col, a))); p.setPen(Qt.PenStyle.NoPen)
            p.drawEllipse(QRectF(4+i*13, 5, 9, 9))


# -- Enhanced Chat Transcript Widget ---------------------------------------------
class TranscriptWidget(QWidget):
    _sig = pyqtSignal(str, bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self); lay.setContentsMargins(0,0,0,0); lay.setSpacing(0)
        self._scroll = QScrollArea(); self._scroll.setWidgetResizable(True)
        self._scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._scroll.setStyleSheet(f"""
            QScrollArea{{background:transparent;border:none;}}
            QScrollBar:vertical{{background:{C.BG};width:4px;border:none;}}
            QScrollBar::handle:vertical{{background:{C.BORDER_G};border-radius:2px;}}
        """)
        self._container = QWidget(); self._container.setStyleSheet("background:transparent;")
        self._vlay = QVBoxLayout(self._container)
        self._vlay.setContentsMargins(12,12,12,12); self._vlay.setSpacing(10)
        self._vlay.addStretch()
        self._scroll.setWidget(self._container)
        lay.addWidget(self._scroll)

        # Scroll-to-bottom button
        self._scroll_btn = QPushButton("v Scroll to latest")
        self._scroll_btn.setFixedHeight(26)
        self._scroll_btn.setFont(QFont("Courier New", 7, QFont.Weight.Bold))
        self._scroll_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._scroll_btn.setStyleSheet(
            f"QPushButton{{background:{C.GREEN_DIM};color:{C.GREEN};"
            f"border:1px solid {C.GREEN_D};border-radius:0;padding:0 12px;}}"
            f"QPushButton:hover{{background:{C.PANEL};}}"
        )
        self._scroll_btn.hide()
        self._scroll_btn.clicked.connect(self._scroll_to_bottom)
        lay.addWidget(self._scroll_btn)

        self._sig.connect(self._add_bubble)
        self._typing_row = None
        self._typing_widget = None
        self._streaming_label = None
        self._streaming_full = ""
        self._stream_timer = None
        self._stream_chars_shown = 0
        self._auto_scroll = True
        self._command_history: list = []

        sb = self._scroll.verticalScrollBar()
        sb.valueChanged.connect(self._on_scroll)
        sb.rangeChanged.connect(lambda *_: self._maybe_scroll())

    def _on_scroll(self, val: int):
        sb = self._scroll.verticalScrollBar()
        at_bottom = val >= sb.maximum() - 20
        self._auto_scroll = at_bottom
        self._scroll_btn.setVisible(not at_bottom)

    def _maybe_scroll(self):
        if self._auto_scroll:
            QTimer.singleShot(30, self._scroll_to_bottom)

    def _scroll_to_bottom(self):
        sb = self._scroll.verticalScrollBar()
        sb.setValue(sb.maximum())
        self._scroll_btn.hide(); self._auto_scroll = True

    def append_log(self, text: str):
        tl = text.strip()
        if tl.lower().startswith(("zero_two:", "zero two:")):
            self._sig.emit(tl.split(":", 1)[1].strip(), True)
        elif tl.lower().startswith("you:"):
            self._sig.emit(tl.split(":", 1)[1].strip(), False)
        else:
            self._sig.emit(tl, True)

    def start_typing(self):
        if self._typing_row: return
        row = QHBoxLayout(); row.setContentsMargins(0,0,0,0)
        dots = TypingDots(self._container)
        row.addWidget(dots); row.addStretch()
        self._vlay.insertLayout(self._vlay.count()-1, row)
        self._typing_row = row; self._typing_widget = dots
        self._maybe_scroll()

    def stop_typing(self):
        if not self._typing_row: return
        while self._typing_row.count():
            item = self._typing_row.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        idx = self._vlay.indexOf(self._typing_row)
        if idx >= 0: self._vlay.removeItem(self._typing_row)
        self._typing_row = None; self._typing_widget = None

    def _add_bubble(self, text: str, is_zero_two: bool):
        self.stop_typing()
        row = QHBoxLayout(); row.setContentsMargins(0,0,0,0); row.setSpacing(6)
        bubble = QLabel()
        bubble.setWordWrap(True); bubble.setMaximumWidth(310)
        bubble.setFont(QFont("Segoe UI", 9) if _OS == "Windows" else QFont("Arial", 9))
        bubble.setTextFormat(Qt.TextFormat.RichText)
        bubble.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        if is_zero_two:
            bubble.setText(_md_to_html(text))
            bubble.setStyleSheet(f"""
                color:{C.WHITE}; background:rgba(30,6,12,210);
                border:1px solid {C.BORDER_G}; border-left:2px solid {C.GREEN};
                border-radius:12px; padding:10px 14px; line-height:1.5;
            """)
            row.addWidget(bubble); row.addStretch()
        else:
            bubble.setText(text)
            bubble.setStyleSheet(f"""
                color:{C.WHITE}; background:rgba(50,10,20,200);
                border:1px solid {C.BORDER_A}; border-right:2px solid {C.TEAL};
                border-radius:12px; padding:10px 14px;
            """)
            row.addStretch(); row.addWidget(bubble)
        self._vlay.insertLayout(self._vlay.count()-1, row)
        self._maybe_scroll()
        if not is_zero_two and text:
            if text not in self._command_history:
                self._command_history.insert(0, text)
                if len(self._command_history) > 30: self._command_history.pop()

    def stream_ai_response(self, full_text: str):
        """Reveal AI response character by character with a typing cursor."""
        self.stop_typing()
        row = QHBoxLayout(); row.setContentsMargins(0,0,0,0)
        lbl = QLabel()
        lbl.setWordWrap(True); lbl.setMaximumWidth(300)
        lbl.setFont(QFont("Courier New", 8))
        lbl.setTextFormat(Qt.TextFormat.RichText)
        lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        lbl.setStyleSheet(f"""
            color:{C.WHITE}; background:rgba(30,6,12,210);
            border:1px solid {C.BORDER_G}; border-left:2px solid {C.GREEN};
            border-radius:12px; padding:10px 14px;
        """)
        row.addWidget(lbl); row.addStretch()
        self._vlay.insertLayout(self._vlay.count()-1, row)
        self._streaming_label = lbl
        self._streaming_full = full_text
        self._stream_chars_shown = 0
        t = QTimer(self); t.setInterval(10); self._stream_timer = t
        def _reveal():
            if self._stream_chars_shown >= len(self._streaming_full):
                t.stop()
                self._streaming_label.setText(_md_to_html(self._streaming_full))
                self._streaming_label = None; self._streaming_full = ""; return
            self._stream_chars_shown = min(self._stream_chars_shown+5, len(self._streaming_full))
            chunk = self._streaming_full[:self._stream_chars_shown]
            self._streaming_label.setText(_md_to_html(chunk) + '<span style="color:#e8386a;">|</span>')
            self._maybe_scroll()
        t.timeout.connect(_reveal); t.start()

# -- Screen Feed --------------------------------------------------------------------
class ScreenFeedWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._active = False; self._mode = "screen"; self.setFixedHeight(200)
        lay = QVBoxLayout(self); lay.setContentsMargins(0,0,0,0); lay.setSpacing(4)
        hdr = QHBoxLayout()
        self._title = QLabel("o  OPTICS OFFLINE")
        self._title.setFont(QFont("Courier New",7,QFont.Weight.Bold))
        self._title.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;letter-spacing:1px;")
        hdr.addWidget(self._title); hdr.addStretch()
        eb = QPushButton("[+]"); eb.setFixedSize(28,18); eb.setFlat(True)
        eb.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;font-size:8px;"); hdr.addWidget(eb)
        lay.addLayout(hdr)
        self._canvas = _FeedCanvas(self); lay.addWidget(self._canvas, stretch=1)
        self._timer = QTimer(self); self._timer.timeout.connect(self._refresh)

    def start(self, mode="screen"):
        self._mode = mode; self._active = True
        try: self._monitor_idx = int(mode.split(":")[1])
        except Exception: self._monitor_idx = 1
        label = "CAMERA FEED" if mode == "camera" else "SCREEN FEED"
        self._title.setText(f"* {label}")
        self._title.setStyleSheet(f"color:{C.GREEN};background:transparent;")
        self._timer.start(500)

    def stop(self):
        self._active = False; self._timer.stop(); self._release_camera()
        self._title.setText("o OPTICS OFFLINE")
        self._title.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;")
        self._canvas.update()

    def _refresh(self):
        if not self._active: self._canvas.update(); return
        from PyQt6.QtGui import QImage, QPixmap
        if self._mode.startswith("screen"):
            try:
                import mss, numpy as np
                mon_idx = getattr(self,"_monitor_idx",1)
                with mss.mss() as sct:
                    monitors = sct.monitors; idx = min(mon_idx, len(monitors)-1)
                    img = sct.grab(monitors[idx] if idx > 0 else monitors[1])
                # mss returns BGRA byte order. Qt's Format_RGB32/ARGB32 are
                # stored as BGRA in memory on little-endian systems, so that
                # format (not RGBA8888) gives correct colors here.
                arr = np.array(img, dtype=np.uint8)  # already (h, w, 4) BGRA, owns its memory
                qi = QImage(arr.data, arr.shape[1], arr.shape[0],
                             arr.strides[0], QImage.Format.Format_RGB32)
                # .copy() detaches the QImage from `arr`'s buffer entirely --
                # without this, `arr` (and the memory QImage points at) gets
                # garbage-collected once _refresh() returns, and the next
                # paintEvent reads freed memory -> intermittent crash.
                self._canvas._pixmap = QPixmap.fromImage(qi.copy())
            except Exception as e:
                print(f"[ScreenFeed] capture error: {e}")
                self._canvas._pixmap = None
        elif self._mode == "camera":
            try:
                import cv2, numpy as np
                if not hasattr(self,"_cap") or self._cap is None: self._cap = cv2.VideoCapture(0)
                ret, frame = self._cap.read()
                if ret:
                    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    frame = np.ascontiguousarray(frame)  # ensure owned, contiguous memory
                    h, w, ch = frame.shape
                    qi = QImage(frame.data, w, h, ch*w, QImage.Format.Format_RGB888)
                    # Same dangling-buffer fix as the screen path: copy()
                    # before `frame` goes out of scope and gets freed.
                    self._canvas._pixmap = QPixmap.fromImage(qi.copy())
                else: self._canvas._pixmap = None
            except Exception as e:
                print(f"[ScreenFeed] camera error: {e}")
                self._canvas._pixmap = None
        self._canvas.update()

    def _release_camera(self):
        if hasattr(self,"_cap") and self._cap is not None:
            try: self._cap.release()
            except Exception: pass
            self._cap = None

class _FeedCanvas(QWidget):
    def __init__(self, parent): super().__init__(parent); self._pixmap = None
    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), qcol(C.CARD)); W, H = self.width(), self.height(); z = self.parent()
        if z._active and self._pixmap:
            s = self._pixmap.scaled(W, H, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            p.drawPixmap((W-s.width())//2, (H-s.height())//2, s)
        else:
            p.setPen(QPen(qcol(C.BORDER_G),1)); p.drawRect(QRectF(1,1,W-2,H-2))
            p.setFont(QFont("Courier New",7)); p.setPen(QPen(qcol(C.TEXT_DIM),1))
            p.drawText(QRectF(0,0,W,H), Qt.AlignmentFlag.AlignCenter, "NO SIGNAL" if not z._active else "LOADING...")


# -- Vision Source Dialog ---------------------------------------------------------
class VisionSourceDialog(QDialog):
    source_chosen = pyqtSignal(str)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint|Qt.WindowType.Dialog)
        self.setModal(True)
        self.setStyleSheet(f"QDialog{{background:{C.PANEL};border:1px solid {C.GREEN_D};border-radius:8px;}}")
        lay = QVBoxLayout(self); lay.setContentsMargins(16,14,16,14); lay.setSpacing(10)
        hdr = QHBoxLayout()
        title = QLabel("ZERO TWO VISION -- SELECT INPUT SOURCE")
        title.setFont(QFont("Courier New",8,QFont.Weight.Bold))
        title.setStyleSheet(f"color:{C.GREEN};background:transparent;")
        hdr.addWidget(title); hdr.addStretch()
        xb = QPushButton("X"); xb.setFixedSize(18,18); xb.setFlat(True)
        xb.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;"); xb.clicked.connect(self.reject)
        hdr.addWidget(xb); lay.addLayout(hdr)
        monitors = self._detect_monitors()
        sources = [("CAM","CAMERA\nFEED","camera")]
        for i, m in enumerate(monitors):
            sources.append(("DSP", f"MONITOR {i+1}\n{m['width']}x{m['height']}", f"screen:{i+1}"))
        cols = min(3, len(sources)); grid = QGridLayout(); grid.setSpacing(8)
        for idx, (icon, label, key) in enumerate(sources):
            btn = QWidget(); btn.setFixedSize(100,80)
            btn.setStyleSheet(f"QWidget{{background:{C.CARD};border:1px solid {C.BORDER_G};border-radius:6px;}}QWidget:hover{{border:1px solid {C.GREEN};background:{C.GREEN_GHO};}}")
            bl = QVBoxLayout(btn); bl.setContentsMargins(4,8,4,8); bl.setSpacing(2)
            ic = QLabel(icon); ic.setFont(QFont("Courier New",12,QFont.Weight.Bold))
            ic.setStyleSheet(f"background:transparent;color:{C.GREEN};"); ic.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lbl = QLabel(label); lbl.setFont(QFont("Courier New",6,QFont.Weight.Bold))
            lbl.setStyleSheet(f"color:{C.TEXT};background:transparent;"); lbl.setAlignment(Qt.AlignmentFlag.AlignCenter); lbl.setWordWrap(True)
            bl.addWidget(ic); bl.addWidget(lbl)
            def _mc(k): return lambda e: (self.source_chosen.emit(k), self.accept())
            btn.mousePressEvent = _mc(key)
            grid.addWidget(btn, idx//cols, idx%cols)
        lay.addLayout(grid)
        hint = QLabel("SELECT INPUT SOURCE FOR NEURAL PROCESSING")
        hint.setFont(QFont("Courier New",6)); hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hint.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;"); lay.addWidget(hint)
        self.adjustSize()

    def _detect_monitors(self):
        try:
            import mss
            with mss.mss() as sct:
                return [{"width":m["width"],"height":m["height"]} for m in sct.monitors[1:]]
        except Exception: pass
        return [{"width":s.geometry().width(),"height":s.geometry().height()} for s in QApplication.screens()]


# -- Network Widget -----------------------------------------------------------------
class NetworkWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent); self.setFixedHeight(100)
        lay = QVBoxLayout(self); lay.setContentsMargins(8,6,8,6); lay.setSpacing(4)
        self.setStyleSheet(f"background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 {C.CARD2},stop:1 {C.CARD});border:1px solid {C.BORDER_G};border-radius:8px;")
        hdr = QHBoxLayout()
        icon = QLabel("NET"); icon.setFont(QFont("Courier New",8,QFont.Weight.Bold)); icon.setStyleSheet(f"color:{C.GREEN};background:transparent;")
        title = QLabel("NETWORK TELEMETRY"); title.setFont(QFont("Courier New",7,QFont.Weight.Bold)); title.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;")
        self._badge = QLabel("SECURE UPLINK"); self._badge.setFont(QFont("Courier New",6,QFont.Weight.Bold))
        self._badge.setStyleSheet(f"color:{C.BG};background:{C.GREEN};border-radius:3px;padding:1px 5px;")
        hdr.addWidget(icon); hdr.addWidget(title); hdr.addStretch(); hdr.addWidget(self._badge); lay.addLayout(hdr)
        grid = QGridLayout(); grid.setSpacing(4); grid.setContentsMargins(0,0,0,0)
        def _mk(label):
            l = QLabel(label); l.setFont(QFont("Courier New",6)); l.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;")
            v = QLabel("--"); v.setFont(QFont("Courier New",9,QFont.Weight.Bold)); v.setStyleSheet(f"color:{C.WHITE};background:transparent;")
            return l, v
        ll, self._lat_lbl = _mk("WSS LATENCY")
        pl, self._pkt_lbl = _mk("PACKET RATE")
        rl, self._rte_lbl = _mk("ROUTING")
        self._rte_lbl.setText("GLOBAL")
        grid.addWidget(ll,0,0); grid.addWidget(self._lat_lbl,1,0)
        grid.addWidget(pl,0,1); grid.addWidget(self._pkt_lbl,1,1)
        grid.addWidget(rl,0,2); grid.addWidget(self._rte_lbl,1,2)
        lay.addLayout(grid)
        br = QHBoxLayout(); br.setSpacing(4)
        def _bar():
            b = QProgressBar(); b.setFixedHeight(3); b.setTextVisible(False); return b
        self._dl_bar = _bar(); self._dl_bar.setStyleSheet(f"QProgressBar{{background:{C.BAR_BG};border:none;border-radius:1px;}}QProgressBar::chunk{{background:{C.GREEN};border-radius:1px;}}")
        self._ul_bar = _bar(); self._ul_bar.setStyleSheet(f"QProgressBar{{background:{C.BAR_BG};border:none;border-radius:1px;}}QProgressBar::chunk{{background:{C.TEAL};border-radius:1px;}}")
        br.addWidget(self._dl_bar); br.addWidget(self._ul_bar); lay.addLayout(br)
        t = QTimer(self); t.timeout.connect(self._refresh); t.start(2000); self._refresh()

    def _refresh(self):
        try:
            mon = None
            try:
                from system_monitor import get_monitor; mon = get_monitor()
            except Exception: pass
            if mon:
                snap = mon.snapshot()
                dl = getattr(snap,"net_recv_mbps",0); ul = getattr(snap,"net_sent_mbps",0)
                self._lat_lbl.setText(f"D{dl*1024:.0f}KB/s" if dl<1 else f"D{dl:.1f}MB/s")
                self._pkt_lbl.setText(f"U{ul*1024:.0f}KB/s" if ul<1 else f"U{ul:.1f}MB/s")
                self._dl_bar.setValue(min(100,int(dl*20))); self._ul_bar.setValue(min(100,int(ul*20)))
                total = dl+ul
                if total > 0.1:
                    self._badge.setStyleSheet(f"color:{C.BG};background:{C.GREEN};border-radius:3px;padding:1px 5px;"); self._badge.setText("ACTIVE")
                else:
                    self._badge.setStyleSheet(f"color:{C.TEXT_DIM};background:{C.CARD};border:1px solid {C.BORDER};border-radius:3px;padding:1px 5px;"); self._badge.setText("IDLE")
            else:
                snap = _metrics.snapshot(); net = snap.get("net",0)
                self._lat_lbl.setText(f"{net:.2f} MB/s"); self._dl_bar.setValue(min(100,int(net*20)))
        except Exception: pass


# -- Core Metrics Widget ------------------------------------------------------------
class CoreMetricsWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self); lay.setContentsMargins(6,6,6,6); lay.setSpacing(6)
        hdr = QHBoxLayout()
        title = QLabel("=  SYSTEM METRICS"); title.setFont(QFont("Courier New",8,QFont.Weight.Bold)); title.setStyleSheet(f"color:{C.GREEN};background:transparent;letter-spacing:1px;")
        self._live_dot = QLabel("* LIVE"); self._live_dot.setFont(QFont("Courier New",6,QFont.Weight.Bold)); self._live_dot.setStyleSheet(f"color:{C.GREEN};background:transparent;")
        self._live_ts  = QLabel("--:--:--"); self._live_ts.setFont(QFont("Courier New",6)); self._live_ts.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;")
        hdr.addWidget(title); hdr.addStretch(); hdr.addWidget(self._live_ts); hdr.addSpacing(6); hdr.addWidget(self._live_dot)
        lay.addLayout(hdr)
        grid = QGridLayout(); grid.setSpacing(6); grid.setContentsMargins(0,0,0,0)
        self._sysmon = None
        try:
            from system_monitor import get_monitor; self._sysmon = get_monitor()
        except Exception: pass
        self._cards = {}
        for idx, (key, label, color) in enumerate([("cpu","CPU LOAD",C.GREEN),("mem","RAM USAGE",C.TEAL),("tmp","CPU TEMP",C.ORANGE),("gpu","GPU","#7c3aed")]):
            card = self._make_card(key, label, color); self._cards[key] = card; grid.addWidget(card, idx//2, idx%2)
        lay.addLayout(grid)
        strip = QHBoxLayout(); strip.setSpacing(8)
        self._disk_lbl = QLabel("DISK  --"); self._disk_lbl.setFont(QFont("Courier New",7)); self._disk_lbl.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;")
        self._net_lbl  = QLabel("NET  --");  self._net_lbl.setFont(QFont("Courier New",7));  self._net_lbl.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;")
        strip.addWidget(self._disk_lbl); strip.addStretch(); strip.addWidget(self._net_lbl); lay.addLayout(strip)
        t = QTimer(self); t.timeout.connect(self._refresh); t.start(1500); self._refresh()

    def _make_card(self, key, label, color):
        w = QWidget()
        w.setStyleSheet(f"background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 {C.CARD2},stop:1 {C.CARD});border:1px solid {C.BORDER_G};border-radius:8px;")
        w.setFixedHeight(114); cl = QVBoxLayout(w); cl.setContentsMargins(8,6,8,6); cl.setSpacing(3)
        lbl = QLabel(label); lbl.setFont(QFont("Courier New",6,QFont.Weight.Bold)); lbl.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;")
        val = QLabel("--"); val.setFont(QFont("Courier New",14,QFont.Weight.Bold)); val.setStyleSheet(f"color:{C.WHITE};background:transparent;")
        spark = Sparkline(color)
        bar = QProgressBar(); bar.setFixedHeight(3); bar.setTextVisible(False)
        bar.setStyleSheet(f"QProgressBar{{background:{C.BAR_BG};border:none;border-radius:1px;}}QProgressBar::chunk{{background:{color};border-radius:1px;}}")
        cl.addWidget(lbl); cl.addWidget(val); cl.addWidget(spark); cl.addWidget(bar)
        w._val = val; w._spark = spark; w._bar = bar; return w

    def _refresh(self):
        try:
            sm = None
            if self._sysmon:
                try: sm = self._sysmon.snapshot()
                except Exception: pass
            lg = _metrics.snapshot()
            cpu = sm.cpu if sm else lg.get("cpu",0)
            c = self._cards["cpu"]; c._val.setText(f"{cpu:.1f}%"); c._bar.setValue(int(cpu)); c._spark.update_data(lg.get("cpu_hist",[cpu]))
            ram = sm.ram if sm else lg.get("mem",0)
            m = self._cards["mem"]; m._val.setText(f"{ram:.1f}%"); m._bar.setValue(int(ram)); m._spark.update_data(lg.get("mem_hist",[ram]))
            tmp = sm.temp if sm else -1.0
            if tmp < 0:
                # system_monitor had no reading (or returned -1) -- try the
                # independent _SysMetrics probe as a second opinion before
                # giving up. Different sensor-name lists / WMI paths mean
                # one of the two often succeeds even when the other fails.
                tmp = lg.get("tmp", -1)
            t = self._cards["tmp"]
            if tmp >= 0:
                col = C.GREEN if tmp<60 else (C.YELLOW if tmp<80 else C.RED)
                t._val.setText(f"{tmp:.0f}C"); t._val.setStyleSheet(f"color:{col};background:transparent;"); t._bar.setValue(min(100,int(tmp)))
            else:
                t._val.setText("N/A"); t._val.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;"); t._bar.setValue(0)
            g = self._cards.get("gpu")
            if g and sm and sm.gpu_usage >= 0:
                gp = sm.gpu_usage; gc = C.GREEN if gp<60 else (C.YELLOW if gp<85 else C.RED)
                g._val.setText(f"{gp:.0f}%"); g._val.setStyleSheet(f"color:{gc};background:transparent;"); g._bar.setValue(int(gp))
            elif g:
                g._val.setText("N/A"); g._val.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;"); g._bar.setValue(0)
            if sm and hasattr(sm,"disk_pct"):
                dp = sm.disk_pct; dc = C.RED if dp>90 else (C.YELLOW if dp>75 else C.TEXT_MED)
                self._disk_lbl.setText(f"DISK  {sm.disk_used_gb:.0f}/{sm.disk_total_gb:.0f} GB  ({dp:.0f}%)")
                self._disk_lbl.setStyleSheet(f"color:{dc};background:transparent;")
            if sm and hasattr(sm,"net_sent_mbps"):
                dl = sm.net_recv_mbps; ul = sm.net_sent_mbps
                self._net_lbl.setText(f"D{dl:.1f}  U{ul:.1f} MB/s")
            self._live_ts.setText(time.strftime("%H:%M:%S"))
            on = (int(time.time()*2) % 2) == 0
            self._live_dot.setStyleSheet(f"color:{C.GREEN if on else C.GREEN_DIM};background:transparent;")
        except Exception: pass


# -- Agent Card -----------------------------------------------------------------------
class AgentCard(QWidget):
    def __init__(self, name, role, parent=None):
        super().__init__(parent)
        self._name = name; self._role = role; self._status = "idle"; self._msg = "Standby"
        self.setFixedHeight(52)
        self.setStyleSheet(f"background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {C.CARD2},stop:1 {C.CARD});border:1px solid {C.BORDER_G};border-radius:6px;")
        lay = QHBoxLayout(self); lay.setContentsMargins(8,4,8,4); lay.setSpacing(8)
        self._dot = QLabel("*"); self._dot.setFixedWidth(12); self._dot.setFont(QFont("Courier New",9,QFont.Weight.Bold))
        info = QVBoxLayout(); info.setSpacing(1)
        self._nlbl = QLabel(name); self._nlbl.setFont(QFont("Courier New",7,QFont.Weight.Bold)); self._nlbl.setStyleSheet(f"color:{C.WHITE};background:transparent;")
        self._mlbl = QLabel(self._msg); self._mlbl.setFont(QFont("Courier New",6)); self._mlbl.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;")
        info.addWidget(self._nlbl); info.addWidget(self._mlbl)
        lay.addWidget(self._dot); lay.addLayout(info, stretch=1)
        self._slbl = QLabel("IDLE"); self._slbl.setFont(QFont("Courier New",6,QFont.Weight.Bold))
        self._slbl.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignVCenter)
        lay.addWidget(self._slbl); self._refresh()

    def update_status(self, status, msg=""):
        self._status = status
        if msg: self._msg = msg
        self._refresh()

    def _refresh(self):
        col = {"idle":C.TEXT_DIM,"working":C.GREEN,"done":C.TEAL,"error":C.RED}.get(self._status, C.TEXT_DIM)
        self._dot.setStyleSheet(f"color:{col};background:transparent;")
        self._slbl.setText(self._status.upper()); self._slbl.setStyleSheet(f"color:{col};background:transparent;")
        self._mlbl.setText(self._msg)

# -- Memory Viewer (NEW) -------------------------------------------------------------
class MemoryViewerWidget(QWidget):
    """Live viewer and editor for long_term.json."""
    def __init__(self, parent=None):
        super().__init__(parent); self.setStyleSheet(f"background:{C.NAVY};")
        lay = QVBoxLayout(self); lay.setContentsMargins(10,10,10,10); lay.setSpacing(8)
        hdr = QHBoxLayout()
        title = QLabel("MEMORY BANK"); title.setFont(QFont("Courier New",9,QFont.Weight.Bold)); title.setStyleSheet(f"color:{C.GREEN};background:transparent;")
        self._count_lbl = QLabel(""); self._count_lbl.setFont(QFont("Courier New",7)); self._count_lbl.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;")
        rb = QPushButton("Reload"); rb.setFixedHeight(24); rb.setFont(QFont("Courier New",7,QFont.Weight.Bold)); rb.setCursor(Qt.CursorShape.PointingHandCursor)
        rb.setStyleSheet(f"QPushButton{{background:{C.GREEN_GHO};color:{C.GREEN};border:1px solid {C.GREEN_D};border-radius:3px;padding:1px 8px;}}QPushButton:hover{{background:{C.PANEL};}}")
        rb.clicked.connect(self._load)
        hdr.addWidget(title); hdr.addStretch(); hdr.addWidget(self._count_lbl); hdr.addSpacing(6); hdr.addWidget(rb); lay.addLayout(hdr)
        cat_row = QHBoxLayout()
        cl = QLabel("Category:"); cl.setFont(QFont("Courier New",7)); cl.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;")
        self._cat = QComboBox(); self._cat.addItems(["All","identity","preferences","projects","relationships","wishes","notes"])
        self._cat.setFixedHeight(24); self._cat.setFont(QFont("Courier New",7))
        self._cat.setStyleSheet(f"QComboBox{{background:{C.CARD};color:{C.WHITE};border:1px solid {C.BORDER_G};border-radius:3px;padding:1px 4px;}}QComboBox QAbstractItemView{{background:{C.PANEL};color:{C.WHITE};}}")
        self._cat.currentTextChanged.connect(self._load)
        cat_row.addWidget(cl); cat_row.addWidget(self._cat, stretch=1); lay.addLayout(cat_row)
        self._table = QTableWidget(0, 3)
        self._table.setHorizontalHeaderLabels(["Category","Key","Value"])
        self._table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self._table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self._table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self._table.horizontalHeader().setStyleSheet(f"QHeaderView::section{{background:{C.PANEL};color:{C.GREEN};font-family:'Courier New';font-size:7pt;border:none;padding:3px;}}")
        self._table.setStyleSheet(f"""
            QTableWidget{{background:{C.CARD};color:{C.TEXT};border:1px solid {C.BORDER_G};
                          border-radius:4px;gridline-color:{C.BORDER};font-family:'Courier New';font-size:8pt;}}
            QTableWidget::item{{padding:4px;}}
            QTableWidget::item:selected{{background:{C.GREEN_GHO};color:{C.GREEN};}}
            QScrollBar:vertical{{background:{C.BG};width:4px;border:none;}}
            QScrollBar::handle:vertical{{background:{C.BORDER_G};border-radius:2px;}}
        """)
        self._table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setEditTriggers(QAbstractItemView.EditTrigger.DoubleClicked)
        self._table.verticalHeader().hide()
        self._table.itemChanged.connect(self._on_edit)
        lay.addWidget(self._table, stretch=1)
        db = QPushButton("X Delete selected"); db.setFixedHeight(26); db.setFont(QFont("Courier New",7,QFont.Weight.Bold)); db.setCursor(Qt.CursorShape.PointingHandCursor)
        db.setStyleSheet(f"QPushButton{{background:{C.CARD};color:{C.RED};border:1px solid {C.RED};border-radius:3px;padding:1px 8px;}}QPushButton:hover{{background:{C.PANEL};}}")
        db.clicked.connect(self._delete_selected); lay.addWidget(db)
        hint = QLabel("Double-click Value to edit  |  Changes save immediately")
        hint.setFont(QFont("Courier New",6)); hint.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;"); lay.addWidget(hint)
        self._editing = False; self._load()

    def _load(self):
        self._editing = True
        try: data = json.loads(MEMORY_FILE.read_text(encoding="utf-8")) if MEMORY_FILE.exists() else {}
        except Exception: data = {}
        self._table.setRowCount(0); sel = self._cat.currentText(); count = 0
        for cat, entries in data.items():
            if not isinstance(entries, dict): continue
            if sel != "All" and cat != sel: continue
            for key, entry in entries.items():
                val = entry.get("value","") if isinstance(entry, dict) else str(entry)
                row = self._table.rowCount(); self._table.insertRow(row)
                ci = QTableWidgetItem(cat); ci.setFlags(ci.flags() & ~Qt.ItemFlag.ItemIsEditable); ci.setForeground(QColor(C.TEXT_DIM))
                ki = QTableWidgetItem(key); ki.setFlags(ki.flags() & ~Qt.ItemFlag.ItemIsEditable); ki.setForeground(QColor(C.TEAL))
                vi = QTableWidgetItem(str(val))
                self._table.setItem(row,0,ci); self._table.setItem(row,1,ki); self._table.setItem(row,2,vi)
                count += 1
        self._count_lbl.setText(f"{count} entries"); self._editing = False

    def _on_edit(self, item: QTableWidgetItem):
        if self._editing or item.column() != 2: return
        row = item.row()
        ci = self._table.item(row,0); ki = self._table.item(row,1)
        if not ci or not ki: return
        cat = ci.text(); key = ki.text(); val = item.text()
        try:
            data = json.loads(MEMORY_FILE.read_text(encoding="utf-8")) if MEMORY_FILE.exists() else {}
            if cat in data and key in data[cat]:
                if isinstance(data[cat][key], dict): data[cat][key]["value"] = val
                else: data[cat][key] = val
                MEMORY_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception as e: print(f"[MemoryViewer] save error: {e}")

    def _delete_selected(self):
        rows = {idx.row() for idx in self._table.selectedIndexes()}
        if not rows: return
        try:
            data = json.loads(MEMORY_FILE.read_text(encoding="utf-8")) if MEMORY_FILE.exists() else {}
            for row in sorted(rows, reverse=True):
                ci = self._table.item(row,0); ki = self._table.item(row,1)
                if ci and ki and ci.text() in data and ki.text() in data[ci.text()]:
                    del data[ci.text()][ki.text()]
            MEMORY_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception as e: print(f"[MemoryViewer] delete error: {e}")
        self._load()


# -- Command Palette (Ctrl+K) --------------------------------------------------------
class CommandPalette(QDialog):
    command_selected = pyqtSignal(str)

    BUILT_IN = [
        ("status check",              "Status Check",          "Show full system stats"),
        ("all agents report",         "Agents Report",         "Show all agent statuses"),
        ("which model are you using", "Which Model",           "Show active AI provider"),
        ("api status",                "API Status",            "Show provider health"),
        ("start screen monitor",      "Start Screen Monitor",  "Watch screen continuously"),
        ("stop screen monitor",       "Stop Screen Monitor",   "Stop watching screen"),
        ("hey zero two",              "Wake Zero Two",         "Activate assistant"),
        ("go to sleep",               "Sleep Mode",            "Enter sleep mode"),
        ("open chrome",               "Open Chrome",           "Launch Chrome browser"),
        ("open spotify",              "Open Spotify",          "Launch Spotify"),
        ("weather today",             "Weather Today",         "Get current weather"),
        ("switch to gemini",          "Switch -> Gemini",      "Use Gemini provider"),
        ("switch to openai",          "Switch -> OpenAI",      "Use OpenAI provider"),
        ("switch to anthropic",       "Switch -> Anthropic",   "Use Claude provider"),
        ("godmode what can you do",   "GodMode Query",         "Query all providers at once"),
        ("security check",            "Security Check",        "Run security audit"),
        ("open task manager",         "Task Manager",          "Open task manager"),
    ]

    def __init__(self, recent: list, parent=None):
        super().__init__(parent); self._recent = recent
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint|Qt.WindowType.Dialog)
        self.setModal(True); self.setFixedWidth(560)
        self.setStyleSheet(f"QDialog{{background:{C.PANEL};border:1px solid {C.GREEN_D};border-radius:10px;}}")
        lay = QVBoxLayout(self); lay.setContentsMargins(16,16,16,16); lay.setSpacing(8)

        self._search = QLineEdit()
        self._search.setPlaceholderText("  Search commands or type anything...")
        self._search.setFont(QFont("Courier New",10)); self._search.setFixedHeight(40)
        self._search.setStyleSheet(f"""
            QLineEdit{{background:{C.CARD};color:{C.WHITE};
                      border:1px solid {C.GREEN_D};border-radius:6px;padding:4px 14px;}}
            QLineEdit:focus{{border:1px solid {C.GREEN};}}
        """)
        self._search.textChanged.connect(self._filter)
        self._search.returnPressed.connect(self._accept_top)
        lay.addWidget(self._search)

        self._section_lbl = QLabel("QUICK ACTIONS")
        self._section_lbl.setFont(QFont("Courier New",6,QFont.Weight.Bold))
        self._section_lbl.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;letter-spacing:1px;")
        lay.addWidget(self._section_lbl)

        self._list = QListWidget(); self._list.setFixedHeight(300)
        self._list.setStyleSheet(f"""
            QListWidget{{background:transparent;border:none;outline:none;}}
            QListWidget::item{{background:{C.CARD};border:1px solid {C.BORDER_G};
                               border-radius:6px;margin-bottom:3px;padding:6px 10px;}}
            QListWidget::item:selected{{background:{C.GREEN_GHO};border:1px solid {C.GREEN_D};}}
            QListWidget::item:hover{{background:{C.GLASS_B};border:1px solid {C.BORDER_A};}}
            QScrollBar:vertical{{background:{C.BG};width:4px;border:none;}}
            QScrollBar::handle:vertical{{background:{C.BORDER_G};border-radius:2px;}}
        """)
        self._list.itemActivated.connect(self._on_item)
        lay.addWidget(self._list)

        hint = QLabel("Up/Down navigate  |  Enter to run  |  Esc to close")
        hint.setFont(QFont("Courier New",6)); hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hint.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;"); lay.addWidget(hint)
        self._populate(); self.adjustSize()

    def _populate(self, query=""):
        self._list.clear(); ql = query.lower().strip(); added = 0
        if not ql and self._recent:
            for cmd in self._recent[:5]:
                item = QListWidgetItem(f"<-  {cmd}"); item.setFont(QFont("Courier New",8)); item.setForeground(QColor(C.TEAL))
                item.setData(Qt.ItemDataRole.UserRole, cmd); self._list.addItem(item); added += 1
        for cmd, label, desc in self.BUILT_IN:
            if ql and ql not in label.lower() and ql not in cmd.lower() and ql not in desc.lower(): continue
            item = QListWidgetItem(f"{label}\n      {desc}"); item.setFont(QFont("Courier New",8))
            item.setForeground(QColor(C.TEXT)); item.setData(Qt.ItemDataRole.UserRole, cmd)
            self._list.addItem(item); added += 1
        if ql and added < 3:
            item = QListWidgetItem(f'>>  Run: "{query}"'); item.setFont(QFont("Courier New",8))
            item.setForeground(QColor(C.GREEN)); item.setData(Qt.ItemDataRole.UserRole, query)
            self._list.addItem(item)
        if self._list.count() > 0: self._list.setCurrentRow(0)

    def _filter(self, text):
        self._populate(text)
        self._section_lbl.setText("RESULTS" if text else "QUICK ACTIONS" + ("  |  RECENT" if self._recent else ""))

    def _accept_top(self):
        q = self._search.text().strip()
        if self._list.currentItem():
            cmd = self._list.currentItem().data(Qt.ItemDataRole.UserRole)
            self.command_selected.emit(cmd or q); self.accept()
        elif q:
            self.command_selected.emit(q); self.accept()

    def _on_item(self, item):
        cmd = item.data(Qt.ItemDataRole.UserRole)
        if cmd: self.command_selected.emit(cmd); self.accept()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Up:
            self._list.setCurrentRow(max(0, self._list.currentRow()-1))
        elif event.key() == Qt.Key.Key_Down:
            self._list.setCurrentRow(min(self._list.count()-1, self._list.currentRow()+1))
        elif event.key() == Qt.Key.Key_Escape: self.reject()
        else: super().keyPressEvent(event)

# -- Settings Panel ------------------------------------------------------------------
class SettingsPanel(QWidget):
    settings_saved = pyqtSignal(dict)

    @staticmethod
    def _fmt_interval(seconds: int) -> str:
        """Format seconds for the proactive check-in slider label."""
        if seconds < 60:
            return f"Every {seconds}s"
        m, s = divmod(seconds, 60)
        if s == 0:
            return f"Every {m}m"
        return f"Every {m}m {s}s"

    def __init__(self, parent=None):
        super().__init__(parent); self._s = load_settings()
        self.setStyleSheet(f"background:{C.NAVY};")
        # Use a scroll area so settings are accessible on smaller windows
        outer = QVBoxLayout(self); outer.setContentsMargins(0,0,0,0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet(f"QScrollArea{{background:transparent;border:none;}}QScrollBar:vertical{{background:{C.BG};width:4px;border:none;}}QScrollBar::handle:vertical{{background:{C.BORDER_G};border-radius:2px;}}")
        inner = QWidget(); inner.setStyleSheet(f"background:{C.NAVY};")
        lay = QVBoxLayout(inner); lay.setContentsMargins(16,16,16,16); lay.setSpacing(10)
        scroll.setWidget(inner); outer.addWidget(scroll)

        def sec(t):
            l=QLabel(t); l.setFont(QFont("Arial",8,QFont.Weight.Bold) if _OS=="Windows" else QFont("Arial",8,QFont.Weight.Bold))
            l.setStyleSheet(f"color:{C.GREEN};background:transparent;border-bottom:1px solid {C.BORDER_G};padding-bottom:3px;margin-top:4px;"); return l
        def rl(t):
            l=QLabel(t); l.setFont(QFont("Arial",8) if _OS=="Windows" else QFont("Arial",8)); l.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;"); return l
        def slider(val):
            s=QSlider(Qt.Orientation.Horizontal); s.setRange(0,100); s.setValue(val)
            s.setStyleSheet(
                f"QSlider::groove:horizontal{{background:{C.BAR_BG};height:5px;border-radius:3px;}}"
                f"QSlider::handle:horizontal{{background:{C.GREEN};width:14px;height:14px;margin:-5px 0;border-radius:7px;}}"
                f"QSlider::sub-page:horizontal{{background:{C.GREEN_D};border-radius:3px;}}"
            ); return s
        def key_input(ph):
            f=QLineEdit(); f.setEchoMode(QLineEdit.EchoMode.Password); f.setPlaceholderText(ph)
            f.setFont(QFont("Arial",8)); f.setFixedHeight(30)
            f.setStyleSheet(
                f"QLineEdit{{background:{C.CARD2};color:{C.WHITE};"
                f"border:1px solid {C.BORDER_G};border-radius:8px;padding:3px 10px;}}"
                f"QLineEdit:focus{{border:1px solid {C.GREEN};}}"
            ); return f
        def key_lbl(t):
            l=QLabel(t); l.setFont(QFont("Arial",7,QFont.Weight.Bold)); l.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;letter-spacing:1px;"); return l
        combo_ss = (
            f"QComboBox{{background:{C.CARD2};color:{C.WHITE};"
            f"border:1px solid {C.BORDER_G};border-radius:8px;padding:3px 8px;}}"
            f"QComboBox:hover{{border:1px solid {C.GREEN};}}"
            f"QComboBox QAbstractItemView{{background:{C.PANEL};color:{C.WHITE};"
            f"selection-background-color:{C.GREEN_GHO};}}"
        )

        lay.addWidget(sec("VOICE"))
        r=QHBoxLayout(); r.addWidget(rl("Voice"))
        self._voice=QComboBox(); self._voice.addItems(["Aoede","Kore","Puck","Charon","Fenrir"])
        self._voice.setCurrentText(self._s.get("voice","Aoede")); self._voice.setFixedHeight(26); self._voice.setStyleSheet(combo_ss)
        r.addWidget(self._voice); lay.addLayout(r)
        r2=QHBoxLayout(); self._vol_lbl=QLabel(f"Volume  {self._s.get('volume',80)}%")
        self._vol_lbl.setFont(QFont("Courier New",7)); self._vol_lbl.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;")
        self._vol=slider(self._s.get("volume",80)); self._vol.valueChanged.connect(lambda v: self._vol_lbl.setText(f"Volume  {v}%"))
        r2.addWidget(self._vol_lbl); r2.addWidget(self._vol); lay.addLayout(r2)
        r3=QHBoxLayout(); self._mic_lbl=QLabel(f"Mic  {self._s.get('mic_sensitivity',70)}%")
        self._mic_lbl.setFont(QFont("Courier New",7)); self._mic_lbl.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;")
        self._mic=slider(self._s.get("mic_sensitivity",70)); self._mic.valueChanged.connect(lambda v: self._mic_lbl.setText(f"Mic  {v}%"))
        r3.addWidget(self._mic_lbl); r3.addWidget(self._mic); lay.addLayout(r3)

        lay.addWidget(sec("BEHAVIOUR"))
        self._wake=QCheckBox("Wake word enabled (\"Hello Zero Two\")"); self._wake.setChecked(self._s.get("wake_word",True)); self._wake.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;"); lay.addWidget(self._wake)
        self._clap=QCheckBox("Clap to activate (clap twice)"); self._clap.setChecked(self._s.get("clap_activation",False)); self._clap.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;"); lay.addWidget(self._clap)
        crow=QHBoxLayout(); self._clap_lbl=QLabel(f"Clap sensitivity  {self._s.get('clap_sensitivity',60)}%")
        self._clap_lbl.setFont(QFont("Courier New",7)); self._clap_lbl.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;")
        self._clap_sens=slider(self._s.get("clap_sensitivity",60)); self._clap_sens.valueChanged.connect(lambda v: self._clap_lbl.setText(f"Clap sensitivity  {v}%"))
        crow.addWidget(self._clap_lbl); crow.addWidget(self._clap_sens); lay.addLayout(crow)
        clap_hint=QLabel("Higher = easier to trigger (more sensitive to quieter claps)")
        clap_hint.setFont(QFont("Arial",6)); clap_hint.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;padding-left:2px;"); lay.addWidget(clap_hint)

        lay.addWidget(sec("THEME"))
        theme_row = QHBoxLayout(); theme_row.setSpacing(6)
        self._theme_lbl = QLabel("Theme:")
        self._theme_lbl.setFont(QFont("Arial",7)); self._theme_lbl.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;")
        self._theme_combo = QComboBox()
        self._theme_combo.addItems(list(C.THEMES.keys()))
        self._theme_combo.setCurrentText(self._s.get("theme","Zero Two Classic"))
        self._theme_combo.setFixedHeight(28); self._theme_combo.setFont(QFont("Arial",8))
        self._theme_combo.setStyleSheet(
            f"QComboBox{{background:{C.CARD2};color:{C.WHITE};border:1px solid {C.BORDER_G};"
            f"border-radius:6px;padding:2px 8px;}}"
            f"QComboBox:hover{{border:1px solid {C.GREEN};}}"
            f"QComboBox QAbstractItemView{{background:{C.PANEL};color:{C.WHITE};"
            f"selection-background-color:{C.GREEN_GHO};}}"
        )
        self._theme_combo.currentTextChanged.connect(self._apply_theme_preview)
        theme_row.addWidget(self._theme_lbl); theme_row.addWidget(self._theme_combo, stretch=1)
        lay.addLayout(theme_row)
        theme_hint = QLabel("Theme change takes full effect on next restart.")
        theme_hint.setFont(QFont("Arial",6)); theme_hint.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;padding-left:2px;")
        lay.addWidget(theme_hint)

        lay.addWidget(sec("PROACTIVE"))
        self._proactive=QCheckBox("Proactive screen check-ins")
        self._proactive.setChecked(self._s.get("proactive_checkins",False))
        self._proactive.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;")
        lay.addWidget(self._proactive)
        prow=QHBoxLayout()
        _pint = self._s.get("proactive_interval",60)
        self._proactive_lbl=QLabel(self._fmt_interval(_pint))
        self._proactive_lbl.setFont(QFont("Courier New",7)); self._proactive_lbl.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;")
        self._proactive_sens=QSlider(Qt.Orientation.Horizontal); self._proactive_sens.setRange(20,300); self._proactive_sens.setValue(_pint)
        self._proactive_sens.setStyleSheet(f"QSlider::groove:horizontal{{background:{C.BAR_BG};height:4px;border-radius:2px;}}QSlider::handle:horizontal{{background:{C.GREEN};width:12px;height:12px;margin:-4px 0;border-radius:6px;}}QSlider::sub-page:horizontal{{background:{C.GREEN_D};border-radius:2px;}}")
        self._proactive_sens.valueChanged.connect(lambda v: self._proactive_lbl.setText(self._fmt_interval(v)))
        prow.addWidget(self._proactive_lbl); prow.addWidget(self._proactive_sens); lay.addLayout(prow)
        proactive_hint=QLabel("While active, Zero Two glances at your screen on this cadence. Mostly silent --\nonly speaks up for a likely bug/error, or a casual check-in if you've gone quiet a while.")
        proactive_hint.setFont(QFont("Courier New",6)); proactive_hint.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;padding-left:2px;")
        proactive_hint.setWordWrap(True); lay.addWidget(proactive_hint)

        lay.addWidget(sec("SECURITY"))
        lock_row = QHBoxLayout(); lock_row.setSpacing(8)
        self._lock_chk = QCheckBox("Require PIN on startup")
        self._lock_chk.setChecked(lock_is_enabled())
        self._lock_chk.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;")
        self._pin_btn = QPushButton("Set PIN" if not lock_pin_is_set() else "Change PIN")
        self._pin_btn.setFixedHeight(24); self._pin_btn.setFont(QFont("Courier New",7,QFont.Weight.Bold))
        self._pin_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._pin_btn.setStyleSheet(f"QPushButton{{background:{C.GREEN_GHO};color:{C.GREEN};border:1px solid {C.GREEN_D};border-radius:3px;padding:1px 8px;}}QPushButton:hover{{background:{C.PANEL};}}")
        lock_row.addWidget(self._lock_chk, stretch=1); lock_row.addWidget(self._pin_btn)
        lay.addLayout(lock_row)
        self._lock_status = QLabel("PIN set" if lock_pin_is_set() else "No PIN set yet")
        self._lock_status.setFont(QFont("Courier New",6))
        self._lock_status.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;padding-left:2px;")
        lay.addWidget(self._lock_status)

        def _open_pin_setup():
            dlg = LockScreenDialog(mode="setup", parent=self)
            if dlg.exec() == QDialog.DialogCode.Accepted:
                self._lock_chk.setChecked(True)
                self._pin_btn.setText("Change PIN")
                self._lock_status.setText("PIN set")
                self._lock_status.setStyleSheet(f"color:{C.GREEN};background:transparent;padding-left:2px;")
        self._pin_btn.clicked.connect(_open_pin_setup)

        def _on_lock_toggled(checked: bool):
            if checked and not lock_pin_is_set():
                # Enabling lock with no PIN set yet -> force setup first
                self._lock_chk.blockSignals(True); self._lock_chk.setChecked(False); self._lock_chk.blockSignals(False)
                _open_pin_setup()
                return
            if checked and lock_pin_is_set():
                set_lock_enabled(True)
                self._lock_status.setText("PIN set -- required on startup")
                self._lock_status.setStyleSheet(f"color:{C.GREEN};background:transparent;padding-left:2px;")
            else:
                set_lock_enabled(False)
                self._lock_status.setText("PIN saved but not required" if lock_pin_is_set() else "No PIN set yet")
                self._lock_status.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;padding-left:2px;")
        self._lock_chk.toggled.connect(_on_lock_toggled)

        vrow=QHBoxLayout(); vl=QLabel("Offline model:"); vl.setFont(QFont("Courier New",7)); vl.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;")
        self._vosk_status=QLabel(); self._vosk_status.setFont(QFont("Courier New",7,QFont.Weight.Bold))
        self._vosk_dl_btn=QPushButton("Download"); self._vosk_dl_btn.setFixedHeight(22); self._vosk_dl_btn.setFont(QFont("Courier New",6,QFont.Weight.Bold)); self._vosk_dl_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._vosk_dl_btn.setStyleSheet(f"QPushButton{{background:{C.GREEN_GHO};color:{C.GREEN};border:1px solid {C.GREEN_D};border-radius:3px;padding:1px 6px;}}QPushButton:hover{{background:{C.PANEL};}}")
        self._vosk_bar=QProgressBar(); self._vosk_bar.setFixedHeight(3); self._vosk_bar.setTextVisible(False)
        self._vosk_bar.setStyleSheet(f"QProgressBar{{background:{C.BAR_BG};border:none;border-radius:1px;}}QProgressBar::chunk{{background:{C.GREEN};border-radius:1px;}}"); self._vosk_bar.hide()
        vrow.addWidget(vl); vrow.addWidget(self._vosk_status,stretch=1); vrow.addWidget(self._vosk_dl_btn)
        lay.addLayout(vrow); lay.addWidget(self._vosk_bar)
        self._vosk_dl_btn.clicked.connect(self._download_vosk); self._refresh_vosk_status()
        self._automem=QCheckBox("Auto-save memory"); self._automem.setChecked(self._s.get("auto_memory",True)); self._automem.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;"); lay.addWidget(self._automem)
        self._autorun=QCheckBox("Auto-run commands"); self._autorun.setChecked(self._s.get("auto_run",False)); self._autorun.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;"); lay.addWidget(self._autorun)
        self._greet=QCheckBox("Startup greeting"); self._greet.setChecked(self._s.get("startup_greeting",True)); self._greet.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;"); lay.addWidget(self._greet)
        self._boot=QCheckBox("Start with Windows / OS boot")
        try:
            from autostart import is_enabled as _ae; self._boot.setChecked(_ae())
        except Exception: self._boot.setChecked(False)
        self._boot.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;"); lay.addWidget(self._boot)

        lay.addWidget(sec("AI MODEL"))
        pr=QHBoxLayout(); pr.addWidget(rl("Provider"))
        self._provider=QComboBox(); self._provider.setFixedHeight(26)
        for lbl2, key2 in [("Google Gemini","gemini"),("OpenAI GPT","openai"),("xAI Grok","xai"),("Anthropic Claude","anthropic")]:
            self._provider.addItem(lbl2, key2)
        self._provider.setStyleSheet(combo_ss); pr.addWidget(self._provider,stretch=1); lay.addLayout(pr)
        mr=QHBoxLayout(); mr.addWidget(rl("Model"))
        self._model=QComboBox(); self._model.setFixedHeight(26); self._model.setStyleSheet(combo_ss)
        mr.addWidget(self._model,stretch=1); lay.addLayout(mr)
        self._catalog={"gemini":[("gemini-2.5-flash","Gemini 2.5 Flash","Fastest"),("gemini-2.0-flash","Gemini 2.0 Flash","Stable"),("gemini-1.5-pro","Gemini 1.5 Pro","High reasoning")],"openai":[("gpt-4o","GPT-4o","Flagship"),("gpt-4o-mini","GPT-4o mini","Fast & cheap"),("gpt-4-turbo","GPT-4 Turbo","Very capable")],"xai":[("grok-2-latest","Grok 2","Real-time"),("grok-beta","Grok Beta","Experimental")],"anthropic":[("claude-3-5-sonnet","Claude 3.5 Sonnet","Strong writing"),("claude-3-5-haiku","Claude 3.5 Haiku","Fast & cheap")]}
        self._mhint=QLabel(""); self._mhint.setFont(QFont("Courier New",7)); self._mhint.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;padding-left:60px;"); self._mhint.setWordWrap(True); lay.addWidget(self._mhint)
        def _reload():
            prov=self._provider.currentData(); self._model.blockSignals(True); self._model.clear()
            for mid,lbl3,_ in self._catalog.get(prov,[]): self._model.addItem(lbl3,mid)
            self._model.blockSignals(False); _hint()
        def _hint():
            prov=self._provider.currentData(); mid=self._model.currentData()
            for m,_,d in self._catalog.get(prov,[]):
                if m==mid: self._mhint.setText(f"i  {d}"); return
            self._mhint.setText("")
        self._provider.currentIndexChanged.connect(_reload); self._model.currentIndexChanged.connect(_hint)
        _sv=self._s.get("ai_model","gemini-2.5-flash"); _sp="gemini"
        for _p,_it in self._catalog.items():
            if any(m==_sv for m,_,_ in _it): _sp=_p; break
        for i in range(self._provider.count()):
            if self._provider.itemData(i)==_sp: self._provider.setCurrentIndex(i); break
        _reload()
        for i in range(self._model.count()):
            if self._model.itemData(i)==_sv: self._model.setCurrentIndex(i); break
        _hint()

        lay.addWidget(sec("API KEYS"))
        lay.addWidget(key_lbl("GEMINI (primary)")); self._api=key_input("Gemini key -- AIza..."); lay.addWidget(self._api)
        lay.addWidget(key_lbl("OPENAI")); self._api_oai=key_input("OpenAI key -- sk-..."); lay.addWidget(self._api_oai)
        lay.addWidget(key_lbl("xAI / GROK")); self._api_xai=key_input("xAI key -- xai-..."); lay.addWidget(self._api_xai)
        lay.addWidget(key_lbl("ANTHROPIC")); self._api_ant=key_input("Anthropic key -- sk-ant-..."); lay.addWidget(self._api_ant)
        try:
            kd=json.loads(API_FILE.read_text(encoding="utf-8")) if API_FILE.exists() else {}
            if kd.get("gemini_api_key"):    self._api.setPlaceholderText("Gemini key loaded OK")
            if kd.get("openai_api_key"):    self._api_oai.setPlaceholderText("OpenAI key loaded OK")
            if kd.get("xai_api_key"):       self._api_xai.setPlaceholderText("xAI key loaded OK")
            if kd.get("anthropic_api_key"): self._api_ant.setPlaceholderText("Anthropic key loaded OK")
        except Exception: pass
        lay.addStretch()
        tr=QHBoxLayout()
        tb=QPushButton("Test Connection"); tb.setFixedHeight(28); tb.setFont(QFont("Courier New",7,QFont.Weight.Bold)); tb.setCursor(Qt.CursorShape.PointingHandCursor)
        tb.setStyleSheet(f"QPushButton{{background:{C.CARD};color:{C.TEXT_MED};border:1px solid {C.BORDER_G};border-radius:4px;}}QPushButton:hover{{color:{C.GREEN};border:1px solid {C.GREEN};}}")
        self._tres=QLabel(""); self._tres.setFont(QFont("Courier New",7)); self._tres.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;")
        tr.addWidget(tb); tr.addWidget(self._tres,stretch=1); lay.addLayout(tr)
        def _test():
            tb.setEnabled(False); self._tres.setText("Testing..."); self._tres.setStyleSheet(f"color:{C.YELLOW};background:transparent;")
            def _run():
                try:
                    from api_manager import test_provider, ProviderStatus
                    prov=self._provider.currentData(); model=self._model.currentData() or ""
                    ok,msg=test_provider(prov,model); col=C.GREEN if ok else C.RED
                    self._tres.setText(msg[:35]); self._tres.setStyleSheet(f"color:{col};background:transparent;")
                except Exception as e: self._tres.setText(f"Error: {str(e)[:30]}"); self._tres.setStyleSheet(f"color:{C.RED};background:transparent;")
                finally: tb.setEnabled(True)
            threading.Thread(target=_run,daemon=True).start()
        tb.clicked.connect(_test)
        sv=QPushButton("SAVE SETTINGS"); sv.setFixedHeight(34); sv.setFont(QFont("Courier New",8,QFont.Weight.Bold)); sv.setCursor(Qt.CursorShape.PointingHandCursor)
        sv.setStyleSheet(f"QPushButton{{background:{C.GREEN_GHO};color:{C.GREEN};border:1px solid {C.GREEN_D};border-radius:4px;}}QPushButton:hover{{background:{C.PANEL};border:1px solid {C.GREEN};}}")
        sv.clicked.connect(self._save); lay.addWidget(sv)

    def _apply_theme_preview(self, theme_name: str):
        """Immediately apply a colour accent preview to key widgets."""
        t = C.THEMES.get(theme_name, C.THEMES["Zero Two Classic"])
        acc  = t["accent"]
        acc2 = t["accent2"]
        # Update the combo border colour as a live preview cue
        self._theme_combo.setStyleSheet(
            f"QComboBox{{background:{C.CARD2};color:{C.WHITE};"
            f"border:1px solid {acc};border-radius:6px;padding:2px 8px;}}"
            f"QComboBox QAbstractItemView{{background:{C.PANEL};color:{C.WHITE};}}"
        )
        # Hint label reflects new accent
        self._theme_lbl.setStyleSheet(f"color:{acc2};background:transparent;")

    def _refresh_vosk_status(self):
        try:
            from vosk_setup import is_installed
            if is_installed(): self._vosk_status.setText("Installed"); self._vosk_status.setStyleSheet(f"color:{C.GREEN};background:transparent;"); self._vosk_dl_btn.setText("Reinstall")
            else: self._vosk_status.setText("Not installed"); self._vosk_status.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;"); self._vosk_dl_btn.setText("Download (~55MB)")
        except Exception: self._vosk_status.setText("vosk missing"); self._vosk_status.setStyleSheet(f"color:{C.RED};background:transparent;"); self._vosk_dl_btn.setText("pip install vosk"); self._vosk_dl_btn.setEnabled(False)

    def _download_vosk(self):
        self._vosk_bar.show(); self._vosk_bar.setValue(0); self._vosk_dl_btn.setEnabled(False)
        self._vosk_status.setText("Downloading..."); self._vosk_status.setStyleSheet(f"color:{C.YELLOW};background:transparent;")
        def _run():
            try:
                import urllib.request, zipfile
                from vosk_setup import MODEL_URL, MODELS_DIR, MODEL_NAME, _make_link
                MODELS_DIR.mkdir(parents=True,exist_ok=True); zip_path=MODELS_DIR/f"{MODEL_NAME}.zip"
                def _hook(c,b,t):
                    if t>0: self._vosk_bar.setValue(min(99,int(c*b*100/t)))
                urllib.request.urlretrieve(MODEL_URL,zip_path,_hook); self._vosk_bar.setValue(99)
                with zipfile.ZipFile(zip_path,"r") as zf: zf.extractall(MODELS_DIR)
                zip_path.unlink(); _make_link(); self._vosk_bar.setValue(100)
                self._vosk_status.setText("Installed"); self._vosk_status.setStyleSheet(f"color:{C.GREEN};background:transparent;"); self._vosk_dl_btn.setText("Reinstall")
            except Exception as e: self._vosk_status.setText(f"Failed: {str(e)[:30]}"); self._vosk_status.setStyleSheet(f"color:{C.RED};background:transparent;")
            finally: self._vosk_dl_btn.setEnabled(True); QTimer.singleShot(3000,self._vosk_bar.hide)
        threading.Thread(target=_run,daemon=True).start()

    def _save(self):
        try:
            cfg=json.loads(API_FILE.read_text(encoding="utf-8")) if API_FILE.exists() else {}; changed=False
            for attr,key in [("_api","gemini_api_key"),("_api_oai","openai_api_key"),("_api_xai","xai_api_key"),("_api_ant","anthropic_api_key")]:
                w=getattr(self,attr,None)
                if w and w.text().strip(): cfg[key]=w.text().strip(); w.clear(); w.setPlaceholderText(f"{key.split('_')[0].capitalize()} key saved OK"); changed=True
            if changed: os.makedirs(CONFIG_DIR,exist_ok=True); API_FILE.write_text(json.dumps(cfg,indent=2),encoding="utf-8")
            try:
                from api_manager import reload_manager; reload_manager()
            except Exception: pass
        except Exception as e: print(f"[Settings] save error: {e}")
        self._s.update({
            "voice":self._voice.currentText().capitalize(), "volume":self._vol.value(),
            "mic_sensitivity":self._mic.value(), "wake_word":self._wake.isChecked(),
            "clap_activation":self._clap.isChecked(), "clap_sensitivity":self._clap_sens.value(),
            "proactive_checkins":self._proactive.isChecked(), "proactive_interval":self._proactive_sens.value(),
            "theme": self._theme_combo.currentText(),
            "auto_memory":self._automem.isChecked(), "auto_run":self._autorun.isChecked(),
            "startup_greeting":self._greet.isChecked(),
            "ai_model":self._model.currentData() or self._model.currentText(),
            "ai_provider":self._provider.currentData(),
            "startup_on_boot":self._boot.isChecked(),
        })
        save_settings(self._s); self.settings_saved.emit(self._s)


# -- Lock Screen (PIN) -----------------------------------------------------------
class LockScreenDialog(QDialog):
    """
    Full-screen-ish PIN lock, shown before the main window becomes usable.

    Two modes:
      - setup  : no PIN exists yet -> ask the user to create one (enter
                 twice to confirm), then call set_lock_pin() and unlock.
      - verify : a PIN already exists -> ask for it, check with
                 verify_lock_pin(). Wrong PIN shakes the dot indicator and
                 clears input; correct PIN closes the dialog (accept()).

    This dialog is modal (exec()) -- the caller blocks until the user
    either unlocks successfully or, in verify mode, can optionally allow
    "Forgot PIN?" to reset (handled by the caller via a dedicated signal so
    policy decisions stay outside this widget).
    """
    forgot_pin = pyqtSignal()

    PIN_LEN = 4  # digits

    def __init__(self, mode: str = "verify", parent=None):
        super().__init__(parent)
        self._mode = mode  # "setup" or "verify"
        self._stage = "enter"  # for setup: "enter" -> "confirm"
        self._first_pin = ""
        self._buffer = ""
        self._attempts = 0

        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Dialog)
        self.setModal(True)
        self.setStyleSheet(
            f"QDialog{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,"
            f"stop:0 #100508,stop:1 #0a0305);"
            f"border:1px solid {C.BORDER_A};border-radius:16px;}}"
        )
        self.setFixedSize(360, 490)

        lay = QVBoxLayout(self); lay.setContentsMargins(28,28,28,24); lay.setSpacing(8)
        lay.setAlignment(Qt.AlignmentFlag.AlignHCenter)

        title = QLabel("ZERO TWO")
        title.setFont(QFont("Arial Black",16,QFont.Weight.Black) if _OS=="Windows" else QFont("Arial",16,QFont.Weight.Bold))
        title.setStyleSheet(
            f"color:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {C.GREEN},stop:1 {C.TEAL});"
            f"background:transparent;letter-spacing:4px;"
        )
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(title)

        self._subtitle = QLabel()
        self._subtitle.setFont(QFont("Arial", 9) if _OS=="Windows" else QFont("Arial", 9))
        self._subtitle.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;")
        self._subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._subtitle.setWordWrap(True)
        lay.addWidget(self._subtitle)
        lay.addSpacing(14)

        # PIN dot indicator — crimson ring dots
        self._dots_row = QHBoxLayout(); self._dots_row.setSpacing(18)
        self._dots_row.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._dot_lbls = []
        for _ in range(self.PIN_LEN):
            d = QLabel("○"); d.setFont(QFont("Arial", 22, QFont.Weight.Bold))
            d.setFixedSize(32,32); d.setAlignment(Qt.AlignmentFlag.AlignCenter)
            d.setStyleSheet(f"color:{C.BORDER_A};background:transparent;")
            self._dot_lbls.append(d); self._dots_row.addWidget(d)
        dots_w = QWidget(); dots_w.setLayout(self._dots_row)
        lay.addWidget(dots_w)
        lay.addSpacing(6)

        self._error_lbl = QLabel("")
        self._error_lbl.setFont(QFont("Arial",8,QFont.Weight.Bold))
        self._error_lbl.setStyleSheet(f"color:{C.RED};background:transparent;")
        self._error_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._error_lbl.setFixedHeight(18)
        lay.addWidget(self._error_lbl)
        lay.addSpacing(8)

        # Numeric keypad — glass crimson buttons
        _ds = (f"QPushButton{{background:rgba(30,8,14,200);color:{C.WHITE};"
               f"border:1px solid {C.BORDER_G};border-radius:10px;font-size:16pt;font-weight:bold;}}"
               f"QPushButton:hover{{background:rgba(60,12,24,230);"
               f"border:1px solid {C.BORDER_A};color:{C.GREEN};}}"
               f"QPushButton:pressed{{background:{C.GREEN_GHO};border:1px solid {C.GREEN_D};}}")
        _bs = (f"QPushButton{{background:rgba(20,5,10,200);color:{C.TEXT_MED};"
               f"border:1px solid {C.BORDER_G};border-radius:10px;font-size:14pt;}}"
               f"QPushButton:hover{{border:1px solid {C.RED};color:{C.RED};}}")
        grid = QGridLayout(); grid.setSpacing(10)
        keys = [("1",0,0),("2",0,1),("3",0,2),
                ("4",1,0),("5",1,1),("6",1,2),
                ("7",2,0),("8",2,1),("9",2,2),
                ("",3,0),("0",3,1),("←",3,2)]
        for label, r, c in keys:
            if label == "":
                sp = QWidget(); sp.setFixedSize(76,54); grid.addWidget(sp,r,c); continue
            btn = QPushButton(label); btn.setFixedSize(76,54)
            btn.setFont(QFont("Arial",16,QFont.Weight.Bold))
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            if label == "←":
                btn.setStyleSheet(_bs); btn.clicked.connect(self._backspace)
            else:
                btn.setStyleSheet(_ds)
                btn.clicked.connect(lambda _,d=label: self._digit(d))
            grid.addWidget(btn, r, c)
        keypad_w = QWidget(); keypad_w.setLayout(grid)
        lay.addWidget(keypad_w, alignment=Qt.AlignmentFlag.AlignHCenter)
        lay.addStretch()

        self._forgot_btn = QPushButton("Forgot PIN?")
        self._forgot_btn.setFlat(True)
        self._forgot_btn.setFont(QFont("Arial",8))
        self._forgot_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._forgot_btn.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;")
        self._forgot_btn.clicked.connect(self.forgot_pin.emit)
        lay.addWidget(self._forgot_btn, alignment=Qt.AlignmentFlag.AlignHCenter)
        self._forgot_btn.setVisible(self._mode == "verify")

        self._refresh_subtitle()
        self._refresh_dots()

    # ── subtitle / stage text ────────────────────────────────────────────────
    def _refresh_subtitle(self):
        if self._mode == "setup":
            if self._stage == "enter":
                self._subtitle.setText(f"Create a {self.PIN_LEN}-digit PIN to protect Zero Two")
            else:
                self._subtitle.setText("Enter the PIN again to confirm")
        else:
            self._subtitle.setText("Enter PIN to unlock Zero Two")

    # ── dot indicator ────────────────────────────────────────────────────────
    def _refresh_dots(self):
        for i, d in enumerate(self._dot_lbls):
            if i < len(self._buffer):
                d.setText("●"); d.setStyleSheet(f"color:{C.GREEN};background:transparent;")
            else:
                d.setText("○"); d.setStyleSheet(f"color:{C.BORDER_A};background:transparent;")

    # ── input handling ───────────────────────────────────────────────────────
    def _digit(self, d: str):
        if len(self._buffer) >= self.PIN_LEN:
            return
        self._error_lbl.setText("")
        self._buffer += d
        self._refresh_dots()
        if len(self._buffer) == self.PIN_LEN:
            QTimer.singleShot(120, self._submit)

    def _backspace(self):
        self._error_lbl.setText("")
        self._buffer = self._buffer[:-1]
        self._refresh_dots()

    def keyPressEvent(self, event):
        key = event.key()
        if Qt.Key.Key_0 <= key <= Qt.Key.Key_9:
            self._digit(chr(key))
        elif key in (Qt.Key.Key_Backspace, Qt.Key.Key_Delete):
            self._backspace()
        elif key == Qt.Key.Key_Escape:
            pass  # lock screen cannot be dismissed with Escape
        else:
            super().keyPressEvent(event)

    # ── submit logic ─────────────────────────────────────────────────────────
    def _submit(self):
        pin = self._buffer
        if self._mode == "setup":
            if self._stage == "enter":
                self._first_pin = pin
                self._buffer = ""
                self._stage = "confirm"
                self._refresh_subtitle()
                self._refresh_dots()
            else:  # confirm stage
                if pin == self._first_pin:
                    set_lock_pin(pin, enabled=True)
                    self.accept()
                else:
                    self._shake_error("PINs didn't match -- try again")
                    self._first_pin = ""
                    self._buffer = ""
                    self._stage = "enter"
                    self._refresh_subtitle()
                    self._refresh_dots()
        else:  # verify
            if verify_lock_pin(pin):
                self.accept()
            else:
                self._attempts += 1
                self._shake_error("Incorrect PIN")
                self._buffer = ""
                self._refresh_dots()

    def _shake_error(self, msg: str):
        self._error_lbl.setText(msg)
        for d in self._dot_lbls:
            d.setStyleSheet(f"color:{C.RED};background:transparent;")
            d.setText("✕")
        QTimer.singleShot(380, self._refresh_dots)

    def closeEvent(self, event):
        # Lock screen can't be closed via window controls -- only accept()
        # (success) or reject() (called explicitly by the caller, e.g. on
        # app quit) dismisses it.
        if self.result() == QDialog.DialogCode.Accepted:
            event.accept()
        else:
            event.ignore()


# -- Setup Overlay -------------------------------------------------------------------
class SetupOverlay(QWidget):
    done = pyqtSignal(str, str)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet(
            f"SetupOverlay{{background:rgba(14,5,8,252);"
            f"border:1px solid {C.GREEN_D};border-radius:14px;}}"
        )
        detected = {"darwin":"mac","windows":"windows"}.get(_OS.lower(),"linux")
        self._sel_os = detected
        lay = QVBoxLayout(self); lay.setContentsMargins(32,28,32,28); lay.setSpacing(12)

        def lbl(t,sz=9,bold=False,col=C.GREEN,align=Qt.AlignmentFlag.AlignCenter):
            w=QLabel(t); w.setAlignment(align)
            w.setFont(QFont("Arial",sz,QFont.Weight.Bold if bold else QFont.Weight.Normal))
            w.setStyleSheet(f"color:{col};background:transparent;"); return w

        badge = QLabel("02"); badge.setFixedSize(48,48)
        badge.setFont(QFont("Arial Black",18,QFont.Weight.Black) if _OS=="Windows" else QFont("Arial",18,QFont.Weight.Bold))
        badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        badge.setStyleSheet(f"color:{C.WHITE};background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {C.GREEN},stop:1 {C.GREEN_D});border-radius:12px;")
        lay.addWidget(badge, alignment=Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(lbl("ZERO TWO AI  SETUP",14,True))
        lay.addWidget(lbl("Enter your Gemini API key to begin.",9,col=C.TEXT_MED))
        lay.addSpacing(4)
        sep=QFrame(); sep.setFrameShape(QFrame.Shape.HLine); sep.setStyleSheet(f"color:{C.BORDER_G};"); lay.addWidget(sep)
        lay.addWidget(lbl("GEMINI API KEY",8,col=C.TEXT_DIM,align=Qt.AlignmentFlag.AlignLeft))
        self._key=QLineEdit(); self._key.setEchoMode(QLineEdit.EchoMode.Password)
        self._key.setPlaceholderText("AIza..."); self._key.setFont(QFont("Arial",10)); self._key.setFixedHeight(38)
        self._key.setStyleSheet(
            f"QLineEdit{{background:{C.PANEL};color:{C.WHITE};border:1px solid {C.BORDER_G};"
            f"border-radius:8px;padding:4px 12px;}}"
            f"QLineEdit:focus{{border:1px solid {C.GREEN};}}"
        )
        lay.addWidget(self._key)
        sep2=QFrame(); sep2.setFrameShape(QFrame.Shape.HLine); sep2.setStyleSheet(f"color:{C.BORDER_G};"); lay.addWidget(sep2)
        lay.addWidget(lbl("OPERATING SYSTEM",8,col=C.TEXT_DIM,align=Qt.AlignmentFlag.AlignLeft))
        os_row=QHBoxLayout(); os_row.setSpacing(8); self._os_btns={}
        for k,label in [("windows","Windows"),("mac","macOS"),("linux","Linux")]:
            btn=QPushButton(label)
            btn.setFont(QFont("Arial",8,QFont.Weight.Bold)); btn.setFixedHeight(34)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda _,x=k: self._sel(x))
            os_row.addWidget(btn); self._os_btns[k]=btn
        lay.addLayout(os_row); self._sel(detected); lay.addSpacing(8)
        go=QPushButton("▸  ACTIVATE ZERO TWO")
        go.setFont(QFont("Arial",10,QFont.Weight.Bold)); go.setFixedHeight(40)
        go.setCursor(Qt.CursorShape.PointingHandCursor)
        go.setStyleSheet(
            f"QPushButton{{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,"
            f"stop:0 {C.GREEN},stop:1 {C.GREEN_D});"
            f"color:{C.WHITE};border:none;border-radius:10px;font-weight:bold;}}"
            f"QPushButton:hover{{background:{C.GREEN_D};border:none;border-radius:10px;}}"
        )
        go.clicked.connect(self._submit); lay.addWidget(go)

    def _sel(self, k):
        self._sel_os = k
        pal = {"windows":(C.GREEN,C.GREEN_GHO),"mac":(C.TEAL,C.GREEN_GHO),"linux":(C.CYAN,C.GREEN_GHO)}
        for key,btn in self._os_btns.items():
            if key==k:
                fg,bg=pal[k]
                btn.setStyleSheet(
                    f"QPushButton{{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,"
                    f"stop:0 {fg},stop:1 {C.GREEN_D});"
                    f"color:{C.WHITE};border:none;border-radius:8px;font-weight:bold;}}"
                )
            else:
                btn.setStyleSheet(
                    f"QPushButton{{background:{C.PANEL};color:{C.TEXT_DIM};"
                    f"border:1px solid {C.BORDER_G};border-radius:8px;}}"
                    f"QPushButton:hover{{color:{C.TEXT};border:1px solid {C.BORDER_A};}}"
                )

    def _submit(self):
        key = self._key.text().strip()
        if not key: self._key.setStyleSheet(self._key.styleSheet()+f"QLineEdit{{border:1px solid {C.RED};}}"); return
        self.done.emit(key, self._sel_os)

# -- Main Window ----------------------------------------------------------------------
class MainWindow(QMainWindow):
    _log_sig   = pyqtSignal(str)
    _state_sig = pyqtSignal(str)
    _agent_sig = pyqtSignal(str, str, str)

    def __init__(self, face_path: str):
        super().__init__()
        self.setWindowTitle(f"Zero Two AI  v{_VERSION}")
        self.setMinimumSize(_MIN_W,_MIN_H); self.resize(_W,_H)
        scr = QApplication.primaryScreen().availableGeometry()
        self.move(max(0,(scr.width()-_W)//2), max(0,(scr.height()-_H)//2))
        self.on_text_command = None; self._muted = False; self._current_file = None
        self._settings = load_settings()

        if _OS == "Windows":
            try:
                import ctypes; hwnd = int(self.winId())
                ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd,20,ctypes.byref(ctypes.c_int(1)),4)
            except Exception: pass

        self.setStyleSheet(f"""
            QMainWindow{{background:{C.BG};}}
            QToolTip{{background:{C.CARD2};color:{C.WHITE};border:1px solid {C.BORDER_G};
                      border-radius:4px;padding:4px 8px;font-family:'Segoe UI';font-size:9pt;}}
        """)
        central = QWidget(); central.setStyleSheet(f"background:{C.BG};")
        self.setCentralWidget(central)
        root = QVBoxLayout(central); root.setContentsMargins(0,0,0,0); root.setSpacing(0)
        root.addWidget(self._build_title_bar())
        root.addWidget(self._build_nav_bar())
        body = QHBoxLayout(); body.setContentsMargins(0,0,0,0); body.setSpacing(0)
        body.addWidget(self._build_left_panel(), stretch=0)
        center = QWidget(); center.setStyleSheet(f"background:{C.BG};")
        cl = QVBoxLayout(center); cl.setContentsMargins(0,0,0,0); cl.setSpacing(0)

        # Zero Two character portrait (top of center column)
        self._char_panel = CharacterPanel()
        self._char_panel.setMinimumHeight(220)
        cl.addWidget(self._char_panel, stretch=2)

        # Orb (bottom of center column, above controls)
        self.hud = OrbCanvas()
        self.hud.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        cl.addWidget(self.hud, stretch=3)
        cl.addWidget(self._build_bottom_bar())
        body.addWidget(center, stretch=1)
        body.addWidget(self._build_right_panel(), stretch=0)
        root.addLayout(body, stretch=1)

        self._log_sig.connect(self._transcript.append_log)
        self._state_sig.connect(self._apply_state)
        self._agent_sig.connect(self._on_agent_update)

        self._clock_tmr = QTimer(self); self._clock_tmr.timeout.connect(self._tick_clock); self._clock_tmr.start(1000); self._tick_clock()
        QShortcut(QKeySequence("F4"),   self).activated.connect(self._toggle_mute)
        QShortcut(QKeySequence("F11"),  self).activated.connect(self._toggle_fs)
        QShortcut(QKeySequence("Ctrl+K"), self).activated.connect(self._open_palette)

        self._tray = self._build_tray()
        self._overlay = None
        self._ready = self._check_config()
        if not self._ready: self._show_setup()

    # -- Title bar (Zero Two branded, crimson/pink glass) ----------------------
    def _build_title_bar(self) -> QWidget:
        w = QWidget(); w.setFixedHeight(52)
        w.setStyleSheet(
            f"background:qlineargradient(x1:0,y1:0,x2:1,y2:0,"
            f"stop:0 #0e0508,stop:0.4 #120609,stop:1 #0e0508);"
            f"border-bottom:1px solid {C.BORDER_G};"
        )
        lay = QHBoxLayout(w); lay.setContentsMargins(18,0,18,0); lay.setSpacing(10)

        # Logo block — 02 badge + name
        badge = QLabel("02"); badge.setFixedSize(32,32)
        badge.setFont(QFont("Arial Black", 11, QFont.Weight.Black) if _OS=="Windows" else QFont("Arial", 11, QFont.Weight.Bold))
        badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        badge.setStyleSheet(f"""
            color:{C.WHITE}; background:qlineargradient(x1:0,y1:0,x2:1,y2:1,
            stop:0 {C.GREEN},stop:1 {C.GREEN_D});
            border-radius:8px; font-weight:900;
        """)
        logo = QLabel("ZERO TWO AI")
        logo.setFont(QFont("Arial", 13, QFont.Weight.Bold) if _OS=="Windows" else QFont("Arial", 12, QFont.Weight.Bold))
        logo.setStyleSheet(f"color:{C.WHITE};background:transparent;letter-spacing:2px;")
        sub  = QLabel(f"v{_VERSION}  •  Powered by Gemini")
        sub.setFont(QFont("Arial", 7)); sub.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;")
        ll = QVBoxLayout(); ll.setSpacing(0); ll.addWidget(logo); ll.addWidget(sub)
        lay.addWidget(badge); lay.addLayout(ll); lay.addStretch()

        # Center — decorative status text
        center_lbl = QLabel("ZERO  TWO  //  AI  ASSISTANT")
        center_lbl.setFont(QFont("Arial", 9, QFont.Weight.Bold) if _OS=="Windows" else QFont("Arial", 9))
        center_lbl.setStyleSheet(f"color:{C.BORDER_A};background:transparent;letter-spacing:3px;")
        lay.addWidget(center_lbl); lay.addStretch()

        # Right — metrics + status pill + clock
        self._sys_lbl = QLabel("CPU --  RAM --")
        self._sys_lbl.setFont(QFont("Arial", 7)); self._sys_lbl.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;")

        self._status_dot  = QLabel("●")
        self._status_dot.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        self._status_dot.setStyleSheet(f"color:{C.GREEN};background:transparent;")

        self._status_text = QLabel("ONLINE")
        self._status_text.setFont(QFont("Arial", 7, QFont.Weight.Bold) if _OS=="Windows" else QFont("Arial", 7))
        self._status_text.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;letter-spacing:1px;")

        self._provider_pill = QLabel("···")
        self._provider_pill.setFont(QFont("Arial", 7, QFont.Weight.Bold) if _OS=="Windows" else QFont("Arial", 7))
        self._provider_pill.setStyleSheet(
            f"background:{C.GREEN_GHO};color:{C.GREEN};"
            f"border:1px solid {C.GREEN_D};border-radius:10px;padding:2px 10px;"
        )
        kb_hint = QLabel("Ctrl+K")
        kb_hint.setFont(QFont("Arial", 6, QFont.Weight.Bold) if _OS=="Windows" else QFont("Arial", 6))
        kb_hint.setStyleSheet(
            f"background:{C.CARD};color:{C.TEXT_DIM};"
            f"border:1px solid {C.BORDER_G};border-radius:4px;padding:1px 6px;"
        )
        kb_hint.setToolTip("Open command palette (Ctrl+K)")

        self._clock_lbl = QLabel("00:00:00")
        self._clock_lbl.setFont(QFont("Arial", 10, QFont.Weight.Bold) if _OS=="Windows" else QFont("Arial", 10))
        self._clock_lbl.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;")

        lay.addWidget(self._sys_lbl); lay.addSpacing(10)
        lay.addWidget(self._status_dot); lay.addWidget(self._status_text); lay.addSpacing(10)
        lay.addWidget(self._provider_pill); lay.addSpacing(8)
        lay.addWidget(kb_hint); lay.addSpacing(14); lay.addWidget(self._clock_lbl)

        pt = QTimer(self); pt.timeout.connect(self._refresh_provider_pill); pt.start(3000)
        QTimer.singleShot(500, self._refresh_provider_pill)
        st = QTimer(self); st.timeout.connect(self._update_sys_bar); st.start(2500)
        QTimer.singleShot(1000, self._update_sys_bar)
        return w

    def _refresh_provider_pill(self):
        try:
            from api_manager import get_manager
            st = get_manager().status()
            prov  = (st.get("active_provider") or "?").upper()
            model = st.get("selected_model") or ""
            short = model.split("/")[-1][:16]
            self._provider_pill.setText(f"  {prov}  {short}  ")
        except Exception:
            self._provider_pill.setText("  ···  ")

    def _tick_clock(self): self._clock_lbl.setText(time.strftime("%H:%M:%S"))

    def _update_sys_bar(self):
        try:
            from system_monitor import get_monitor
            mon = get_monitor(); snap = mon.snapshot() if mon else None
            if snap:
                cpu = snap.cpu; ram = snap.ram
                tmp = f"  {snap.temp:.0f}°C" if snap.temp>=0 else ""
                gpu_s = ""
                if hasattr(snap,"gpu_usage") and snap.gpu_usage>=0:
                    gpu_s = f"  GPU {snap.gpu_usage:.0f}%"
                    if hasattr(snap,"gpu_temp") and snap.gpu_temp>0:
                        gpu_s += f" {snap.gpu_temp:.0f}°C"
                self._sys_lbl.setText(f"CPU {cpu:.0f}%  RAM {ram:.0f}%{tmp}{gpu_s}")
                col = C.RED if (cpu>80 or ram>85) else (C.YELLOW if (cpu>60 or ram>70) else C.TEXT_DIM)
                self._sys_lbl.setStyleSheet(f"color:{col};background:transparent;")
            else:
                s2 = _metrics.snapshot()
                self._sys_lbl.setText(f"CPU {s2.get('cpu',0):.0f}%  RAM {s2.get('mem',0):.0f}%")
        except Exception:
            pass

    # -- Nav bar (Zero Two glass tabs) -----------------------------------------
    def _build_nav_bar(self) -> QWidget:
        w = QWidget(); w.setFixedHeight(44)
        w.setStyleSheet(
            f"background:qlineargradient(x1:0,y1:0,x2:0,y2:1,"
            f"stop:0 #100708,stop:1 #0e0508);"
            f"border-bottom:1px solid {C.BORDER_G};"
        )
        lay = QHBoxLayout(w); lay.setContentsMargins(14,4,14,4); lay.setSpacing(2)
        self._nav_btns = {}
        icons = {"DASHBOARD":"◈ ","MEMORY":"♡ ","AGENTS":"⚡ ","NOTES":"✎ ",
                 "GALLERY":"⊞ ","ANIME":"▶ ","SETTINGS":"⚙ "}
        for label in ["DASHBOARD","MEMORY","AGENTS","NOTES","GALLERY","ANIME","SETTINGS"]:
            btn = QPushButton(f"{icons.get(label,'')}{label}")
            btn.setFont(QFont("Arial", 7, QFont.Weight.Bold) if _OS=="Windows" else QFont("Arial", 7))
            btn.setFixedHeight(34); btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda _,l=label: self._on_nav(l))
            self._nav_btns[label] = btn; lay.addWidget(btn)
        lay.addStretch(); self._on_nav("DASHBOARD", init=True)
        return w

    def _on_nav(self, label, init=False):
        for k, btn in self._nav_btns.items():
            if k == label:
                btn.setStyleSheet(
                    f"QPushButton{{background:{C.GREEN_GHO};color:{C.GREEN};"
                    f"border:1px solid {C.GREEN_D};border-radius:8px;padding:2px 12px;}}"
                )
            else:
                btn.setStyleSheet(
                    f"QPushButton{{background:transparent;color:{C.TEXT_DIM};"
                    f"border:none;border-radius:8px;padding:2px 12px;}}"
                    f"QPushButton:hover{{color:{C.TEXT};background:{C.PANEL};"
                    f"border:1px solid {C.BORDER};}}"
                )
        if not init:
            page_map = {"MEMORY":self._memory_page,"AGENTS":self._agents_page,
                        "SETTINGS":self._settings_page, "NOTES":self._notes_page,
                        "GALLERY":self._gallery_page, "ANIME":self._anime_page}
            self._right_stack.setCurrentWidget(page_map.get(label, self._transcript_page))
            if label == "GALLERY": self._gallery_page._scan_screenshots()
            if label == "MEMORY":  self._memory_page._load()

    # -- Left panel (Zero Two glass sidebar) ----------------------------------
    def _build_left_panel(self) -> QWidget:
        w = QWidget(); w.setFixedWidth(370)
        w.setStyleSheet(
            f"background:qlineargradient(x1:0,y1:0,x2:1,y2:0,"
            f"stop:0 #0e0508,stop:1 #120609);"
            f"border-right:1px solid {C.BORDER_G};"
        )
        lay = QVBoxLayout(w); lay.setContentsMargins(10,10,10,10); lay.setSpacing(10)
        self._feed = ScreenFeedWidget(); lay.addWidget(self._feed)
        sep1 = QFrame(); sep1.setFrameShape(QFrame.Shape.HLine)
        sep1.setStyleSheet(f"color:{C.BORDER_G};"); lay.addWidget(sep1)
        lay.addWidget(NetworkWidget())
        sep2 = QFrame(); sep2.setFrameShape(QFrame.Shape.HLine)
        sep2.setStyleSheet(f"color:{C.BORDER_G};"); lay.addWidget(sep2)
        lay.addWidget(CoreMetricsWidget(), stretch=1)
        return w

    # -- Right panel (Zero Two glass sidebar) ---------------------------------
    def _build_right_panel(self) -> QWidget:
        w = QWidget(); w.setFixedWidth(390)
        w.setStyleSheet(
            f"background:qlineargradient(x1:0,y1:0,x2:1,y2:0,"
            f"stop:0 #120609,stop:1 #0e0508);"
            f"border-left:1px solid {C.BORDER_G};"
        )
        lay = QVBoxLayout(w); lay.setContentsMargins(0,0,0,0); lay.setSpacing(0)
        self._right_stack = QStackedWidget()

        # Transcript page
        self._transcript_page = QWidget(); self._transcript_page.setStyleSheet(f"background:{C.NAVY};")
        tl = QVBoxLayout(self._transcript_page); tl.setContentsMargins(0,0,0,0); tl.setSpacing(0)
        hdr = QWidget(); hdr.setFixedHeight(38)
        hdr.setStyleSheet(
            f"background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #150a0d,stop:1 #120608);"
            f"border-bottom:1px solid {C.BORDER_G};"
        )
        hl = QHBoxLayout(hdr); hl.setContentsMargins(14,0,14,0)
        tl_lbl = QLabel("♡  CONVERSATION")
        tl_lbl.setFont(QFont("Arial", 8, QFont.Weight.Bold) if _OS=="Windows" else QFont("Arial", 8))
        tl_lbl.setStyleSheet(f"color:{C.TEXT_MED};background:transparent;letter-spacing:1px;")
        kh = QLabel("Ctrl+K"); kh.setFont(QFont("Arial", 6) if _OS=="Windows" else QFont("Arial", 6))
        kh.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;")
        live_lbl = QLabel("● LIVE")
        live_lbl.setFont(QFont("Arial", 6, QFont.Weight.Bold) if _OS=="Windows" else QFont("Arial", 6))
        live_lbl.setStyleSheet(f"color:{C.GREEN};background:transparent;")
        hl.addWidget(tl_lbl); hl.addStretch(); hl.addWidget(kh); hl.addSpacing(8); hl.addWidget(live_lbl)
        self._transcript = TranscriptWidget()
        tl.addWidget(hdr); tl.addWidget(self._transcript, stretch=1); tl.addWidget(self._build_input_bar())

        # Memory page
        self._memory_page = MemoryViewerWidget()

        # Agents page
        self._agents_page = QWidget(); self._agents_page.setStyleSheet(f"background:{C.NAVY};")
        al = QVBoxLayout(self._agents_page); al.setContentsMargins(10,10,10,10); al.setSpacing(8)
        ah = QHBoxLayout()
        at = QLabel("AGENT CONTROL CENTER"); at.setFont(QFont("Courier New",8,QFont.Weight.Bold)); at.setStyleSheet(f"color:{C.GREEN};background:transparent;")
        self._rpt_btn = QPushButton("RUN REPORT"); self._rpt_btn.setFixedHeight(24); self._rpt_btn.setFont(QFont("Courier New",6,QFont.Weight.Bold)); self._rpt_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._rpt_btn.setStyleSheet(f"QPushButton{{background:{C.GREEN_GHO};color:{C.GREEN};border:1px solid {C.GREEN_D};border-radius:3px;padding:2px 6px;}}QPushButton:hover{{background:{C.PANEL};}}")
        self._rpt_btn.clicked.connect(self._run_agent_report); ah.addWidget(at); ah.addStretch(); ah.addWidget(self._rpt_btn); al.addLayout(ah)
        self._agent_cards = {}
        for key,name,role in [("planner","Planner","Breaks goals into steps"),("coder","Coder","Writes and edits code"),("tester","Tester","Tests and validates"),("reviewer","Reviewer","Reviews logic"),("security","Security","Monitors safety"),("voice","Voice","Speech I/O manager")]:
            card = AgentCard(name,role); self._agent_cards[key] = card; al.addWidget(card)
        al.addStretch()
        rs = QWidget(); rs.setStyleSheet(f"background:{C.CARD};border:1px solid {C.BORDER_G};border-radius:4px;"); rs.setFixedHeight(40)
        rl2 = QHBoxLayout(rs); rl2.setContentsMargins(8,4,8,4); rl2.setSpacing(6)
        rl_title = QLabel("AI ROUTER"); rl_title.setFont(QFont("Courier New",6,QFont.Weight.Bold)); rl_title.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;")
        rl2.addWidget(rl_title)
        self._router_lbl = QLabel("Checking..."); self._router_lbl.setFont(QFont("Courier New",7,QFont.Weight.Bold)); self._router_lbl.setStyleSheet(f"color:{C.GREEN};background:transparent;")
        rl2.addWidget(self._router_lbl,stretch=1)
        rrb = QPushButton("R"); rrb.setFixedSize(22,22); rrb.setFlat(True); rrb.setStyleSheet(f"color:{C.GREEN};background:transparent;font-weight:bold;"); rrb.setCursor(Qt.CursorShape.PointingHandCursor)
        rrb.clicked.connect(self._refresh_router_status); rl2.addWidget(rrb)
        al.addWidget(rs); QTimer.singleShot(2000, self._refresh_router_status)

        self._settings_page = SettingsPanel(); self._settings_page.settings_saved.connect(self._on_settings_saved)
        self._notes_page   = self._build_notes_page()
        self._gallery_page = self._build_gallery_page()
        self._anime_page   = self._build_anime_page()

        for page in [self._transcript_page, self._memory_page, self._agents_page,
                     self._settings_page, self._notes_page, self._gallery_page, self._anime_page]:
            self._right_stack.addWidget(page)
        lay.addWidget(self._right_stack, stretch=1)
        return w

    # -- Bottom bar ----------------------------------------------------------------------
    # -- Bottom bar (Zero Two rounded crimson controls) -----------------------
    def _build_bottom_bar(self) -> QWidget:
        w = QWidget(); w.setFixedHeight(90)
        w.setStyleSheet(f"background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 {C.BG},stop:1 #0d0508);")
        lay = QHBoxLayout(w); lay.setContentsMargins(0,0,0,0)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter); lay.setSpacing(28)
        _btn = (f"QPushButton{{background:{C.PANEL};color:{C.TEXT_MED};"
                f"border:1px solid {C.BORDER_G};border-radius:26px;}}"
                f"QPushButton:hover{{background:{C.CARD2};border:1px solid {C.BORDER_A};color:{C.GREEN};}}"
                f"QPushButton:checked{{background:{C.RED};color:{C.WHITE};border:1px solid {C.RED};}}")
        _call = (f"QPushButton{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,"
                 f"stop:0 {C.GREEN},stop:1 {C.GREEN_D});"
                 f"color:{C.WHITE};border:none;border-radius:34px;"
                 f"border-bottom:3px solid {C.GREEN_D};}}"
                 f"QPushButton:hover{{background:{C.GREEN_D};border:none;border-radius:34px;}}"
                 f"QPushButton:checked{{background:{C.RED};color:{C.WHITE};border:none;border-radius:34px;}}")
        self._cam_btn = QPushButton("CAM"); self._cam_btn.setFixedSize(52,52)
        self._cam_btn.setFont(QFont("Arial",8,QFont.Weight.Bold))
        self._cam_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._cam_btn.setStyleSheet(_btn); self._cam_btn.setCheckable(True)
        self._cam_btn.clicked.connect(self._on_vision_btn)
        self._call_btn = QPushButton("02"); self._call_btn.setFixedSize(68,68)
        self._call_btn.setFont(QFont("Arial Black",13,QFont.Weight.Black) if _OS=="Windows" else QFont("Arial",13,QFont.Weight.Bold))
        self._call_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._call_btn.setStyleSheet(_call); self._call_btn.setCheckable(True)
        self._call_btn.setToolTip("Activate / Deactivate Zero Two")
        self._call_btn.clicked.connect(self._on_call_btn)
        self._mic_btn = QPushButton("MIC"); self._mic_btn.setFixedSize(52,52)
        self._mic_btn.setFont(QFont("Arial",8,QFont.Weight.Bold))
        self._mic_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._mic_btn.setStyleSheet(_btn); self._mic_btn.setCheckable(True)
        self._mic_btn.clicked.connect(self._toggle_mute)
        lay.addWidget(self._cam_btn); lay.addWidget(self._call_btn); lay.addWidget(self._mic_btn)
        return w

    # -- Input bar (Zero Two glass input area) --------------------------------
    def _build_input_bar(self) -> QWidget:
        container = QWidget()
        container.setStyleSheet(f"background:{C.PANEL};border-top:1px solid {C.BORDER_G};")
        vlay = QVBoxLayout(container); vlay.setContentsMargins(0,0,0,0); vlay.setSpacing(0)
        chips_w = QWidget(); chips_w.setFixedHeight(34)
        chips_w.setStyleSheet(f"background:{C.PANEL};")
        cl = QHBoxLayout(chips_w); cl.setContentsMargins(10,6,10,0); cl.setSpacing(4)
        for label in ["Status check","All agents report","Open Chrome","What's on my screen?","Open Spotify","Weather today"]:
            chip = QPushButton(label); chip.setFixedHeight(22)
            chip.setFont(QFont("Arial",6,QFont.Weight.Bold)); chip.setCursor(Qt.CursorShape.PointingHandCursor)
            chip.setStyleSheet(
                f"QPushButton{{background:{C.GREEN_GHO};color:{C.GREEN};"
                f"border:1px solid {C.GREEN_D};border-radius:11px;padding:0 8px;}}"
                f"QPushButton:hover{{background:{C.CARD2};border:1px solid {C.GREEN};color:{C.WHITE};}}"
            )
            def _click(checked=False, txt=label): self._input.setText(txt); self._send()
            chip.clicked.connect(_click); cl.addWidget(chip)
        cl.addStretch(); vlay.addWidget(chips_w)
        row_w = QWidget(); row_w.setFixedHeight(52)
        row_w.setStyleSheet(f"background:{C.PANEL};")
        lay = QHBoxLayout(row_w); lay.setContentsMargins(10,7,10,8); lay.setSpacing(8)
        ab = QPushButton("+"); ab.setFixedSize(34,34)
        ab.setFont(QFont("Arial",14,QFont.Weight.Bold))
        ab.setCursor(Qt.CursorShape.PointingHandCursor); ab.setToolTip("Attach file")
        ab.setStyleSheet(
            f"QPushButton{{background:{C.CARD2};color:{C.GREEN};"
            f"border:1px solid {C.BORDER_G};border-radius:17px;}}"
            f"QPushButton:hover{{border:1px solid {C.GREEN};background:{C.GREEN_GHO};}}"
        )
        ab.clicked.connect(self._on_attach_clicked)
        self._input = QLineEdit()
        self._input.setPlaceholderText("Ask Zero Two anything...  (Ctrl+K for commands)")
        self._input.setFont(QFont("Arial",10) if _OS=="Windows" else QFont("Arial",10))
        self._input.setFixedHeight(36)
        self._input.setStyleSheet(
            f"QLineEdit{{background:{C.CARD2};color:{C.WHITE};"
            f"border:1px solid {C.BORDER_G};border-radius:18px;"
            f"padding:4px 16px;font-size:10pt;}}"
            f"QLineEdit:focus{{border:1px solid {C.GREEN};background:{C.CARD};}}"
        )
        self._input.returnPressed.connect(self._send)
        sb = QPushButton(">"); sb.setFixedSize(36,36)
        sb.setFont(QFont("Arial",12,QFont.Weight.Bold)); sb.setCursor(Qt.CursorShape.PointingHandCursor)
        sb.setStyleSheet(
            f"QPushButton{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,"
            f"stop:0 {C.GREEN},stop:1 {C.GREEN_D});"
            f"color:{C.WHITE};font-weight:bold;border:none;border-radius:18px;}}"
            f"QPushButton:hover{{background:{C.GREEN_D};border:none;border-radius:18px;}}"
        )
        sb.clicked.connect(self._send)
        lay.addWidget(ab); lay.addWidget(self._input, stretch=1); lay.addWidget(sb)
        vlay.addWidget(row_w)
        self._pending_file_lbl = QLabel()
        self._pending_file_lbl.setFont(QFont("Arial",7))
        self._pending_file_lbl.setStyleSheet(
            f"color:{C.GREEN};background:{C.GREEN_GHO};"
            f"border-top:1px solid {C.BORDER_G};padding:2px 10px;"
        )
        self._pending_file_lbl.hide(); vlay.addWidget(self._pending_file_lbl)
        self._pending_file_path = None
        return container

    # -- Notes page ----------------------------------------------------------------------
    def _build_notes_page(self) -> QWidget:
        NF = CONFIG_DIR / "notes.txt"
        w = QWidget(); w.setStyleSheet(f"background:{C.NAVY};")
        lay = QVBoxLayout(w); lay.setContentsMargins(10,10,10,10); lay.setSpacing(8)
        hdr = QHBoxLayout()
        title = QLabel("NOTES"); title.setFont(QFont("Courier New",9,QFont.Weight.Bold)); title.setStyleSheet(f"color:{C.GREEN};background:transparent;")
        sv = QPushButton("Save"); sv.setFixedHeight(24); sv.setFont(QFont("Courier New",7,QFont.Weight.Bold)); sv.setCursor(Qt.CursorShape.PointingHandCursor)
        sv.setStyleSheet(f"QPushButton{{background:{C.GREEN_GHO};color:{C.GREEN};border:1px solid {C.GREEN_D};border-radius:3px;padding:1px 8px;}}QPushButton:hover{{background:{C.PANEL};}}")
        hdr.addWidget(title); hdr.addStretch(); hdr.addWidget(sv); lay.addLayout(hdr)
        editor = QTextEdit(); editor.setFont(QFont("Courier New",9))
        editor.setStyleSheet(f"QTextEdit{{background:{C.CARD};color:{C.WHITE};border:1px solid {C.BORDER_G};border-radius:5px;padding:8px;}}QScrollBar:vertical{{background:{C.BG};width:4px;border:none;}}QScrollBar::handle:vertical{{background:{C.BORDER_G};border-radius:2px;}}")
        try:
            if NF.exists(): editor.setPlainText(NF.read_text(encoding="utf-8"))
        except Exception: pass
        def _save():
            try:
                os.makedirs(CONFIG_DIR, exist_ok=True); NF.write_text(editor.toPlainText(), encoding="utf-8")
                sv.setText("Saved"); QTimer.singleShot(1500, lambda: sv.setText("Save"))
            except Exception as e: sv.setText(f"Error: {e}")
        sv.clicked.connect(_save)
        auto = QTimer(w); auto.timeout.connect(_save); auto.start(30000)
        lay.addWidget(editor, stretch=1)
        hint = QLabel("Auto-saves every 30 seconds"); hint.setFont(QFont("Courier New",6)); hint.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;"); lay.addWidget(hint)
        return w

    # -- Gallery page --------------------------------------------------------------------
    def _build_gallery_page(self) -> QWidget:
        SD = BASE_DIR / "memory" / "screenshots"
        w = QWidget(); w.setStyleSheet(f"background:{C.NAVY};")
        lay = QVBoxLayout(w); lay.setContentsMargins(10,10,10,10); lay.setSpacing(8)
        hdr = QHBoxLayout()
        title = QLabel("GALLERY"); title.setFont(QFont("Courier New",9,QFont.Weight.Bold)); title.setStyleSheet(f"color:{C.GREEN};background:transparent;")
        add_btn = QPushButton("+ Add File"); add_btn.setFixedHeight(24); add_btn.setFont(QFont("Courier New",7,QFont.Weight.Bold)); add_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_ss = f"QPushButton{{background:{C.GREEN_GHO};color:{C.GREEN};border:1px solid {C.GREEN_D};border-radius:3px;padding:1px 8px;}}QPushButton:hover{{background:{C.PANEL};}}"
        add_btn.setStyleSheet(btn_ss)
        ref_btn = QPushButton("Refresh"); ref_btn.setFixedHeight(24); ref_btn.setFont(QFont("Courier New",7,QFont.Weight.Bold)); ref_btn.setCursor(Qt.CursorShape.PointingHandCursor); ref_btn.setStyleSheet(btn_ss)
        hdr.addWidget(title); hdr.addStretch(); hdr.addWidget(add_btn); hdr.addSpacing(4); hdr.addWidget(ref_btn); lay.addLayout(hdr)
        cnt = QLabel("No screenshots yet."); cnt.setFont(QFont("Courier New",7)); cnt.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;"); lay.addWidget(cnt)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet(f"QScrollArea{{background:transparent;border:none;}}QScrollBar:vertical{{background:{C.BG};width:4px;border:none;}}QScrollBar::handle:vertical{{background:{C.BORDER_G};border-radius:2px;}}")
        gw = QWidget(); gw.setStyleSheet("background:transparent;")
        grid = QGridLayout(gw); grid.setContentsMargins(0,0,0,0); grid.setSpacing(6)
        scroll.setWidget(gw); lay.addWidget(scroll, stretch=1)
        def _add():
            paths,_ = QFileDialog.getOpenFileNames(w,"Add files",str(Path.home()),"Images (*.png *.jpg *.jpeg *.gif *.webp);;All (*.*)")
            for p in paths:
                try:
                    import shutil; SD.mkdir(parents=True,exist_ok=True); shutil.copy2(p, SD/Path(p).name)
                except Exception: pass
            if paths: _scan()
        add_btn.clicked.connect(_add)
        def _scan():
            while grid.count():
                item = grid.takeAt(0)
                if item.widget(): item.widget().deleteLater()
            if not SD.exists(): cnt.setText("No screenshots folder found."); return
            imgs = sorted(SD.glob("*.png"), key=lambda p: p.stat().st_mtime, reverse=True)[:20]
            if not imgs: cnt.setText("No screenshots yet."); return
            cnt.setText(f"{len(imgs)} screenshot{'s' if len(imgs)!=1 else ''}")
            from PyQt6.QtGui import QPixmap
            for idx, ip in enumerate(imgs):
                try:
                    pm = QPixmap(str(ip)).scaled(128,80,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)
                    thumb = QLabel(); thumb.setPixmap(pm); thumb.setFixedSize(132,84)
                    thumb.setStyleSheet(f"border:1px solid {C.BORDER_G};border-radius:3px;background:{C.CARD};"); thumb.setAlignment(Qt.AlignmentFlag.AlignCenter); thumb.setToolTip(ip.name)
                    grid.addWidget(thumb, idx//2, idx%2)
                except Exception: pass
        w._scan_screenshots = _scan; ref_btn.clicked.connect(_scan)
        return w

    # -- Anime page -----------------------------------------------------------------------
    def _build_anime_page(self) -> QWidget:
        AF = CONFIG_DIR / "anime_list.json"
        w = QWidget(); w.setStyleSheet(f"background:{C.NAVY};")
        lay = QVBoxLayout(w); lay.setContentsMargins(10,10,10,10); lay.setSpacing(8)
        hdr = QHBoxLayout()
        title = QLabel("ANIME LIST"); title.setFont(QFont("Courier New",9,QFont.Weight.Bold)); title.setStyleSheet(f"color:{C.GREEN};background:transparent;")
        cnt_lbl = QLabel("0 anime"); cnt_lbl.setFont(QFont("Courier New",7)); cnt_lbl.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;")
        hdr.addWidget(title); hdr.addStretch(); hdr.addWidget(cnt_lbl); lay.addLayout(hdr)
        fr = QHBoxLayout()
        fi = QLineEdit(); fi.setPlaceholderText("Search..."); fi.setFont(QFont("Courier New",7)); fi.setFixedHeight(24)
        fi.setStyleSheet(f"QLineEdit{{background:{C.CARD};color:{C.WHITE};border:1px solid {C.BORDER_G};border-radius:3px;padding:2px 8px;}}QLineEdit:focus{{border:1px solid {C.GREEN};}}")
        sf = QComboBox(); sf.addItems(["All","Watching","Completed","Plan to Watch","Dropped","On Hold"]); sf.setFixedHeight(24); sf.setFont(QFont("Courier New",7))
        sf.setStyleSheet(f"QComboBox{{background:{C.CARD};color:{C.WHITE};border:1px solid {C.BORDER_G};border-radius:3px;padding:1px 4px;}}QComboBox QAbstractItemView{{background:{C.PANEL};color:{C.WHITE};}}")
        fr.addWidget(fi,stretch=1); fr.addWidget(sf); lay.addLayout(fr)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet(f"QScrollArea{{background:transparent;border:none;}}QScrollBar:vertical{{background:{C.BG};width:4px;border:none;}}QScrollBar::handle:vertical{{background:{C.BORDER_G};border-radius:2px;}}")
        lw = QWidget(); lw.setStyleSheet("background:transparent;")
        ll = QVBoxLayout(lw); ll.setContentsMargins(0,0,0,0); ll.setSpacing(3); ll.addStretch()
        scroll.setWidget(lw); lay.addWidget(scroll, stretch=1)
        SC = {"Watching":C.GREEN,"Completed":C.TEAL,"Plan to Watch":C.TEXT_MED,"Dropped":C.RED,"On Hold":C.YELLOW}
        def _ld():
            try: return json.loads(AF.read_text(encoding="utf-8")) if AF.exists() else []
            except Exception: return []
        def _sv(d):
            try: os.makedirs(CONFIG_DIR,exist_ok=True); AF.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding="utf-8")
            except Exception: pass
        def _render(data=None):
            if data is None: data=_ld()
            filt=fi.text().strip().lower(); s=sf.currentText()
            filtered=[a for a in data if (not filt or filt in a.get("title","").lower()) and (s=="All" or a.get("status","")==s)]
            cnt_lbl.setText(f"{len(filtered)} / {len(data)} anime")
            while ll.count()>1:
                item=ll.takeAt(0)
                if item.widget(): item.widget().deleteLater()
            for a in filtered:
                row=QWidget(); row.setFixedHeight(48); sc=SC.get(a.get("status",""),C.TEXT_DIM)
                row.setStyleSheet(f"background:{C.CARD};border:1px solid {C.BORDER_G};border-left:3px solid {sc};border-radius:4px;")
                rl3=QHBoxLayout(row); rl3.setContentsMargins(8,4,8,4); rl3.setSpacing(6)
                inf=QVBoxLayout(); inf.setSpacing(1)
                tl=QLabel(a.get("title","?")); tl.setFont(QFont("Courier New",8,QFont.Weight.Bold)); tl.setStyleSheet(f"color:{C.WHITE};background:transparent;")
                sl=QLabel(f"{a.get('status','?')}  |  {a.get('rating','?')}/10  |  Ep {a.get('episodes','?')}"); sl.setFont(QFont("Courier New",6)); sl.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;")
                inf.addWidget(tl); inf.addWidget(sl); rl3.addLayout(inf,stretch=1)
                db2=QPushButton("X"); db2.setFixedSize(20,20); db2.setFlat(True); db2.setStyleSheet(f"color:{C.TEXT_DIM};background:transparent;"); db2.setCursor(Qt.CursorShape.PointingHandCursor)
                def _del(checked=False,t=a.get("title","")): d=_ld(); d=[x for x in d if x.get("title","")!=t]; _sv(d); _render(d)
                db2.clicked.connect(_del); rl3.addWidget(db2)
                ll.insertWidget(ll.count()-1, row)
        fi.textChanged.connect(lambda: _render()); sf.currentTextChanged.connect(lambda: _render()); _render()
        sec_lbl = QLabel("ADD ANIME"); sec_lbl.setFont(QFont("Courier New",7,QFont.Weight.Bold))
        sec_lbl.setStyleSheet(f"color:{C.GREEN};background:transparent;border-bottom:1px solid {C.BORDER_G};padding-bottom:2px;"); lay.addWidget(sec_lbl)
        add1=QHBoxLayout()
        ti=QLineEdit(); ti.setPlaceholderText("Anime title..."); ti.setFont(QFont("Courier New",8)); ti.setFixedHeight(28)
        ti.setStyleSheet(f"QLineEdit{{background:{C.CARD};color:{C.WHITE};border:1px solid {C.BORDER_G};border-radius:3px;padding:2px 8px;}}QLineEdit:focus{{border:1px solid {C.GREEN};}}")
        ri=QLineEdit(); ri.setPlaceholderText("Rating 1-10"); ri.setFixedWidth(70); ri.setFixedHeight(28); ri.setFont(QFont("Courier New",8)); ri.setStyleSheet(ti.styleSheet())
        add1.addWidget(ti,stretch=1); add1.addWidget(ri); lay.addLayout(add1)
        add2=QHBoxLayout()
        si=QComboBox(); si.addItems(["Completed","Watching","Plan to Watch","On Hold","Dropped"]); si.setFixedHeight(28); si.setFont(QFont("Courier New",8))
        si.setStyleSheet(f"QComboBox{{background:{C.CARD};color:{C.WHITE};border:1px solid {C.BORDER_G};border-radius:3px;padding:2px 4px;}}QComboBox QAbstractItemView{{background:{C.PANEL};color:{C.WHITE};}}")
        ei=QLineEdit(); ei.setPlaceholderText("Episodes"); ei.setFixedWidth(70); ei.setFixedHeight(28); ei.setFont(QFont("Courier New",8)); ei.setStyleSheet(ti.styleSheet())
        ab2=QPushButton("+ Add"); ab2.setFixedHeight(28); ab2.setFont(QFont("Courier New",8,QFont.Weight.Bold)); ab2.setCursor(Qt.CursorShape.PointingHandCursor)
        ab2.setStyleSheet(f"QPushButton{{background:{C.GREEN};color:{C.BG};border:none;border-radius:3px;padding:2px 10px;font-weight:bold;}}QPushButton:hover{{background:{C.GREEN_D};}}")
        add2.addWidget(si,stretch=1); add2.addWidget(ei); add2.addWidget(ab2); lay.addLayout(add2)
        def _add2():
            t=ti.text().strip()
            if not t: return
            entry={"title":t,"status":si.currentText(),"rating":ri.text().strip() or "?","episodes":ei.text().strip() or "?","added":__import__("datetime").datetime.now().strftime("%Y-%m-%d")}
            d=_ld()
            for idx,a in enumerate(d):
                if a.get("title","").lower()==t.lower(): d[idx]=entry; _sv(d); _render(d); ti.clear(); ri.clear(); ei.clear(); return
            d.insert(0,entry); _sv(d); _render(d); ti.clear(); ri.clear(); ei.clear()
            if self.on_text_command:
                threading.Thread(target=self.on_text_command,args=(f"I just added '{t}' to my anime list. Acknowledge briefly.",),daemon=True).start()
        ab2.clicked.connect(_add2); ti.returnPressed.connect(_add2)
        w._render_anime = _render
        return w

    # -- Command Palette -------------------------------------------------------------------
    def _open_palette(self):
        recent = getattr(self._transcript, "_command_history", [])
        dlg = CommandPalette(recent, self)
        dlg.command_selected.connect(self._run_palette_command)
        dlg.move(self.x()+(self.width()-dlg.width())//2, self.y()+(self.height()-dlg.height())//3)
        dlg.exec()

    def _run_palette_command(self, cmd: str):
        if not cmd: return
        self._on_nav("DASHBOARD")
        self._transcript.append_log(f"You: {cmd}")
        self._transcript.start_typing()
        if self.on_text_command:
            threading.Thread(target=self.on_text_command, args=(cmd,), daemon=True).start()

    # -- Event handlers ----------------------------------------------------------------------
    def _on_attach_clicked(self):
        path,_ = QFileDialog.getOpenFileName(self,"Attach file",str(Path.home()),"Images & Docs (*.png *.jpg *.jpeg *.gif *.webp *.bmp *.pdf *.txt *.py *.json *.csv);;All (*.*)")
        if not path: return
        p = Path(path); self._pending_file_path = path; self._current_file = path
        self._pending_file_lbl.setText(f"[FILE] {p.name}  ({_fmt_size(p.stat().st_size)})  -- will scan on send   X click to remove")
        self._pending_file_lbl.show()
        self._pending_file_lbl.mousePressEvent = lambda e: self._clear_pending_file()

    def _clear_pending_file(self):
        self._pending_file_path = None; self._pending_file_lbl.hide()

    def _send(self):
        txt = self._input.text().strip(); pending = getattr(self,"_pending_file_path",None)
        if not txt and not pending: return
        self._input.clear()
        if pending:
            self._clear_pending_file(); p = Path(pending); ext = p.suffix.lower().lstrip(".")
            display_txt = txt or f"Please scan and describe this file: {p.name}"
            self._transcript.append_log(f"You: {display_txt} [FILE: {p.name}]")
            self._transcript.start_typing()
            def _swf(user_text, file_path, extension):
                try:
                    img_exts = {"png","jpg","jpeg","gif","webp","bmp"}
                    if extension in img_exts:
                        msg = f"[IMAGE_ATTACHED] {Path(file_path).name}. User says: {user_text}. file_path={file_path}"
                    else:
                        try:
                            with open(file_path,"r",encoding="utf-8",errors="replace") as fh: content = fh.read(8000)
                            msg = f"[FILE_ATTACHED] filename={Path(file_path).name}\nContent:\n{content}\n\nUser instruction: {user_text}"
                        except Exception:
                            msg = f"[FILE_ATTACHED] filename={Path(file_path).name} (binary). User instruction: {user_text}"
                    if self.on_text_command: self.on_text_command(msg)
                except Exception as e: self._log_sig.emit(f"SYS: File attach error: {e}")
            threading.Thread(target=_swf,args=(display_txt,pending,ext),daemon=True).start()
        else:
            self._transcript.append_log(f"You: {txt}")
            self._transcript.start_typing()
            if self.on_text_command:
                threading.Thread(target=self.on_text_command, args=(txt,), daemon=True).start()

    def _toggle_mute(self):
        self._muted = not self._muted; self.hud.muted = self._muted; self._mic_btn.setChecked(self._muted)
        if self._muted: self._apply_state("MUTED"); self._transcript.append_log("SYS: Microphone muted.")
        else: self._apply_state("LISTENING"); self._transcript.append_log("SYS: Microphone active.")

    def _on_call_btn(self, checked):
        if checked:
            self._transcript.append_log("SYS: Session active -- Zero Two listening.")
            if self.on_text_command:
                threading.Thread(target=self.on_text_command,args=("[FORCE_WAKE] User pressed call button -- activate and say hello.",),daemon=True).start()
        else:
            self._transcript.append_log("SYS: Session paused.")

    def _on_vision_btn(self, checked):
        if checked:
            dlg = VisionSourceDialog(self); dlg.source_chosen.connect(self._start_feed)
            if not dlg.exec(): self._cam_btn.setChecked(False)
        else:
            self._feed.stop()

    def _start_feed(self, mode):
        self._feed.start(mode)
        label = "CAMERA" if mode=="camera" else f"SCREEN {mode.split(':')[-1] if ':' in mode else '1'}"
        self._transcript.append_log(f"SYS: Vision source: {label} -- live feed active.")

    def _apply_state(self, state):
        self.hud.state = state; self.hud.speaking = (state == "SPEAKING")
        # Drive character panel animation
        if hasattr(self, "_char_panel"):
            self._char_panel.set_speaking(state == "SPEAKING")
        if state in ("LISTENING","SLEEP","MUTED"):
            self._transcript.stop_typing()
        state_map = {
            "LISTENING":  ("♡  LISTENING",  C.GREEN),
            "SPEAKING":   ("◈  SPEAKING",   C.TEAL),
            "THINKING":   ("◆  THINKING",   C.YELLOW),
            "PROCESSING": ("▷  PROCESSING", C.ORANGE),
            "EXECUTION":  ("▶  EXECUTING",  C.ORANGE),
            "SLEEP":      ("◌  SLEEPING",   C.TEXT_DIM),
            "MUTED":      ("✕  MUTED",      C.RED),
        }
        label, col = state_map.get(state, ("◈  ONLINE", C.GREEN))
        self._status_text.setText(label)
        self._status_text.setStyleSheet(f"color:{C.TEXT};background:transparent;letter-spacing:1px;")
        self._status_dot.setStyleSheet(f"color:{col};background:transparent;")

    def _on_agent_update(self, key, status, msg):
        if key in self._agent_cards: self._agent_cards[key].update_status(status, msg)

    def _refresh_router_status(self):
        try:
            from ai_router import get_router
            s = get_router().status(); avail = s.get("available",[]); pref = s.get("preferred","gemini")
            if avail:
                lbl2 = f"{pref.upper()} active  |  {len(avail)} provider{'s' if len(avail)!=1 else ''}"
                cool = s.get("on_cooldown",[])
                if cool: lbl2 += f"  |  WARN {','.join(cool)} cooling"
                col = C.GREEN
            else:
                lbl2 = "No providers configured"; col = C.RED
            self._router_lbl.setText(lbl2); self._router_lbl.setStyleSheet(f"color:{col};background:transparent;")
        except Exception as e:
            self._router_lbl.setText(f"Router error: {e}"); self._router_lbl.setStyleSheet(f"color:{C.RED};background:transparent;")

    def _run_agent_report(self):
        self._transcript.append_log("SYS: Running agent report...")
        for key in self._agent_cards: self._agent_cards[key].update_status("working","Reporting...")
        QTimer.singleShot(900, self._finish_report)

    def _finish_report(self):
        for key,status,msg in [("planner","idle","Ready."),("coder","idle","No active tasks."),
                                ("tester","idle","All clear."),("reviewer","idle","No reviews."),
                                ("security","idle","System secure."),("voice","idle","Listening.")]:
            self._agent_cards[key].update_status(status,msg)
        self._transcript.append_log("SYS: Agent report complete.")

    def _on_settings_saved(self, s):
        self._settings = s; self._transcript.append_log("SYS: Settings saved.")
        try:
            from api_manager import reload_manager, get_manager
            reload_manager(); st = get_manager().status()
            self._transcript.append_log(f"SYS: API -> {st['active_provider'].upper()} ({st['selected_model']})")
        except Exception: pass
        try: self._refresh_router_status()
        except Exception: pass

    def _toggle_fs(self):
        self.showNormal() if self.isFullScreen() else self.showFullScreen()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if self._overlay and self._overlay.isVisible():
            cw = self.centralWidget(); ow, oh = 480, 460
            self._overlay.setGeometry((cw.width()-ow)//2, (cw.height()-oh)//2, ow, oh)

    def _build_tray(self) -> QSystemTrayIcon:
        tray = QSystemTrayIcon(self)
        from PyQt6.QtGui import QPixmap, QColor, QIcon
        pm = QPixmap(32,32); pm.fill(QColor(C.GREEN)); tray.setIcon(QIcon(pm))
        tray.setToolTip(f"Zero Two AI  v{_VERSION}  —  Running")
        menu = QMenu()
        menu.setStyleSheet(f"QMenu{{background:{C.PANEL};color:{C.WHITE};border:1px solid {C.BORDER_G};}}QMenu::item:selected{{background:{C.GREEN_GHO};color:{C.GREEN};}}")
        a_show   = menu.addAction("Show Zero Two")
        a_mute   = menu.addAction("Toggle Mute")
        menu.addSeparator()
        a_status = menu.addAction("Status Check")
        menu.addSeparator()
        a_quit   = menu.addAction("Quit")
        a_show.triggered.connect(self._tray_show)
        a_mute.triggered.connect(self._toggle_mute)
        a_status.triggered.connect(lambda: self.on_text_command and self.on_text_command("status check"))
        a_quit.triggered.connect(QApplication.quit)
        tray.setContextMenu(menu); tray.activated.connect(self._tray_activated); tray.show()
        return tray

    def _tray_show(self): self.showNormal(); self.raise_(); self.activateWindow()
    def _tray_activated(self, reason):
        if reason == QSystemTrayIcon.ActivationReason.DoubleClick: self._tray_show()

    def closeEvent(self, event):
        event.ignore(); self.hide()
        self._tray.showMessage("Zero Two AI","Running in background — double-click to restore.",QSystemTrayIcon.MessageIcon.Information,2500)

    def _check_config(self) -> bool:
        if not API_FILE.exists(): return False
        try:
            d = json.loads(API_FILE.read_text(encoding="utf-8"))
            return bool(d.get("gemini_api_key")) and bool(d.get("os_system"))
        except Exception: return False

    def _show_setup(self):
        ov = SetupOverlay(self.centralWidget()); cw = self.centralWidget()
        ow, oh = 480, 460  # slightly taller for badge + new layout
        ov.setGeometry((cw.width()-ow)//2, (cw.height()-oh)//2, ow, oh)
        ov.done.connect(self._on_setup_done); ov.show(); self._overlay = ov

    def _on_setup_done(self, key, os_name):
        os.makedirs(CONFIG_DIR, exist_ok=True)
        API_FILE.write_text(json.dumps({"gemini_api_key":key,"os_system":os_name},indent=4),encoding="utf-8")
        self._ready = True
        if self._overlay: self._overlay.hide(); self._overlay = None
        self._apply_state("LISTENING")
        self._transcript.append_log(f"SYS: ZERO TWO AI online  //  OS={os_name.upper()}")


# -- Zero Two Character Panel --------------------------------------------------
class CharacterPanel(QWidget):
    """
    Displays a Zero Two character portrait on the dashboard.
    Tries to load assets/zero_two.png (or jpg/webp) from the project folder.
    If no image is found, paints a stylised placeholder portrait using Qt
    drawing primitives — crimson/pink silhouette with glowing halo rings —
    so the panel always looks good even without the image file.

    To add a real Zero Two image: drop any PNG/JPG/WEBP named zero_two.png
    (or zero_two.jpg / zero_two.webp) into the `assets/` subfolder next to
    main.py.  Size ≥ 400×600 recommended; the panel will scale it to fit.
    """

    _IMG_PATHS = [
        BASE_DIR / "assets" / "zero_two.png",
        BASE_DIR / "assets" / "zero_two.jpg",
        BASE_DIR / "assets" / "zero_two.webp",
        BASE_DIR / "assets" / "zero_two.jpeg",
        BASE_DIR / "zero_two.png",
        BASE_DIR / "zero_two.jpg",
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self._pixmap = None
        self._speaking = False
        self._anim_phase = 0.0
        self._pulse = 0.0
        self._tgt_pulse = 0.8

        # Try to load a real image
        for p in self._IMG_PATHS:
            if p.exists():
                from PyQt6.QtGui import QPixmap as QP
                pm = QP(str(p))
                if not pm.isNull():
                    self._pixmap = pm
                    break

        # Gentle animation timer for halo pulse + speaking effect
        self._tmr = QTimer(self); self._tmr.timeout.connect(self._step); self._tmr.start(50)

    def set_speaking(self, speaking: bool):
        self._speaking = speaking
        self._tgt_pulse = 1.0 if speaking else 0.6

    def _step(self):
        self._anim_phase = (self._anim_phase + (0.06 if self._speaking else 0.025)) % (2*math.pi)
        self._pulse += (self._tgt_pulse - self._pulse) * 0.08
        self.update()

    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        W, H = self.width(), self.height()
        p.fillRect(self.rect(), qcol(C.BG, 0))  # transparent

        cx = W / 2; cy = H * 0.52
        r_base = min(W, H) * 0.38

        # -- outer atmospheric glow halos --
        for i in range(8):
            r = r_base * (1.6 - i * 0.04)
            a = max(0, int(30 * self._pulse * (1.0 - i/8)))
            col = C.GREEN if i < 4 else C.TEAL
            p.setPen(QPen(qcol(col, a), 2))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(QRectF(cx-r, cy-r, r*2, r*2))

        # -- pulsing scanner ring --
        pr = r_base * (1.2 + 0.12 * math.sin(self._anim_phase))
        p.setPen(QPen(qcol(C.GREEN, int(60 * self._pulse)), 1.5))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(QRectF(cx-pr, cy-pr, pr*2, pr*2))

        if self._pixmap:
            # -- draw real image, clipped to a rounded rectangle --
            target = QRectF(cx - r_base*1.1, cy - r_base*1.35, r_base*2.2, r_base*2.7)
            path = QPainterPath()
            path.addRoundedRect(target, 24, 24)
            p.setClipPath(path)

            scaled = self._pixmap.scaled(
                int(target.width()), int(target.height()),
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation
            )
            dx = cx - scaled.width()/2
            dy = target.top() + (target.height() - scaled.height())/2
            p.drawPixmap(int(dx), int(dy), scaled)
            p.setClipping(False)

            # -- crimson vignette frame over image edges --
            vgr = QRadialGradient(cx, cy, r_base*1.3)
            vgr.setColorAt(0.6, qcol(C.BG, 0))
            vgr.setColorAt(1.0, qcol(C.BG, 200))
            p.setBrush(QBrush(vgr)); p.setPen(Qt.PenStyle.NoPen)
            p.drawEllipse(QRectF(cx - r_base*1.4, cy - r_base*1.5, r_base*2.8, r_base*3.0))

        else:
            # -- painted placeholder portrait --
            self._paint_placeholder(p, cx, cy, r_base)

        # -- decorative corner marks --
        pen = QPen(qcol(C.BORDER_A, 80), 1.5)
        p.setPen(pen); p.setBrush(Qt.BrushStyle.NoBrush)
        m = 16; L = 18
        for px2, py2, dx2, dy2 in [(m,m,1,1),(W-m,m,-1,1),(m,H-m,1,-1),(W-m,H-m,-1,-1)]:
            p.drawLine(int(px2), int(py2), int(px2+dx2*L), int(py2))
            p.drawLine(int(px2), int(py2), int(px2), int(py2+dy2*L))

        # -- bottom label --
        p.setPen(QPen(qcol(C.TEXT_DIM, 140), 1))
        p.setFont(QFont("Arial", 7, QFont.Weight.Bold))
        label_rect = QRectF(0, H-22, W, 18)
        p.drawText(label_rect, Qt.AlignmentFlag.AlignCenter,
                   "SPEAKING..." if self._speaking else "ZERO TWO  //  02")

    def _paint_placeholder(self, p: QPainter, cx: float, cy: float, r: float):
        """Paint a stylised Zero Two silhouette when no image is available."""
        # Body silhouette — deep crimson
        body_grad = QRadialGradient(cx, cy + r*0.3, r*1.2)
        body_grad.setColorAt(0.0, qcol("#2a0810", 220))
        body_grad.setColorAt(0.7, qcol("#1a0508", 200))
        body_grad.setColorAt(1.0, qcol(C.BG, 0))
        body_path = QPainterPath()
        body_path.addEllipse(QRectF(cx - r*0.85, cy - r*0.2, r*1.7, r*2.4))
        p.fillPath(body_path, QBrush(body_grad))

        # Head / face oval
        head_r = r * 0.52; hcy = cy - r*0.25
        hgrad = QRadialGradient(cx, hcy, head_r)
        hgrad.setColorAt(0.0, qcol("#1e0608", 240))
        hgrad.setColorAt(1.0, qcol("#120406", 220))
        p.setBrush(QBrush(hgrad)); p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(QRectF(cx-head_r, hcy-head_r, head_r*2, head_r*2))

        # Hair — dark, flowing downward
        hair_path = QPainterPath()
        hair_path.moveTo(cx - head_r*0.9, hcy - head_r*0.5)
        hair_path.cubicTo(cx - r*0.9, hcy - r*0.8, cx - r*0.7, hcy + r*0.4, cx - r*0.5, hcy + r*0.8)
        hair_path.lineTo(cx + r*0.5, hcy + r*0.8)
        hair_path.cubicTo(cx + r*0.7, hcy + r*0.4, cx + r*0.9, hcy - r*0.8, cx + head_r*0.9, hcy - head_r*0.5)
        hair_path.cubicTo(cx + head_r*0.4, hcy - head_r*1.3, cx - head_r*0.4, hcy - head_r*1.3, cx - head_r*0.9, hcy - head_r*0.5)
        p.fillPath(hair_path, QBrush(qcol("#100308", 230)))

        # Horns — Zero Two's signature horns
        horn_col = qcol(C.TEAL, 180)
        p.setBrush(QBrush(horn_col)); p.setPen(Qt.PenStyle.NoPen)
        horn_L = QPainterPath()
        horn_L.moveTo(cx - head_r*0.55, hcy - head_r*0.6)
        horn_L.lineTo(cx - head_r*0.85, hcy - head_r*1.55)
        horn_L.lineTo(cx - head_r*0.25, hcy - head_r*0.9)
        horn_L.closeSubpath()
        horn_R = QPainterPath()
        horn_R.moveTo(cx + head_r*0.55, hcy - head_r*0.6)
        horn_R.lineTo(cx + head_r*0.85, hcy - head_r*1.55)
        horn_R.lineTo(cx + head_r*0.25, hcy - head_r*0.9)
        horn_R.closeSubpath()
        p.fillPath(horn_L, QBrush(qcol(C.TEAL, 200)))
        p.fillPath(horn_R, QBrush(qcol(C.TEAL, 200)))

        # Eyes — wide, slightly catlike
        eye_y = hcy - head_r*0.1; eye_rx = head_r*0.24; eye_ry = head_r*0.16
        for ex in [cx - head_r*0.34, cx + head_r*0.34]:
            p.setBrush(QBrush(qcol("#eef0ff", 230))); p.setPen(Qt.PenStyle.NoPen)
            p.drawEllipse(QRectF(ex-eye_rx, eye_y-eye_ry, eye_rx*2, eye_ry*2))
            p.setBrush(QBrush(qcol("#1a0d30", 240)))
            p.drawEllipse(QRectF(ex-eye_rx*0.62, eye_y-eye_ry*0.9, eye_rx*1.24, eye_ry*1.6))
            p.setBrush(QBrush(qcol(C.GREEN, 220)))
            p.drawEllipse(QRectF(ex-eye_rx*0.3, eye_y-eye_ry*0.55, eye_rx*0.6, eye_ry*0.9))

        # Blush marks
        p.setBrush(QBrush(qcol("#e86090", 60))); p.setPen(Qt.PenStyle.NoPen)
        for bx in [cx - head_r*0.55, cx + head_r*0.55]:
            p.drawEllipse(QRectF(bx-head_r*0.18, eye_y+eye_ry*0.8, head_r*0.36, head_r*0.12))

        # Mouth — slight smile
        p.setPen(QPen(qcol(C.TEAL, 160), 1.8)); p.setBrush(Qt.BrushStyle.NoBrush)
        mouth_path = QPainterPath()
        mouth_path.moveTo(cx - head_r*0.22, hcy + head_r*0.38)
        mouth_path.cubicTo(cx - head_r*0.1, hcy + head_r*0.5, cx + head_r*0.1, hcy + head_r*0.5, cx + head_r*0.22, hcy + head_r*0.38)
        p.drawPath(mouth_path)

        # Outfit collar/neckline — crimson
        coll_path = QPainterPath()
        coll_path.moveTo(cx - head_r*0.4, hcy + head_r*0.7)
        coll_path.lineTo(cx, hcy + head_r*1.1)
        coll_path.lineTo(cx + head_r*0.4, hcy + head_r*0.7)
        coll_path.lineTo(cx + head_r*0.65, hcy + head_r*0.85)
        coll_path.lineTo(cx, hcy + head_r*1.35)
        coll_path.lineTo(cx - head_r*0.65, hcy + head_r*0.85)
        coll_path.closeSubpath()
        p.fillPath(coll_path, QBrush(qcol(C.GREEN_D, 180)))

        # "Add zero_two.png" hint at bottom
        p.setPen(QPen(qcol(C.TEXT_DIM, 100), 1))
        p.setFont(QFont("Arial", 6))
        p.drawText(QRectF(0, cy + r*1.4, self.width(), 16),
                   Qt.AlignmentFlag.AlignCenter,
                   "Add assets/zero_two.png for her real portrait")


# -- Public UI API ----------------------------------------------------------------------
class _RootShim:
    def __init__(self, app): self._app = app
    def mainloop(self): self._app.exec()
    def protocol(self, *_): pass

class ZERO_TWOUI:
    def __init__(self, face_path, size=None):
        self._app = QApplication.instance() or QApplication(sys.argv)
        self._app.setStyle("Fusion")

        # PIN lock gate -- if enabled, block here until the correct PIN is
        # entered. This runs before the main window is constructed/shown,
        # so the AI/dashboard is completely inaccessible until unlocked.
        if lock_is_enabled():
            while True:
                dlg = LockScreenDialog(mode="verify")
                dlg.forgot_pin.connect(lambda d=dlg: self._handle_forgot_pin(d))
                result = dlg.exec()
                if result == QDialog.DialogCode.Accepted:
                    break
                if getattr(dlg, "_reset_requested", False):
                    if lock_is_enabled():
                        # User chose "create a new PIN" -- loop back into a
                        # setup dialog, then re-verify with the new PIN.
                        setup_dlg = LockScreenDialog(mode="setup")
                        setup_dlg.exec()
                        continue
                    else:
                        # User chose "remove lock entirely" -- proceed unlocked.
                        break
                # exec() only returns non-Accepted (and no reset requested)
                # if the dialog was rejected programmatically (e.g. app
                # quit during lock); exit rather than looping forever.
                self._app.quit()
                sys.exit(0)

        self._win = MainWindow(face_path); self._win.show()
        self.root = _RootShim(self._app)

    def _handle_forgot_pin(self, dlg: "LockScreenDialog"):
        """
        Called when the user taps "Forgot PIN?" on the lock screen.
        Offers two safe choices, both of which require explicit confirmation
        since they affect the security of the device:
          - "Create new PIN"   -> removes the old PIN and immediately opens
                                   setup mode for a fresh one (still locked
                                   to anyone who can't pass setup -- though
                                   note setup itself has no prior-PIN check,
                                   so this is "physical access = reset",
                                   same tradeoff as most consumer devices).
          - "Remove PIN lock"  -> disables the lock entirely; app opens
                                   unlocked. User can re-enable + set a new
                                   PIN later from Settings.
          - Cancel             -> returns to the PIN entry screen, no change.
        """
        box = QMessageBox(dlg)
        box.setWindowTitle("Reset PIN")
        box.setIcon(QMessageBox.Icon.Question)
        box.setText("You can create a new PIN or remove the lock entirely.\n\n"
                     "Anyone with access to this device can choose either "
                     "option, so only use this if you've truly forgotten "
                     "your PIN.")
        new_pin_btn = box.addButton("Create New PIN", QMessageBox.ButtonRole.AcceptRole)
        remove_btn  = box.addButton("Remove PIN Lock", QMessageBox.ButtonRole.DestructiveRole)
        box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
        box.setStyleSheet(f"QMessageBox{{background:{C.PANEL};color:{C.WHITE};}}"
                           f"QLabel{{color:{C.WHITE};background:transparent;}}"
                           f"QPushButton{{background:{C.CARD};color:{C.WHITE};border:1px solid {C.BORDER_G};border-radius:4px;padding:4px 10px;}}"
                           f"QPushButton:hover{{border:1px solid {C.GREEN};}}")
        box.exec()
        clicked = box.clickedButton()

        if clicked is new_pin_btn:
            remove_lock()
            dlg._reset_requested = True
            dlg.reject()
        elif clicked is remove_btn:
            remove_lock()
            dlg._reset_requested = True
            dlg.reject()
        # else Cancel -- do nothing, stay on the PIN entry screen

    @property
    def muted(self) -> bool: return self._win._muted
    @muted.setter
    def muted(self, v):
        if v != self._win._muted: self._win._toggle_mute()

    @property
    def current_file(self): return self._win._current_file

    @property
    def on_text_command(self): return self._win.on_text_command
    @on_text_command.setter
    def on_text_command(self, cb): self._win.on_text_command = cb

    def set_state(self, state):      self._win._state_sig.emit(state)
    def write_log(self, text):       self._win._log_sig.emit(text)
    def update_agent(self, key, status, msg=""):
        self._win._agent_sig.emit(key, status, msg)
    def wait_for_api_key(self):
        while not self._win._ready: time.sleep(0.1)
    def start_speaking(self):  self.set_state("SPEAKING")
    def stop_speaking(self):
        if not self.muted: self.set_state("LISTENING")
        try: self._win._transcript.stop_typing()
        except Exception: pass

    def stream_response(self, text: str):
        """Animate an AI response with character-by-character reveal."""
        try: self._win._transcript.stream_ai_response(text)
        except Exception: self.write_log(f"ZERO TWO: {text}")
