# ZERO TWO — VERIFIED AUDIT REPORT

SYNTAX: 37 OK, 0 errors

IMPORTS:
  OK load_settings at top-level
  OK api_manager imported
  FAIL system_monitor imported
  FAIL emotion_agent imported
  FAIL godmode_agent imported
  FAIL wake_word imported
  FAIL autostart imported
  OK confirm_dialog imported

VOICE AUDIT:
  No hardcoded voice_name found

BRANDING AUDIT:
  All clean

FEATURE CHECKS:
  [OK  ] Screen: monitor index tracked in UI
  [FAIL] Screen: continuous monitor wired in main
  [OK  ] Screen: _capture_screen function exists
  [OK  ] Screen: capture library available
  [OK  ] Voice: ZERO_TWO_VOICE constant defined
  [OK  ] Voice: constant used in main
  [OK  ] Voice: constant used in screen_processor
  [OK  ] Upload: attach button handler exists
  [OK  ] Upload: pending file state tracked
  [OK  ] Wake: 'Hey Zero Two' in phrases
  [OK  ] Wake: notify_user_spoke method
  [OK  ] Wake: auto-sleep timeout
  [OK  ] Tray: system tray present
  [OK  ] Tray: minimize-to-tray on close
  [OK  ] API: ProviderStatus constants
  [OK  ] API: real test_provider function
  [OK  ] API: which_model function
  [OK  ] API: diagnostics function
  [OK  ] API: 'which model' command handled
  [OK  ] Metrics: pynvml for RTX GPU
  [OK  ] Metrics: k10temp for Ryzen
  [OK  ] Metrics: GPU usage field
  [OK  ] Metrics: GPU temp field
  [OK  ] Metrics: GPU VRAM field
  [OK  ] Metrics: LibreHardwareMonitor support
  [OK  ] Emotion: emotion_agent.py exists
  [OK  ] Emotion: EmotionAgent used in main

SUMMARY: 1 failures found