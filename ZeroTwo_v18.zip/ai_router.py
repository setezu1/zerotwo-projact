"""
ai_router.py — Multi-model AI router for ZERO TWO
Primary  : Google Gemini (gemini-2.5-flash)
Backup 1 : OpenAI      (gpt-4o-mini)
Backup 2 : Anthropic   (claude-3-5-haiku)

Used for: text completions, tool routing, fallback when Gemini Live drops.
The Live audio session in main.py always uses Gemini directly.
This router is for non-audio tasks (agent planning, code generation, etc.)
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

# ── Config ────────────────────────────────────────────────────────────────────

def _base_dir() -> Path:
    import sys
    return Path(sys.executable).parent if getattr(sys,"frozen",False) else Path(__file__).resolve().parent

_CFG_PATH = _base_dir() / "config" / "api_keys.json"
_SETTINGS = _base_dir() / "config" / "settings.json"

def _load_keys() -> dict:
    try:
        return json.loads(_CFG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}

def _load_settings() -> dict:
    try:
        return json.loads(_SETTINGS.read_text(encoding="utf-8"))
    except Exception:
        return {}


# ── Router ────────────────────────────────────────────────────────────────────

class AIRouter:
    """
    Simple text-completion router with automatic fallback.
    Call: router.complete(prompt, system="...", max_tokens=500)
    Returns: (text_response, model_used)
    """

    MODELS = [
        ("gemini",    "gemini-2.0-flash"),
        ("openai",    "gpt-4o-mini"),
        ("anthropic", "claude-haiku-4-5"),
    ]

    def __init__(self):
        self._keys    = _load_keys()
        self._settings= _load_settings()
        self._failures: dict[str, int] = {}   # model → consecutive failures
        self._last_try: dict[str, float] = {}  # model → last attempt time
        self._COOLDOWN = 60.0  # seconds before retrying a failed model

    def _preferred_model(self) -> str:
        """Read model preference from settings."""
        m = self._settings.get("ai_model", "gemini-2.5-flash").lower()
        if "openai" in m or "gpt" in m:
            return "openai"
        if "claude" in m or "anthropic" in m:
            return "anthropic"
        return "gemini"

    def complete(
        self,
        prompt:     str,
        system:     str  = "You are ZERO TWO, a helpful AI assistant.",
        max_tokens: int  = 1000,
        temperature:float= 0.7,
    ) -> tuple[str, str]:
        """
        Returns (response_text, model_name_used).
        Tries each backend in priority order with cooldown on failures.
        """
        # Reload keys in case user updated them in settings
        self._keys = _load_keys()

        preferred = self._preferred_model()
        order = self.MODELS[:]
        # Move preferred to front
        order.sort(key=lambda x: 0 if x[0] == preferred else 1)

        for provider, model_id in order:
            if self._is_on_cooldown(provider):
                continue
            try:
                resp = self._call(provider, model_id, prompt, system, max_tokens, temperature)
                self._failures[provider] = 0  # reset on success
                return resp, f"{provider}/{model_id}"
            except Exception as e:
                print(f"[AIRouter] ❌ {provider} failed: {e}")
                self._failures[provider] = self._failures.get(provider, 0) + 1
                self._last_try[provider] = time.time()

        return "All AI backends unavailable. Please check your API keys.", "none"

    def _is_on_cooldown(self, provider: str) -> bool:
        fails = self._failures.get(provider, 0)
        if fails < 2:
            return False
        last = self._last_try.get(provider, 0)
        return (time.time() - last) < self._COOLDOWN

    def _call(
        self,
        provider:    str,
        model_id:    str,
        prompt:      str,
        system:      str,
        max_tokens:  int,
        temperature: float,
    ) -> str:
        if provider == "gemini":
            return self._call_gemini(model_id, prompt, system, max_tokens, temperature)
        elif provider == "openai":
            return self._call_openai(model_id, prompt, system, max_tokens, temperature)
        elif provider == "anthropic":
            return self._call_anthropic(model_id, prompt, system, max_tokens, temperature)
        raise ValueError(f"Unknown provider: {provider}")

    # ── Gemini ────────────────────────────────────────────────────────────────

    def _call_gemini(self, model_id, prompt, system, max_tokens, temperature) -> str:
        import google.generativeai as genai
        key = self._keys.get("gemini_api_key","")
        if not key:
            raise ValueError("No Gemini API key")
        genai.configure(api_key=key)
        model = genai.GenerativeModel(
            model_name=model_id,
            system_instruction=system,
        )
        response = model.generate_content(
            prompt,
            generation_config=genai.GenerationConfig(
                max_output_tokens=max_tokens,
                temperature=temperature,
            )
        )
        return response.text.strip()

    # ── OpenAI ────────────────────────────────────────────────────────────────

    def _call_openai(self, model_id, prompt, system, max_tokens, temperature) -> str:
        try:
            import openai
        except ImportError:
            raise ImportError("openai not installed — run: pip install openai")
        key = self._keys.get("openai_api_key", os.environ.get("OPENAI_API_KEY",""))
        if not key:
            raise ValueError("No OpenAI API key")
        client = openai.OpenAI(api_key=key)
        resp = client.chat.completions.create(
            model=model_id,
            messages=[
                {"role": "system",  "content": system},
                {"role": "user",    "content": prompt},
            ],
            max_tokens=max_tokens,
            temperature=temperature,
        )
        return resp.choices[0].message.content.strip()

    # ── Anthropic ─────────────────────────────────────────────────────────────

    def _call_anthropic(self, model_id, prompt, system, max_tokens, temperature) -> str:
        try:
            import anthropic
        except ImportError:
            raise ImportError("anthropic not installed — run: pip install anthropic")
        key = self._keys.get("anthropic_api_key", os.environ.get("ANTHROPIC_API_KEY",""))
        if not key:
            raise ValueError("No Anthropic API key")
        client = anthropic.Anthropic(api_key=key)
        msg = client.messages.create(
            model=model_id,
            max_tokens=max_tokens,
            system=system,
            messages=[{"role":"user","content":prompt}],
        )
        return msg.content[0].text.strip()

    # ── Convenience ──────────────────────────────────────────────────────────

    def available_providers(self) -> list[str]:
        """Returns list of providers that have an API key configured."""
        avail = []
        keys  = _load_keys()
        if keys.get("gemini_api_key"):     avail.append("gemini")
        if keys.get("openai_api_key"):     avail.append("openai")
        if keys.get("anthropic_api_key"):  avail.append("anthropic")
        return avail

    def status(self) -> dict:
        return {
            "preferred":   self._preferred_model(),
            "available":   self.available_providers(),
            "failures":    dict(self._failures),
            "on_cooldown": [p for p in ["gemini","openai","anthropic"] if self._is_on_cooldown(p)],
        }


# Singleton
_router: AIRouter | None = None

def get_router() -> AIRouter:
    global _router
    if _router is None:
        _router = AIRouter()
    return _router


def quick_complete(prompt: str, system: str = "You are ZERO TWO, a helpful AI assistant.",
                   max_tokens: int = 500) -> str:
    """Convenience function — returns just the text response."""
    text, model = get_router().complete(prompt, system=system, max_tokens=max_tokens)
    print(f"[AIRouter] ✅ Responded via {model}")
    return text
