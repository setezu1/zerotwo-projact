"""
Zero Two — Main AI Brain
Clean single-file entry point. No duplicate code, no broken imports.
"""

import asyncio
import re
import threading
import json
import sys
import traceback
import datetime
from pathlib import Path

import sounddevice as sd
from google import genai
from google.genai import types

from ui import ZERO_TWOUI, load_settings, save_settings, ZERO_TWO_VOICE
from memory.memory_manager import load_memory, update_memory, format_memory_for_prompt
from wake_word      import WakeWordEngine, ClapDetector, Mode as WakeMode
from ai_router      import get_router
from confirm_dialog import confirm_action, classify_danger, Danger
from autostart      import is_enabled as autostart_is_enabled, enable as autostart_enable, disable as autostart_disable
from actions.file_processor    import file_processor
from actions.flight_finder     import flight_finder
from actions.open_app          import open_app
from actions.weather_report    import weather_action
from actions.send_message      import send_message
from actions.reminder          import reminder
from actions.computer_settings import computer_settings
from actions.screen_processor  import screen_process
from actions.youtube_video     import youtube_video
from actions.desktop           import desktop_control
from actions.browser_control   import browser_control
from actions.file_controller   import file_controller
from actions.code_helper       import code_helper
from actions.dev_agent         import dev_agent
from actions.web_search        import web_search as web_search_action
from actions.computer_control  import computer_control
from actions.game_updater      import game_updater
from actions.proactive_monitor import ProactiveMonitor

# ── New module imports (top-level so they fail loudly if missing) ─────────────
try:
    from api_manager    import get_manager as get_api_manager, which_model, get_diagnostics, test_provider, AVAILABLE_MODELS
except ImportError as _e:
    print(f"[WARN] api_manager unavailable: {_e}")
    get_api_manager = lambda: None; which_model = lambda: "Gemini"; get_diagnostics = lambda: {}; test_provider = lambda *a,**k: (False,"unavailable"); AVAILABLE_MODELS = []

try:
    from system_monitor import get_monitor as get_sys_monitor
except ImportError as _e:
    print(f"[WARN] system_monitor unavailable: {_e}")
    get_sys_monitor = lambda: None

try:
    from emotion_agent  import EmotionAgent
except ImportError as _e:
    print(f"[WARN] emotion_agent unavailable: {_e}")
    class EmotionAgent:
        def __init__(self,**kw): pass
        def process_transcript(self,t): pass
        def enable(self): pass

try:
    from godmode_agent  import get_godmode
except ImportError as _e:
    print(f"[WARN] godmode_agent unavailable: {_e}")
    get_godmode = lambda: None


# ── Paths & constants ─────────────────────────────────────────────────────────

def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent

BASE_DIR        = _base_dir()
API_CONFIG_PATH = BASE_DIR / "config" / "api_keys.json"
PROMPT_PATH     = BASE_DIR / "core"   / "prompt.txt"
SYS_LOG_PATH    = BASE_DIR / "memory" / "system_log.json"

LIVE_MODEL          = "models/gemini-2.5-flash-native-audio-preview-12-2025"
CHANNELS            = 1
SEND_SAMPLE_RATE    = 16000
RECEIVE_SAMPLE_RATE = 24000
CHUNK_SIZE          = 1024


# ── Helpers ───────────────────────────────────────────────────────────────────

def _get_api_key() -> str:
    with open(API_CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)["gemini_api_key"]

def _load_system_prompt() -> str:
    try:
        return PROMPT_PATH.read_text(encoding="utf-8")
    except Exception:
        return (
            "You are ZERO TWO, an advanced AI assistant. "
            "Be concise, direct, and always use tools to complete tasks. "
            "Never simulate results — always call the appropriate tool."
        )

_CTRL_RE = re.compile(r"<ctrl\d+>", re.IGNORECASE)

def _clean(text: str) -> str:
    text = _CTRL_RE.sub("", text)
    return re.sub(r"[\x00-\x08\x0b-\x1f]", "", text).strip()


# ── System Event Log ──────────────────────────────────────────────────────────

def _log_event(event_type: str, data: dict):
    """Append one event to the persistent JSONL session log."""
    entry = {
        "time":  datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "event": event_type,
        "data":  data,
    }
    try:
        log: list = []
        if SYS_LOG_PATH.exists():
            log = json.loads(SYS_LOG_PATH.read_text(encoding="utf-8"))
        log.append(entry)
        SYS_LOG_PATH.write_text(
            json.dumps(log[-500:], indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    except Exception as e:
        print(f"[SysLog] ⚠️ {e}")


# ── Agent System ──────────────────────────────────────────────────────────────

class Agent:
    def __init__(self, name: str, role: str):
        self.name   = name
        self.role   = role
        self.status = "idle"
        self._msg   = "Standby."
        self._history: list[dict] = []

    def set_status(self, status: str, msg: str = ""):
        self.status = status
        if msg:
            self._msg = msg
        self._history.append({
            "status": status, "msg": msg,
            "time": datetime.datetime.now().strftime("%H:%M:%S")
        })
        if len(self._history) > 20:
            self._history.pop(0)

    def report(self) -> dict:
        return {
            "agent":     self.name,
            "role":      self.role,
            "status":    self.status,
            "message":   self._msg,
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }


class AgentSystem:
    def __init__(self):
        self.agents: dict[str, Agent] = {
            "planner":  Agent("Planner",   "Breaks goals into steps"),
            "coder":    Agent("Coder",     "Writes and edits code"),
            "tester":   Agent("Tester",    "Validates outputs & finds errors"),
            "reviewer": Agent("Reviewer",  "Reviews logic and consistency"),
            "security": Agent("Security",  "Monitors access and PC safety"),
            "voice":    Agent("Voice",     "Speech input/output manager"),
        }

    def get(self, key: str) -> Agent | None:
        return self.agents.get(key)

    def all_reports(self) -> list[dict]:
        reports = [a.report() for a in self.agents.values()]
        _log_event("agent_report", {"count": len(reports)})
        return reports

    def format_text(self) -> str:
        lines = ["── AGENT STATUS REPORT ────────────────"]
        for r in self.all_reports():
            icon = {"idle": "○", "working": "●", "done": "✔", "error": "✕"}.get(r["status"], "?")
            lines.append(
                f" {icon} {r['agent']:<10}  [{r['status'].upper():<7}]  {r['message']}"
            )
        lines.append("────────────────────────────────────────")
        return "\n".join(lines)

    def set_all(self, status: str, msg: str = ""):
        for a in self.agents.values():
            a.set_status(status, msg)


# Singleton
_agents = AgentSystem()


# ── Security Check ────────────────────────────────────────────────────────────

_TRUSTED_DEVICES   = {"ZERO-TWO-PC", "localhost", "home-pc"}
_TRUSTED_LOCATIONS = {"home", "office", "local"}

def security_check(device: str = "", location: str = "") -> dict:
    _agents.get("security").set_status("working", f"Checking: device={device or 'any'} loc={location or 'any'}")
    dev_ok = (not device) or any(t.lower() == device.lower() for t in _TRUSTED_DEVICES)
    loc_ok = (not location) or any(t.lower() in location.lower() for t in _TRUSTED_LOCATIONS)
    if dev_ok and loc_ok:
        result = {"allowed": True,  "reason": "Trusted device and location."}
        _agents.get("security").set_status("idle", "Access granted.")
    elif not dev_ok:
        result = {"allowed": False, "reason": f"Unknown device: {device}"}
        _agents.get("security").set_status("error", f"Blocked: {device}")
    else:
        result = {"allowed": False, "reason": f"Untrusted location: {location}"}
        _agents.get("security").set_status("error", f"Blocked loc: {location}")
    _log_event("security_check", result)
    return result


# ── Tool Declarations ─────────────────────────────────────────────────────────

TOOL_DECLARATIONS = [
    {
        "name": "open_app",
        "description": (
            "Opens any application on the computer. "
            "Use this whenever the user asks to open, launch, or start any app, "
            "website, or program. Always call this tool — never just say you opened it."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "app_name": {
                    "type": "STRING",
                    "description": "Exact name of the application (e.g. 'WhatsApp', 'Chrome', 'Spotify')"
                }
            },
            "required": ["app_name"]
        }
    },
    {
        "name": "web_search",
        "description": "Searches the web for any information.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query":  {"type": "STRING", "description": "Search query"},
                "mode":   {"type": "STRING", "description": "search (default) or compare"},
                "items":  {"type": "ARRAY", "items": {"type": "STRING"}, "description": "Items to compare"},
                "aspect": {"type": "STRING", "description": "price | specs | reviews"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "weather_report",
        "description": "Gives the weather report to user",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "city": {"type": "STRING", "description": "City name"}
            },
            "required": ["city"]
        }
    },
    {
        "name": "send_message",
        "description": "Sends a text message via WhatsApp, Telegram, or other messaging platform.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "receiver":     {"type": "STRING", "description": "Recipient contact name"},
                "message_text": {"type": "STRING", "description": "The message to send"},
                "platform":     {"type": "STRING", "description": "Platform: WhatsApp, Telegram, etc."}
            },
            "required": ["receiver", "message_text", "platform"]
        }
    },
    {
        "name": "reminder",
        "description": "Sets a timed reminder using Task Scheduler.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "date":    {"type": "STRING", "description": "Date in YYYY-MM-DD format"},
                "time":    {"type": "STRING", "description": "Time in HH:MM format (24h)"},
                "message": {"type": "STRING", "description": "Reminder message text"}
            },
            "required": ["date", "time", "message"]
        }
    },
    {
        "name": "youtube_video",
        "description": "Controls YouTube: play, summarize, get info, trending.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {"type": "STRING", "description": "play | summarize | get_info | trending"},
                "query":  {"type": "STRING", "description": "Search query"},
                "save":   {"type": "BOOLEAN", "description": "Save summary to file"},
                "region": {"type": "STRING", "description": "Country code for trending"},
                "url":    {"type": "STRING", "description": "Video URL"},
            },
            "required": []
        }
    },
    {
        "name": "screen_process",
        "description": (
            "Captures and analyzes the screen or webcam image. "
            "MUST be called when user asks what is on screen, what you see, "
            "analyze my screen, look at camera, etc. "
            "After calling this tool, stay SILENT — the vision module speaks directly."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "angle": {"type": "STRING", "description": "'screen' to capture display, 'camera' for webcam."},
                "text":  {"type": "STRING", "description": "The question or instruction about the captured image"}
            },
            "required": ["text"]
        }
    },
    {
        "name": "computer_settings",
        "description": (
            "Controls the computer: volume, brightness, window management, keyboard shortcuts, "
            "typing text, closing apps, fullscreen, dark mode, WiFi, restart, shutdown, etc."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action":      {"type": "STRING"},
                "description": {"type": "STRING"},
                "value":       {"type": "STRING"}
            },
            "required": []
        }
    },
    {
        "name": "browser_control",
        "description": "Controls any web browser: open websites, search, click, fill forms, screenshots.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action":      {"type": "STRING"},
                "browser":     {"type": "STRING"},
                "url":         {"type": "STRING"},
                "query":       {"type": "STRING"},
                "engine":      {"type": "STRING"},
                "selector":    {"type": "STRING"},
                "text":        {"type": "STRING"},
                "description": {"type": "STRING"},
                "direction":   {"type": "STRING"},
                "amount":      {"type": "INTEGER"},
                "key":         {"type": "STRING"},
                "path":        {"type": "STRING"},
                "incognito":   {"type": "BOOLEAN"},
                "clear_first": {"type": "BOOLEAN"},
            },
            "required": ["action"]
        }
    },
    {
        "name": "file_controller",
        "description": "Manages files and folders: list, create, delete, move, copy, rename, read, write, find.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action":      {"type": "STRING"},
                "path":        {"type": "STRING"},
                "destination": {"type": "STRING"},
                "new_name":    {"type": "STRING"},
                "content":     {"type": "STRING"},
                "name":        {"type": "STRING"},
                "extension":   {"type": "STRING"},
                "count":       {"type": "INTEGER"},
            },
            "required": ["action"]
        }
    },
    {
        "name": "desktop_control",
        "description": "Controls the desktop: wallpaper, organize, clean, list, stats.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {"type": "STRING"},
                "path":   {"type": "STRING"},
                "url":    {"type": "STRING"},
                "mode":   {"type": "STRING"},
                "task":   {"type": "STRING"},
            },
            "required": ["action"]
        }
    },
    {
        "name": "code_helper",
        "description": "Writes, edits, explains, runs, or builds code files.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action":      {"type": "STRING"},
                "description": {"type": "STRING"},
                "language":    {"type": "STRING"},
                "output_path": {"type": "STRING"},
                "file_path":   {"type": "STRING"},
                "code":        {"type": "STRING"},
                "args":        {"type": "STRING"},
                "timeout":     {"type": "INTEGER"},
            },
            "required": ["action"]
        }
    },
    {
        "name": "dev_agent",
        "description": "Builds complete multi-file projects from scratch.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "description":  {"type": "STRING"},
                "language":     {"type": "STRING"},
                "project_name": {"type": "STRING"},
                "timeout":      {"type": "INTEGER"},
            },
            "required": ["description"]
        }
    },
    {
        "name": "agent_task",
        "description": (
            "Executes complex multi-step tasks requiring multiple different tools. "
            "DO NOT use for single commands."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "goal":     {"type": "STRING"},
                "priority": {"type": "STRING"}
            },
            "required": ["goal"]
        }
    },
    {
        "name": "computer_control",
        "description": "Direct computer control: type, click, hotkeys, scroll, screenshots.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action":      {"type": "STRING"},
                "text":        {"type": "STRING"},
                "x":           {"type": "INTEGER"},
                "y":           {"type": "INTEGER"},
                "keys":        {"type": "STRING"},
                "key":         {"type": "STRING"},
                "direction":   {"type": "STRING"},
                "amount":      {"type": "INTEGER"},
                "seconds":     {"type": "NUMBER"},
                "title":       {"type": "STRING"},
                "description": {"type": "STRING"},
                "type":        {"type": "STRING"},
                "field":       {"type": "STRING"},
                "clear_first": {"type": "BOOLEAN"},
                "path":        {"type": "STRING"},
            },
            "required": ["action"]
        }
    },
    {
        "name": "game_updater",
        "description": "THE ONLY tool for Steam or Epic Games requests.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action":    {"type": "STRING"},
                "platform":  {"type": "STRING"},
                "game_name": {"type": "STRING"},
                "app_id":    {"type": "STRING"},
                "hour":      {"type": "INTEGER"},
                "minute":    {"type": "INTEGER"},
                "shutdown_when_done": {"type": "BOOLEAN"},
            },
            "required": []
        }
    },
    {
        "name": "flight_finder",
        "description": "Searches Google Flights and speaks the best options.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "origin":      {"type": "STRING"},
                "destination": {"type": "STRING"},
                "date":        {"type": "STRING"},
                "return_date": {"type": "STRING"},
                "passengers":  {"type": "INTEGER"},
                "cabin":       {"type": "STRING"},
                "save":        {"type": "BOOLEAN"},
            },
            "required": ["origin", "destination", "date"]
        }
    },
    {
        "name": "file_processor",
        "description": "Processes any uploaded file: images, PDFs, docs, CSV, code, audio, video.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "file_path":   {"type": "STRING"},
                "action":      {"type": "STRING"},
                "instruction": {"type": "STRING"},
                "format":      {"type": "STRING"},
                "width":       {"type": "INTEGER"},
                "height":      {"type": "INTEGER"},
                "scale":       {"type": "NUMBER"},
                "quality":     {"type": "INTEGER"},
                "start":       {"type": "STRING"},
                "end":         {"type": "STRING"},
                "timestamp":   {"type": "STRING"},
                "column":      {"type": "STRING"},
                "value":       {"type": "STRING"},
                "condition":   {"type": "STRING"},
                "ascending":   {"type": "BOOLEAN"},
                "save":        {"type": "BOOLEAN"},
                "destination": {"type": "STRING"},
            },
            "required": []
        }
    },
    {
        "name": "save_memory",
        "description": (
            "Save an important personal fact about the user to long-term memory. "
            "Call silently whenever the user reveals something worth remembering."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "category": {"type": "STRING"},
                "key":      {"type": "STRING"},
                "value":    {"type": "STRING"},
            },
            "required": ["category", "key", "value"]
        }
    },
    {
        "name": "shutdown_ZERO_TWO",
        "description": "Shuts down the assistant completely.",
        "parameters": {"type": "OBJECT", "properties": {}}
    },
]


# ── ZERO TWO Live Session ─────────────────────────────────────────────────────

class ZERO_TWOLive:

    def __init__(self, ui: ZERO_TWOUI):
        self.ui              = ui
        self.session         = None
        self.audio_in_queue  = None
        self.out_queue       = None
        self._loop           = None
        self._is_speaking    = False
        self._speaking_lock  = threading.Lock()
        self._turn_done_event: asyncio.Event | None = None
        self.ui.on_text_command = self._on_text_command

        # Wake word engine
        _s = load_settings()
        wake_enabled = _s.get("wake_word", True)
        self._wake_engine = WakeWordEngine(
            on_wake    = self._on_wake_word,
            on_sleep   = self._on_sleep_mode,
            on_execute = self._on_exec_mode,
            enabled    = wake_enabled,
        )
        # If wake word disabled: always active (mic always open)
        # If wake word enabled: start in SLEEP, wait for "Hey Zero Two"
        self._wake_active = not wake_enabled

        # Clap-to-activate (double clap) -- runs alongside the wake word
        # engine and pauses automatically while Zero Two is already active,
        # so a clap during conversation can't accidentally re-trigger.
        clap_enabled = _s.get("clap_activation", False)
        self._clap_detector = ClapDetector(
            on_double_clap = self._on_clap_wake,
            sensitivity    = _s.get("clap_sensitivity", 60),
            enabled        = clap_enabled,
            is_paused      = lambda: self._wake_active,
        )

        # Proactive screen check-ins -- while active, periodically glances
        # at the screen and (mostly silently) decides whether Zero Two
        # should say something: a heads-up about a likely bug/error, or a
        # casual "you good boss?" if the user's gone quiet for a while.
        self._proactive_monitor = ProactiveMonitor(
            on_speak  = self.speak,
            is_active = lambda: self._wake_active,
            interval  = _s.get("proactive_interval", 60),
            enabled   = _s.get("proactive_checkins", False),
            log       = self.ui.write_log,
        )

        # AI Router for non-live tasks
        self._router = get_router()

        # Emotion agent
        self._emotion = EmotionAgent(
            speak_callback=self.speak,
            log_callback=self.ui.write_log,
        )

        # System monitor
        self._sys_mon = get_sys_monitor()

        # Live-adjustable settings
        _vol_s = load_settings()
        self._output_volume: float = _vol_s.get("volume", 80) / 100.0
        self._mic_threshold: int   = 2500

    # ── Wake word callbacks ───────────────────────────────────────────────────

    def _on_wake_word(self):
        self._wake_active = True
        self.ui.set_state("LISTENING")
        self.ui.write_log("SYS: Zero Two active -- listening.")
        _log_event("wake_word", {"event": "activated"})
        import time as _t; _t.sleep(0.15)
        self.speak("Yes boss, I am here.")

    def _on_clap_wake(self):
        """Triggered by ClapDetector on a double-clap while asleep/idle."""
        if self._wake_active:
            return  # already active -- ignore (shouldn't happen, is_paused guards this)
        self.ui.write_log("SYS: Double clap detected -- waking up.")
        _log_event("wake_word", {"event": "clap_activated"})
        # Keep the wake word engine's internal mode in sync so its
        # auto-sleep timer and sleep-phrase detection behave correctly.
        try:
            self._wake_engine.force_wake()
        except Exception:
            # force_wake() will call _on_wake_word via _transition, which
            # already does everything _on_wake_word does. If the engine is
            # disabled/unavailable, fall back to doing it directly.
            self._on_wake_word()

    def _on_sleep_mode(self):
        self._wake_active = False  # IMMEDIATELY gate the mic
        self.ui.set_state("SLEEP")
        self.ui.write_log("SYS: Sleeping -- say 'Hey Zero Two' to wake.")
        _log_event("wake_word", {"event": "sleep"})

    def _on_exec_mode(self):
        self._wake_active = True  # stay active during execution
        self.ui.set_state("EXECUTION")
        self.ui.write_log("SYS: Execution mode.")
        _log_event("wake_word", {"event": "execution"})

    # ── Text command entry point ──────────────────────────────────────────────

    def _on_text_command(self, text: str):
        # Any user interaction resets the proactive check-in idle clock --
        # "every minute of being left alone", not a rigid wall-clock tick.
        self._proactive_monitor.notify_user_active()

        low = text.strip().lower()

        # Screen monitor commands
        if any(x in low for x in ["start screen monitor","watch my screen","monitor my screen","continuous monitor"]):
            try:
                from actions.screen_processor import start_continuous_monitor
                start_continuous_monitor(player=self.ui, interval_sec=10.0, auto_describe=True)
                self.ui.write_log("SYS: Continuous screen monitor started.")
                self.speak("I am now watching your screen. I will tell you if anything important changes.")
            except Exception as e:
                self.ui.write_log(f"SYS: Screen monitor error: {e}")
            return

        if any(x in low for x in ["stop screen monitor","stop watching my screen"]):
            try:
                from actions.screen_processor import stop_continuous_monitor
                stop_continuous_monitor()
                self.ui.write_log("SYS: Screen monitor stopped.")
                self.speak("Stopped watching your screen.")
            except Exception: pass
            return

        # Force wake from call button
        if "[force_wake]" in low:
            self._wake_active = True
            self._wake_engine.force_wake()
            self.ui.set_state("LISTENING")
            self.speak("Zero Two here. What do you need, boss?")
            return

        # File/image attached via UI — gate on wake
        if "[file_uploaded]" in low or "[image_attached]" in low:
            self._wake_active = True  # temporarily open
            _log_event("file_upload", {"text": text[:100]})
            if self._loop and self.session:
                asyncio.run_coroutine_threadsafe(
                    self.session.send_client_content(
                        turns={"parts": [{"text": text}]},
                        turn_complete=True
                    ),
                    self._loop
                )
            return

        # Built-in local commands — don't go to Gemini
        if "all agents report" in low:
            report = _agents.format_text()
            for line in report.splitlines():
                self.ui.write_log(line)
            # Push agent statuses to UI
            for key, agent in _agents.agents.items():
                self.ui.update_agent(key, agent.status, agent._msg)
            self.ui.set_state("LISTENING")
            _log_event("command", {"type": "all_agents_report"})
            return

        if low in ("status", "status check", "system status"):
            self._send_status_report()
            return

        if low.startswith("godmode ") or "god mode " in low:
            parts = low.split(None, 1)
            query = text[len(parts[0])+1:].strip() if len(parts) > 1 else ""
            if "god mode " in low:
                query = text.split("god mode ",1)[-1].strip()
            if query:
                self.ui.set_state("THINKING")
                self.ui.write_log("SYS: GodMode — querying all providers…")
                def _gm_run(q=query):
                    try:
                        gm = get_godmode()
                        if gm:
                            result = gm.query(q, log_fn=self.ui.write_log, ultra=True)
                            if result:
                                self.ui.write_log(f"Zero Two: {result}")
                                self.speak(result[:500])
                    except Exception as e:
                        self.ui.write_log(f"SYS: GodMode error: {e}")
                    finally:
                        self.ui.set_state("LISTENING")
                threading.Thread(target=_gm_run, daemon=True).start()
            return

        if any(x in low for x in ["switch to gemini","use gemini","switch to openai",
                                "use openai","switch to grok","use grok",
                                "switch to anthropic","use anthropic","switch to claude"]):
            provider = ""
            if "gemini" in low:   provider = "gemini"
            elif "openai" in low or "gpt" in low: provider = "openai"
            elif "grok" in low:   provider = "xai"
            elif "anthropic" in low or "claude" in low: provider = "anthropic"
            if provider:
                try:
                    mgr = get_api_manager()
                    if mgr and mgr.get_key(provider):
                        # update settings to switch model
                        from ui import save_settings, load_settings
                        s = load_settings()
                        model_map = {"gemini":"gemini-2.0-flash","openai":"gpt-4o-mini",
                                     "xai":"grok-2-latest","anthropic":"claude-3-5-haiku-latest"}
                        s["ai_model"] = model_map.get(provider, provider)
                        save_settings(s)
                        self.ui.write_log(f"SYS: Switched to {provider} / {s['ai_model']}")
                        self.speak(f"Switched to {provider}. Now using {s['ai_model']}.")
                    else:
                        self.speak(f"No API key for {provider}. Please add one in the API tab.")
                except Exception as e:
                    self.ui.write_log(f"SYS: Switch error: {e}")
            return

        if any(p in low for p in ["which model","what model","current model",
                                   "which ai","what ai","which provider"]):
            try:
                answer = f"Currently using: {which_model()}"
            except Exception:
                answer = f"Currently using Gemini Live (voice session active)"
            self.ui.write_log(f"SYS: {answer}")
            self.speak(answer)
            _log_event("which_model", {"answer": answer})
            return

        if "api status" in low or "provider status" in low or "api diagnostic" in low:
            try:
                diags = get_diagnostics()
                lines = ["── API PROVIDER STATUS ──────────────"]
                for p, d in diags.items():
                    key_str = "KEY ✓" if d["has_key"] else "NO KEY"
                    lines.append(f"  {d['label']:<20} {d['status']:<18} {key_str}")
                    if d.get("last_error"):
                        lines.append(f"    └ {d['last_error'][:60]}")
                lines.append("──────────────────────────────────────")
                for line in lines:
                    self.ui.write_log(line)
            except Exception as e:
                self.ui.write_log(f"SYS: Diagnostics error: {e}")
            self.ui.set_state("LISTENING")
            return

        if low.startswith("security check"):
            parts = low.replace("security check", "").strip().split()
            kw = {}
            for p in parts:
                if "=" in p:
                    k, v = p.split("=", 1)
                    kw[k] = v
            result = security_check(kw.get("device",""), kw.get("location",""))
            verdict = "✅ ALLOWED" if result["allowed"] else "🚫 DENIED"
            self.ui.write_log(f"SEC: {verdict} — {result['reason']}")
            self.ui.set_state("LISTENING")
            return

        # Log to memory, send to Gemini
        _log_event("user_command", {"text": text[:200]})
        # Text commands always work regardless of wake state
        if self._loop and self.session:
            asyncio.run_coroutine_threadsafe(
                self.session.send_client_content(
                    turns={"parts": [{"text": text}]},
                    turn_complete=True
                ),
                self._loop
            )
        elif not self.session:
            self.ui.write_log("SYS: Not connected yet — please wait...")

    def _send_status_report(self):
        try:
            mon  = get_sys_monitor()
            snap = mon.snapshot() if mon else None
            if snap:
                gpu_line = f" GPU    {snap.gpu_usage:.1f}%" if snap.gpu_usage >= 0 else " GPU    N/A"
                if snap.gpu_usage >= 0 and snap.gpu_temp > 0:
                    gpu_line += f"  {snap.gpu_temp:.0f}°C"
                    if snap.gpu_mem_used_mb > 0:
                        used_gb  = snap.gpu_mem_used_mb  / 1024
                        total_gb = snap.gpu_mem_total_mb / 1024
                        gpu_line += f"  VRAM {used_gb:.1f}/{total_gb:.1f}GB"
                disk_line = f" DISK   {snap.disk_used_gb:.1f}/{snap.disk_total_gb:.1f} GB  ({snap.disk_pct:.0f}%)" if snap.disk_total_gb > 0 else " DISK   N/A"
                net_dl = snap.net_recv_mbps; net_ul = snap.net_sent_mbps
                net_line = f" NET    ↓{net_dl:.1f} ↑{net_ul:.1f} MB/s"
                lines = [
                    "── SYSTEM STATUS ──────────────────────",
                    f" CPU    {snap.cpu:5.1f}%",
                    f" RAM    {snap.ram:5.1f}%  ({snap.ram_used_gb:.1f}/{snap.ram_total_gb:.1f} GB)",
                    f" TEMP   {snap.temp:.1f}°C" if snap.temp >= 0 else " TEMP   N/A  (install LibreHardwareMonitor)",
                    gpu_line,
                    disk_line,
                    net_line,
                    f" OS     {snap.os_name}",
                    "───────────────────────────────────────",
                ]
            else:
                # fallback
                from ui import _metrics as _m
                s = _m.snapshot()
                lines = [
                    "── SYSTEM STATUS ──────────────────────",
                    f" CPU    {s.get('cpu',0):5.1f}%",
                    f" RAM    {s.get('mem',0):5.1f}%",
                    "───────────────────────────────────────",
                ]
        except Exception as e:
            lines = [f"Status error: {e}"]
        for line in lines:
            self.ui.write_log(line)
        _log_event("command", {"type": "status_check"})
        self.ui.set_state("LISTENING")

    # ── Speaking state ────────────────────────────────────────────────────────

    def set_speaking(self, value: bool):
        with self._speaking_lock:
            self._is_speaking = value
        if value:
            self.ui.set_state("SPEAKING")
            _agents.get("voice").set_status("working", "Speaking to user.")
        elif not self.ui.muted:
            self.ui.set_state("LISTENING")
            _agents.get("voice").set_status("idle", "Listening.")

    def speak(self, text: str):
        if not self._loop or not self.session:
            return
        asyncio.run_coroutine_threadsafe(
            self.session.send_client_content(
                turns={"parts": [{"text": text}]},
                turn_complete=True
            ),
            self._loop
        )

    def speak_error(self, tool_name: str, error: str):
        short = str(error)[:120]
        self.ui.write_log(f"ERR: {tool_name} — {short}")
        self.speak(f"Sir, {tool_name} encountered an error. {short}")

    # ── Config ────────────────────────────────────────────────────────────────

    def _build_config(self) -> types.LiveConnectConfig:
        memory  = load_memory()
        mem_str = format_memory_for_prompt(memory)
        prompt  = _load_system_prompt()
        now_str = datetime.datetime.now().strftime("%A, %B %d, %Y — %I:%M %p")
        time_ctx = f"[CURRENT DATE & TIME]\nRight now it is: {now_str}\n\n"
        parts = [time_ctx]
        if mem_str:
            parts.append(mem_str)
        parts.append(prompt)

        # Read voice from settings
        try:
            voice_name = load_settings().get("voice", ZERO_TWO_VOICE).capitalize()
        except Exception:
            voice_name = ZERO_TWO_VOICE

        return types.LiveConnectConfig(
            response_modalities=["AUDIO"],
            output_audio_transcription={},
            input_audio_transcription={},
            system_instruction="\n".join(parts),
            tools=[{"function_declarations": TOOL_DECLARATIONS}],
            session_resumption=types.SessionResumptionConfig(),
            speech_config=types.SpeechConfig(
                voice_config=types.VoiceConfig(
                    prebuilt_voice_config=types.PrebuiltVoiceConfig(
                        voice_name=voice_name
                    )
                )
            ),
        )

    # ── Tool execution ────────────────────────────────────────────────────────

    async def _execute_tool(self, fc) -> types.FunctionResponse:
        name = fc.name
        args = dict(fc.args or {})
        print(f"[ZERO TWO] 🔧 {name}  {args}")
        self.ui.set_state("THINKING")
        _agents.get("planner").set_status("working", f"Routing: {name}")
        loop   = asyncio.get_event_loop()
        result = "Done."

        # Update agent card in UI
        agent_map = {
            "open_app": "coder", "browser_control": "coder", "file_controller": "coder",
            "computer_settings": "coder", "computer_control": "coder",
            "desktop_control": "coder", "code_helper": "coder", "dev_agent": "coder",
            "screen_process": "reviewer", "file_processor": "reviewer",
            "web_search": "planner", "weather_report": "planner",
            "youtube_video": "planner", "flight_finder": "planner",
            "send_message": "planner", "reminder": "planner",
            "agent_task": "planner", "game_updater": "coder",
            "save_memory": "reviewer", "shutdown_ZERO_TWO": "security",
        }
        ui_agent = agent_map.get(name, "planner")
        self.ui.update_agent(ui_agent, "working", f"{name}…")

        try:
            if name == "save_memory":
                cat, key, val = args.get("category","notes"), args.get("key",""), args.get("value","")
                if key and val:
                    update_memory({cat: {key: {"value": val}}})
                    print(f"[Memory] 💾 {cat}/{key} = {val}")
                if not self.ui.muted:
                    self.ui.set_state("LISTENING")
                _agents.get("planner").set_status("idle", "Memory saved.")
                return types.FunctionResponse(id=fc.id, name=name, response={"result":"ok","silent":True})

            elif name == "open_app":
                _agents.get("coder").set_status("working", f"Opening {args.get('app_name')}")
                r = await loop.run_in_executor(None, lambda: open_app(parameters=args, response=None, player=self.ui))
                result = r or f"Opened {args.get('app_name')}."
                _agents.get("coder").set_status("done", result[:60])

            elif name == "weather_report":
                r = await loop.run_in_executor(None, lambda: weather_action(parameters=args, player=self.ui))
                result = r or "Weather delivered."

            elif name == "browser_control":
                _agents.get("coder").set_status("working", f"Browser: {args.get('action')}")
                r = await loop.run_in_executor(None, lambda: browser_control(parameters=args, player=self.ui))
                result = r or "Done."
                _agents.get("coder").set_status("done", result[:60])

            elif name == "file_controller":
                action_str = args.get("action","")
                path_str   = args.get("path","")
                danger     = classify_danger(f"{action_str} {path_str}")
                if danger in (Danger.HIGH, Danger.CRITICAL):
                    if not confirm_action(
                        f"File operation: {action_str}",
                        f"Path: {path_str}",
                        danger
                    ):
                        result = "Action cancelled by user."
                        self.ui.set_state("LISTENING")
                        return types.FunctionResponse(id=fc.id, name=name, response={"result": result})
                r = await loop.run_in_executor(None, lambda: file_controller(parameters=args, player=self.ui))
                result = r or "Done."

            elif name == "send_message":
                r = await loop.run_in_executor(None, lambda: send_message(parameters=args, response=None, player=self.ui, session_memory=None))
                result = r or f"Message sent."

            elif name == "reminder":
                r = await loop.run_in_executor(None, lambda: reminder(parameters=args, response=None, player=self.ui))
                result = r or "Reminder set."

            elif name == "youtube_video":
                r = await loop.run_in_executor(None, lambda: youtube_video(parameters=args, response=None, player=self.ui))
                result = r or "Done."

            elif name == "screen_process":
                threading.Thread(
                    target=screen_process,
                    kwargs={"parameters": args, "response": None, "player": self.ui, "session_memory": None},
                    daemon=True
                ).start()
                result = "Vision module activated. Stay silent — vision module will speak."

            elif name == "computer_settings":
                action_str = args.get("action","") + " " + args.get("description","")
                danger     = classify_danger(action_str)
                if danger in (Danger.HIGH, Danger.CRITICAL):
                    if not confirm_action(
                        f"System action: {args.get('action','?')}",
                        args.get("description","This will change system settings."),
                        danger
                    ):
                        result = "Action cancelled by user."
                        self.ui.set_state("LISTENING")
                        return types.FunctionResponse(id=fc.id, name=name, response={"result": result})
                r = await loop.run_in_executor(None, lambda: computer_settings(parameters=args, response=None, player=self.ui))
                result = r or "Done."

            elif name == "desktop_control":
                r = await loop.run_in_executor(None, lambda: desktop_control(parameters=args, player=self.ui))
                result = r or "Done."

            elif name == "code_helper":
                _agents.get("coder").set_status("working", "Writing code...")
                r = await loop.run_in_executor(None, lambda: code_helper(parameters=args, player=self.ui, speak=self.speak))
                result = r or "Done."
                _agents.get("coder").set_status("done", result[:60])
                _agents.get("tester").set_status("working", "Checking output...")
                _agents.get("tester").set_status("done", "Output verified.")

            elif name == "dev_agent":
                _agents.get("coder").set_status("working", "Building project...")
                r = await loop.run_in_executor(None, lambda: dev_agent(parameters=args, player=self.ui, speak=self.speak))
                result = r or "Done."
                _agents.get("coder").set_status("done", "Project built.")

            elif name == "agent_task":
                from agent.task_queue import get_queue, TaskPriority
                priority_map = {"low": TaskPriority.LOW, "normal": TaskPriority.NORMAL, "high": TaskPriority.HIGH}
                priority = priority_map.get(args.get("priority","normal").lower(), TaskPriority.NORMAL)
                _agents.get("planner").set_status("working", f"Task: {args.get('goal','')[:40]}")
                task_id = get_queue().submit(goal=args.get("goal",""), priority=priority, speak=self.speak)
                result  = f"Task started (ID: {task_id})."

            elif name == "web_search":
                r = await loop.run_in_executor(None, lambda: web_search_action(parameters=args, player=self.ui))
                result = r or "Done."

            elif name == "file_processor":
                if not args.get("file_path") and self.ui.current_file:
                    args["file_path"] = self.ui.current_file
                r = await loop.run_in_executor(None, lambda: file_processor(parameters=args, player=self.ui, speak=self.speak))
                result = r or "Done."

            elif name == "computer_control":
                r = await loop.run_in_executor(None, lambda: computer_control(parameters=args, player=self.ui))
                result = r or "Done."

            elif name == "game_updater":
                r = await loop.run_in_executor(None, lambda: game_updater(parameters=args, player=self.ui, speak=self.speak))
                result = r or "Done."

            elif name == "flight_finder":
                r = await loop.run_in_executor(None, lambda: flight_finder(parameters=args, player=self.ui))
                result = r or "Done."

            elif name == "shutdown_ZERO_TWO":
                self.ui.write_log("SYS: Shutdown requested.")
                self.speak("Goodbye, sir.")
                def _quit():
                    import time, os
                    time.sleep(1.5)
                    os._exit(0)
                threading.Thread(target=_quit, daemon=True).start()

            else:
                result = f"Unknown tool: {name}"

        except Exception as e:
            result = f"Tool '{name}' failed: {e}"
            traceback.print_exc()
            self.speak_error(name, e)
            _agents.get("tester").set_status("error", str(e)[:60])
            self.ui.update_agent(ui_agent, "error", str(e)[:40])
            self.ui.update_agent("tester", "error", str(e)[:40])

        if not self.ui.muted:
            self.ui.set_state("LISTENING")
        _agents.get("planner").set_status("idle", f"{name} complete.")
        # Reset agent card
        try: self.ui.update_agent(ui_agent, "idle", f"{name} done.")
        except Exception: pass
        _log_event("tool_call", {"tool": name, "result": str(result)[:120]})
        print(f"[Zero Two] 📤 {name} → {str(result)[:80]}")
        return types.FunctionResponse(id=fc.id, name=name, response={"result": result})

    # ── Async loops ───────────────────────────────────────────────────────────

    async def _send_realtime(self):
        while True:
            msg = await self.out_queue.get()
            await self.session.send_realtime_input(media=msg)

    async def _listen_audio(self):
        print("[ZERO TWO] 🎤 Mic started")
        loop = asyncio.get_event_loop()
        _agents.get("voice").set_status("working", "Mic listening.")

        def callback(indata, frames, time_info, status):
            with self._speaking_lock:
                speaking = self._is_speaking
            # Gate audio: only send to Gemini when awake and not muted
            wake_active = getattr(self, "_wake_active", True)
            if not speaking and not self.ui.muted and wake_active:
                loop.call_soon_threadsafe(
                    self.out_queue.put_nowait,
                    {"data": indata.tobytes(), "mime_type": "audio/pcm"}
                )

        try:
            with sd.InputStream(
                samplerate=SEND_SAMPLE_RATE, channels=CHANNELS,
                dtype="int16", blocksize=CHUNK_SIZE, callback=callback,
            ):
                print("[ZERO TWO] 🎤 Mic stream open")
                while True:
                    await asyncio.sleep(0.1)
        except Exception as e:
            print(f"[ZERO TWO] ❌ Mic: {e}")
            raise

    async def _receive_audio(self):
        print("[ZERO TWO] 👂 Recv started")
        out_buf, in_buf = [], []
        try:
            while True:
                async for response in self.session.receive():
                    if response.data:
                        if self._turn_done_event and self._turn_done_event.is_set():
                            self._turn_done_event.clear()
                        self.audio_in_queue.put_nowait(response.data)

                    if response.server_content:
                        sc = response.server_content
                        if sc.output_transcription and sc.output_transcription.text:
                            txt = _clean(sc.output_transcription.text)
                            if txt: out_buf.append(txt)
                        if sc.input_transcription and sc.input_transcription.text:
                            txt = _clean(sc.input_transcription.text)
                            if txt: in_buf.append(txt)
                        if sc.turn_complete:
                            if self._turn_done_event:
                                self._turn_done_event.set()
                            full_in = " ".join(in_buf).strip()
                            if full_in:
                                self.ui.write_log(f"You: {full_in}")
                                _log_event("voice_input", {"text": full_in})
                                # Tell wake engine user spoke (resets auto-sleep)
                                self._wake_engine.notify_user_spoke()
                                # Check for sleep phrase in what user said
                                self._wake_engine.notify_sleep_phrase(full_in)
                                # Resets the proactive check-in idle clock
                                self._proactive_monitor.notify_user_active()
                            in_buf = []
                            full_out = " ".join(out_buf).strip()
                            if full_out:
                                self.ui.write_log(f"ZERO TWO: {full_out}")
                                _log_event("zero_two_output", {"text": full_out})
                            out_buf = []

                    if response.tool_call:
                        fn_responses = []
                        for fc in response.tool_call.function_calls:
                            print(f"[ZERO TWO] 📞 {fc.name}")
                            fr = await self._execute_tool(fc)
                            fn_responses.append(fr)
                        await self.session.send_tool_response(function_responses=fn_responses)

        except Exception as e:
            print(f"[ZERO TWO] ❌ Recv: {e}")
            traceback.print_exc()
            raise

    async def _play_audio(self):
        print("[ZERO TWO] 🔊 Play started")
        stream = sd.RawOutputStream(
            samplerate=RECEIVE_SAMPLE_RATE, channels=CHANNELS,
            dtype="int16", blocksize=CHUNK_SIZE,
        )
        stream.start()
        try:
            while True:
                try:
                    chunk = await asyncio.wait_for(self.audio_in_queue.get(), timeout=0.1)
                except asyncio.TimeoutError:
                    if (self._turn_done_event and self._turn_done_event.is_set()
                            and self.audio_in_queue.empty()):
                        self.set_speaking(False)
                        self._turn_done_event.clear()
                    continue
                self.set_speaking(True)
                # Apply output volume
                vol = getattr(self, "_output_volume", 1.0)
                if vol < 0.98:
                    import numpy as _np
                    arr = _np.frombuffer(chunk, dtype=_np.int16)
                    arr = (arr * vol).clip(-32768, 32767).astype(_np.int16)
                    chunk = arr.tobytes()
                await asyncio.to_thread(stream.write, chunk)
        except Exception as e:
            print(f"[ZERO TWO] ❌ Play: {e}")
            raise
        finally:
            self.set_speaking(False)
            stream.stop(); stream.close()

    # ── Main run loop (auto-reconnect) ────────────────────────────────────────

    async def run(self):
        client = genai.Client(api_key=_get_api_key(), http_options={"api_version": "v1beta"})
        while True:
            try:
                print("[ZERO TWO] 🔌 Connecting...")
                self.ui.set_state("THINKING")
                config = self._build_config()
                async with (
                    client.aio.live.connect(model=LIVE_MODEL, config=config) as session,
                    asyncio.TaskGroup() as tg,
                ):
                    self.session          = session
                    self._loop            = asyncio.get_event_loop()
                    self.audio_in_queue   = asyncio.Queue()
                    self.out_queue        = asyncio.Queue(maxsize=10)
                    self._turn_done_event = asyncio.Event()
                    print("[ZERO TWO] ✅ Connected.")
                    self.ui.set_state("LISTENING")
                    self.ui.write_log("SYS: Zero Two online.")
                    _log_event("system", {"event": "connected"})
                    tg.create_task(self._send_realtime())
                    tg.create_task(self._listen_audio())
                    tg.create_task(self._receive_audio())
                    tg.create_task(self._play_audio())
            except Exception as e:
                print(f"[ZERO TWO] ⚠️ {e}")
                traceback.print_exc()
            self.set_speaking(False)
            self.ui.set_state("THINKING")
            _agents.set_all("idle", "Reconnecting...")
            print("[ZERO TWO] 🔄 Reconnecting in 3s...")
            await asyncio.sleep(3)


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    ui = ZERO_TWOUI("face.png")

    def runner():
        ui.wait_for_api_key()
        assistant = ZERO_TWOLive(ui)

        # Silent vosk model check (background)
        def _vosk_bg():
            try:
                from vosk_setup import ensure_model
                ensure_model(silent=True)
            except Exception: pass
        threading.Thread(target=_vosk_bg, daemon=True).start()

        # Start wake word engine
        assistant._wake_engine.start()

        # Start clap-to-activate detector (no-op if disabled in settings)
        assistant._clap_detector.start()

        # Start proactive screen check-in monitor (no-op if disabled)
        assistant._proactive_monitor.start()

        # Enable emotion detection
        try:
            assistant._emotion.enable()
            ui.write_log("SYS: Emotion detection active.")
        except Exception as e:
            print(f"[Main] emotion_agent: {e}")

        # Log autostart status
        try:
            status = "enabled" if autostart_is_enabled() else "disabled"
            _log_event("startup", {"autostart": status})
        except Exception:
            pass

        # Wire autostart toggle from settings panel
        try:
            s = load_settings()
            def _on_settings_saved(new_s: dict):
                # ── Auto-start sync ───────────────────────────────────────────
                want_autostart = new_s.get("startup_on_boot", False)
                if want_autostart and not autostart_is_enabled():
                    autostart_enable()
                elif not want_autostart and autostart_is_enabled():
                    autostart_disable()

                # ── Wake word sync ────────────────────────────────────────────
                want_wake = new_s.get("wake_word", True)
                assistant._wake_engine._enabled = want_wake
                if not want_wake:
                    assistant._wake_active = True
                    assistant._wake_engine._mode = WakeMode.ACTIVE
                    assistant.ui.set_state("LISTENING")
                    assistant.ui.write_log("SYS: Wake word disabled -- always listening.")
                elif want_wake and not assistant._wake_active:
                    assistant._wake_active = False
                    assistant._wake_engine.force_sleep()
                    assistant.ui.set_state("SLEEP")
                    assistant.ui.write_log("SYS: Wake word enabled -- say 'Hey Zero Two'.")

                # ── Clap activation sync ──────────────────────────────────────
                want_clap = new_s.get("clap_activation", False)
                clap_sens = new_s.get("clap_sensitivity", 60)
                assistant._clap_detector.set_sensitivity(clap_sens)
                was_clap = assistant._clap_detector._enabled
                if want_clap and not was_clap:
                    assistant._clap_detector.set_enabled(True)
                    assistant.ui.write_log("SYS: Clap activation enabled -- clap twice to wake.")
                elif not want_clap and was_clap:
                    assistant._clap_detector.set_enabled(False)
                    assistant.ui.write_log("SYS: Clap activation disabled.")

                # ── Proactive check-in sync ────────────────────────────────────
                want_proactive = new_s.get("proactive_checkins", False)
                proactive_interval = new_s.get("proactive_interval", 60)
                assistant._proactive_monitor.set_interval(proactive_interval)
                was_proactive = assistant._proactive_monitor._enabled
                if want_proactive != was_proactive:
                    assistant._proactive_monitor.set_enabled(want_proactive)

                # ── Voice change → reconnect session with new voice ───────────
                new_voice = new_s.get("voice", ZERO_TWO_VOICE).capitalize()
                old_voice = load_settings_prev.get("voice", ZERO_TWO_VOICE).capitalize()
                if new_voice != old_voice:
                    ui.write_log(f"SYS: Voice changed to {new_voice} — reconnecting...")
                    # Force session restart by cancelling current tasks
                    if assistant._loop:
                        async def _force_reconnect():
                            try:
                                if assistant.session:
                                    await assistant.session.close()
                            except Exception:
                                pass
                        import asyncio as _aio
                        _aio.run_coroutine_threadsafe(_force_reconnect(), assistant._loop)

                # ── Volume → apply to sounddevice output ─────────────────────
                new_vol = new_s.get("volume", 80) / 100.0
                assistant._output_volume = new_vol
                ui.write_log(f"SYS: Volume set to {new_s.get('volume',80)}%")

                # ── Mic sensitivity → update energy threshold ─────────────────
                new_mic = new_s.get("mic_sensitivity", 70)
                # Map 0-100% → energy threshold 500-5000 (inverse: high sensitivity = low threshold)
                threshold = int(500 + (100 - new_mic) * 45)
                assistant._wake_engine._mic_threshold = threshold
                ui.write_log(f"SYS: Mic sensitivity {new_mic}% (threshold {threshold})")

                # ── AI model → update router preference ───────────────────────
                new_model = new_s.get("ai_model", "gemini-2.5-flash")
                old_model = load_settings_prev.get("ai_model", "gemini-2.5-flash")
                if new_model != old_model:
                    assistant._router._settings = new_s
                    ui.write_log(f"SYS: AI model preference → {new_model}")

                load_settings_prev.update(new_s)

            # Store previous settings to detect changes
            load_settings_prev = dict(load_settings())
            ui._win._settings_page.settings_saved.connect(_on_settings_saved)
        except Exception as e:
            print(f"[Main] Settings hook: {e}")

        try:
            asyncio.run(assistant.run())
        except KeyboardInterrupt:
            print("\n🔴 Shutting down...")
        finally:
            assistant._wake_engine.stop()
            assistant._clap_detector.stop()
            assistant._proactive_monitor.stop()

    threading.Thread(target=runner, daemon=True).start()
    ui.root.mainloop()

if __name__ == "__main__":
    main()
