"""
autostart.py — Auto-start ZERO TWO with Windows / macOS / Linux

Windows : HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run
macOS   : ~/Library/LaunchAgents/com.zero_two.ai.plist
Linux   : ~/.config/autostart/zero_two.desktop
"""
from __future__ import annotations

import os
import platform
import sys
from pathlib import Path

_OS = platform.system()


def _exe_path() -> str:
    """Return the path to launch ZERO TWO (frozen exe or python script)."""
    if getattr(sys, "frozen", False):
        return str(Path(sys.executable).resolve())
    # Running as script
    script = Path(__file__).resolve().parent / "main.py"
    python = sys.executable
    return f'"{python}" "{script}"'


# ── Windows ───────────────────────────────────────────────────────────────────

def _win_is_enabled() -> bool:
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0, winreg.KEY_READ,
        )
        winreg.QueryValueEx(key, "ZeroTwoAI")
        winreg.CloseKey(key)
        return True
    except Exception:
        return False

def _win_enable():
    import winreg
    key = winreg.OpenKey(
        winreg.HKEY_CURRENT_USER,
        r"Software\Microsoft\Windows\CurrentVersion\Run",
        0, winreg.KEY_SET_VALUE,
    )
    winreg.SetValueEx(key, "ZeroTwoAI", 0, winreg.REG_SZ, _exe_path())
    winreg.CloseKey(key)
    print("[AutoStart] ✅ Windows registry entry added.")

def _win_disable():
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0, winreg.KEY_SET_VALUE,
        )
        winreg.DeleteValue(key, "ZeroTwoAI")
        winreg.CloseKey(key)
        print("[AutoStart] 🗑 Windows registry entry removed.")
    except FileNotFoundError:
        pass


# ── macOS ─────────────────────────────────────────────────────────────────────

_MAC_PLIST = Path.home() / "Library" / "LaunchAgents" / "com.zero_two.ai.plist"

def _mac_is_enabled() -> bool:
    return _MAC_PLIST.exists()

def _mac_enable():
    exe = _exe_path()
    plist = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>             <string>com.zero_two.ai</string>
    <key>ProgramArguments</key>
    <array>
        {"".join(f"<string>{p}</string>" for p in exe.split())}
    </array>
    <key>RunAtLoad</key>         <true/>
    <key>KeepAlive</key>         <false/>
    <key>StandardOutPath</key>   <string>/tmp/zero_two.log</string>
    <key>StandardErrorPath</key> <string>/tmp/zerotwo_err.log</string>
</dict>
</plist>"""
    _MAC_PLIST.parent.mkdir(parents=True, exist_ok=True)
    _MAC_PLIST.write_text(plist, encoding="utf-8")
    os.system(f"launchctl load '{_MAC_PLIST}'")
    print("[AutoStart] ✅ macOS LaunchAgent installed.")

def _mac_disable():
    if _MAC_PLIST.exists():
        os.system(f"launchctl unload '{_MAC_PLIST}'")
        _MAC_PLIST.unlink()
        print("[AutoStart] 🗑 macOS LaunchAgent removed.")


# ── Linux ─────────────────────────────────────────────────────────────────────

_LINUX_DESKTOP = Path.home() / ".config" / "autostart" / "zero_two.desktop"

def _linux_is_enabled() -> bool:
    return _LINUX_DESKTOP.exists()

def _linux_enable():
    exe = _exe_path()
    desktop = f"""[Desktop Entry]
Type=Application
Name=ZERO TWO AI
Comment=ZERO TWO AI Assistant
Exec={exe}
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
"""
    _LINUX_DESKTOP.parent.mkdir(parents=True, exist_ok=True)
    _LINUX_DESKTOP.write_text(desktop, encoding="utf-8")
    _LINUX_DESKTOP.chmod(0o755)
    print("[AutoStart] ✅ Linux .desktop autostart entry created.")

def _linux_disable():
    if _LINUX_DESKTOP.exists():
        _LINUX_DESKTOP.unlink()
        print("[AutoStart] 🗑 Linux .desktop autostart entry removed.")


# ── Public API ────────────────────────────────────────────────────────────────

def is_enabled() -> bool:
    """Returns True if ZERO TWO is set to start with the OS."""
    if _OS == "Windows": return _win_is_enabled()
    if _OS == "Darwin":  return _mac_is_enabled()
    return _linux_is_enabled()

def enable() -> bool:
    """Enable auto-start. Returns True on success."""
    try:
        if _OS == "Windows": _win_enable()
        elif _OS == "Darwin": _mac_enable()
        else: _linux_enable()
        return True
    except Exception as e:
        print(f"[AutoStart] ❌ Failed to enable: {e}")
        return False

def disable() -> bool:
    """Disable auto-start. Returns True on success."""
    try:
        if _OS == "Windows": _win_disable()
        elif _OS == "Darwin": _mac_disable()
        else: _linux_disable()
        return True
    except Exception as e:
        print(f"[AutoStart] ❌ Failed to disable: {e}")
        return False

def toggle() -> bool:
    """Toggle auto-start. Returns new enabled state."""
    if is_enabled():
        disable(); return False
    else:
        enable(); return True
