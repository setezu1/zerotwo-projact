ZERO TWO AI — Assets Folder
============================

Place your Zero Two character image here and the dashboard will use it automatically.

Supported filenames (any of these will work):
  zero_two.png    ← recommended (PNG with transparency works great)
  zero_two.jpg
  zero_two.jpeg
  zero_two.webp

Recommended image:
  - Portrait orientation (taller than wide)
  - Minimum 400×600 pixels, 600×900+ preferred
  - Semi-transparent PNG recommended for best blending
  - Any official Zero Two / Code:002 artwork (Darling in the FranXX)

Without an image: the dashboard shows a stylised painted placeholder portrait
that still looks great — horns, pink/crimson hair, glowing eyes, outfit.
With an image: your chosen art appears with a crimson vignette frame and
glowing halo rings, animated when Zero Two is speaking.
