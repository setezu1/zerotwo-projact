"""
system_monitor.py — Lightweight cross-platform system metrics (Zero Two)
=========================================================================
Phase-3 module added by the v10 feature build.

Provides a single, thread-safe snapshot of:
  • CPU usage (%)
  • RAM usage (%)
  • CPU temperature (°C, if the OS exposes a sensor)
  • Number of CPU cores
  • OS name

A background thread keeps the values fresh so UI polling is O(1).

NOTE: This wraps psutil. It does NOT replace the existing _SysMetrics in
ui.py — both can coexist. ui.py uses _SysMetrics for the orb / sparklines;
the new System Metrics dashboard panel uses this module so the metrics
code is properly modular per the build checklist.
"""

from __future__ import annotations

import platform
import subprocess
import threading
import time
from dataclasses import dataclass, asdict
from typing import Optional

try:
    import psutil  # type: ignore
except ImportError:
    psutil = None  # type: ignore

try:
    import pynvml  # type: ignore
    pynvml.nvmlInit()
    _NVML = True
except Exception:
    _NVML = False


_OS = platform.system()


@dataclass
class Metrics:
    cpu: float = 0.0          # 0..100
    ram: float = 0.0          # 0..100
    temp: float = -1.0        # °C, -1.0 if unavailable
    cores: int = 0
    os_name: str = _OS
    ram_used_gb: float = 0.0
    ram_total_gb: float = 0.0
    # GPU (NVIDIA via pynvml)
    gpu_usage: float = -1.0
    gpu_temp: float  = -1.0
    gpu_mem_used_mb: float  = -1.0
    gpu_mem_total_mb: float = -1.0
    gpu_name: str = ""
    # Disk
    disk_used_gb: float  = 0.0
    disk_total_gb: float = 0.0
    disk_pct: float      = 0.0
    # Network MB/s
    net_sent_mbps: float = 0.0
    net_recv_mbps: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)


class SystemMonitor:
    """Background-polling system metrics collector.

    Usage:
        mon = get_monitor()
        mon.snapshot()  →  Metrics(...)

    The poll loop runs every `interval` seconds (default 1.5s).
    """

    def __init__(self, interval: float = 1.5):
        self._interval = max(0.5, float(interval))
        self._lock = threading.Lock()
        self._metrics = Metrics(cores=(psutil.cpu_count(logical=True) if psutil else 0))
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._start_thread()

    # ── public API ────────────────────────────────────────────────────────────

    def snapshot(self) -> Metrics:
        with self._lock:
            # return a copy so callers can't mutate internal state
            return Metrics(**asdict(self._metrics))

    def snapshot_dict(self) -> dict:
        return self.snapshot().to_dict()

    def stop(self) -> None:
        self._stop.set()

    # ── internals ─────────────────────────────────────────────────────────────

    def _start_thread(self) -> None:
        if psutil is None:
            return
        self._thread = threading.Thread(
            target=self._loop, name="SystemMonitor", daemon=True
        )
        self._thread.start()

    def _loop(self) -> None:
        # First call to cpu_percent() with interval=None returns 0.0 — prime it.
        try:
            psutil.cpu_percent(interval=None)
        except Exception:
            pass
        while not self._stop.is_set():
            try:
                self._update()
            except Exception as e:
                # Never crash the thread
                print(f"[system_monitor] update error: {e}")
            self._stop.wait(self._interval)

    def _update(self) -> None:
        cpu  = psutil.cpu_percent(interval=None)
        vm   = psutil.virtual_memory()
        temp = self._read_temp()
        cores= psutil.cpu_count(logical=True) or 0

        # Disk
        disk_used = disk_total = disk_pct = 0.0
        try:
            path = "C:\\" if _OS=="Windows" else "/"
            d = psutil.disk_usage(path)
            disk_used  = d.used  / 1e9
            disk_total = d.total / 1e9
            disk_pct   = d.percent
        except Exception: pass

        # Network
        net_sent = net_recv = 0.0
        try:
            nc  = psutil.net_io_counters()
            now = time.time()
            if hasattr(self, "_last_nc") and self._last_nc:
                dt = max(0.001, now - self._last_nc_t)
                net_sent = (nc.bytes_sent - self._last_nc.bytes_sent) / dt / 1e6
                net_recv = (nc.bytes_recv - self._last_nc.bytes_recv) / dt / 1e6
            self._last_nc   = nc
            self._last_nc_t = now
        except Exception: pass

        # GPU via pynvml
        gpu_usage = gpu_temp = gpu_mem_used = gpu_mem_total = -1.0
        gpu_name = ""
        if _NVML:
            try:
                handle = pynvml.nvmlDeviceGetHandleByIndex(0)
                util   = pynvml.nvmlDeviceGetUtilizationRates(handle)
                mem    = pynvml.nvmlDeviceGetMemoryInfo(handle)
                name   = pynvml.nvmlDeviceGetName(handle)
                gpu_usage     = float(util.gpu)
                gpu_temp      = float(pynvml.nvmlDeviceGetTemperature(
                                    handle, pynvml.NVML_TEMPERATURE_GPU))
                gpu_mem_used  = mem.used  / 1048576
                gpu_mem_total = mem.total / 1048576
                gpu_name      = name if isinstance(name,str) else name.decode()
            except Exception: pass

        with self._lock:
            self._metrics.cpu           = float(cpu)
            self._metrics.ram           = float(vm.percent)
            self._metrics.ram_used_gb   = vm.used  / 1073741824
            self._metrics.ram_total_gb  = vm.total / 1073741824
            self._metrics.temp          = float(temp)
            self._metrics.cores         = int(cores)
            self._metrics.os_name       = _OS
            self._metrics.disk_used_gb  = disk_used
            self._metrics.disk_total_gb = disk_total
            self._metrics.disk_pct      = disk_pct
            self._metrics.net_sent_mbps = net_sent
            self._metrics.net_recv_mbps = net_recv
            self._metrics.gpu_usage     = gpu_usage
            self._metrics.gpu_temp      = gpu_temp
            self._metrics.gpu_mem_used_mb  = gpu_mem_used
            self._metrics.gpu_mem_total_mb = gpu_mem_total
            self._metrics.gpu_name      = gpu_name

    # ── temperature: best-effort, multi-platform ──────────────────────────────

    def _read_temp(self) -> float:
        # 1) psutil (Linux mainly, sometimes macOS via thirdparty)
        try:
            if hasattr(psutil, "sensors_temperatures"):
                t = psutil.sensors_temperatures()
                for n in ("k10temp", "zenpower", "coretemp", "cpu_thermal",
                          "acpitz", "nct6775", "soc_thermal"):
                    if n in t and t[n]:
                        return float(t[n][0].current)
                # Anything else
                for v in t.values():
                    if v:
                        return float(v[0].current)
        except Exception:
            pass

        # 2) Windows — try several sources in order of reliability.
        if _OS == "Windows":
            t = self._read_temp_windows()
            if t > 0:
                return float(t)

        # 3) macOS — try `osx-cpu-temp` if available, otherwise N/A.
        if _OS == "Darwin":
            try:
                r = subprocess.run(["osx-cpu-temp"],
                                   capture_output=True, text=True, timeout=2)
                if r.returncode == 0 and r.stdout.strip():
                    raw = r.stdout.strip().rstrip("°C ").strip()
                    return float(raw)
            except Exception:
                pass

        return -1.0

    # Windows temperature — best-effort multi-path probe.
    # Modern desktop boards usually don't expose MSAcpi_ThermalZoneTemperature,
    # so we also try LibreHardwareMonitor / OpenHardwareMonitor WMI namespaces.
    def _read_temp_windows(self) -> float:
        ps = ["powershell", "-NoProfile", "-NonInteractive", "-Command"]

        # 2a) LibreHardwareMonitor (if user is running the tool / service)
        # Broaden the name match: boards/CPUs report sensors as "CPU Package",
        # "CPU Core", "Core Average", "Tdie", "Tctl", "Package", etc. -- not
        # just literal "CPU". Matching on Core/Package/Tdie/Tctl/CPU together
        # catches AMD, Intel, and most LHM/OHM naming conventions.
        name_filter = (
            "$_.SensorType -eq 'Temperature' -and "
            "($_.Name -match 'CPU' -or $_.Name -match 'Core' -or "
            "$_.Name -match 'Package' -or $_.Name -match 'Tdie' -or "
            "$_.Name -match 'Tctl')"
        )
        try:
            r = subprocess.run(ps + [
                f"$t = Get-WmiObject -Namespace root/LibreHardwareMonitor -Class Sensor "
                f"-ErrorAction SilentlyContinue | "
                f"Where-Object {{{name_filter}}} | "
                f"Select-Object -ExpandProperty Value -First 1; if ($t) {{ $t }}"
            ], capture_output=True, text=True, timeout=3)
            if r.returncode == 0 and r.stdout.strip():
                return float(r.stdout.strip().splitlines()[0])
        except Exception:
            pass

        # 2b) OpenHardwareMonitor (legacy version of LHM)
        try:
            r = subprocess.run(ps + [
                f"$t = Get-WmiObject -Namespace root/OpenHardwareMonitor -Class Sensor "
                f"-ErrorAction SilentlyContinue | "
                f"Where-Object {{{name_filter}}} | "
                f"Select-Object -ExpandProperty Value -First 1; if ($t) {{ $t }}"
            ], capture_output=True, text=True, timeout=3)
            if r.returncode == 0 and r.stdout.strip():
                return float(r.stdout.strip().splitlines()[0])
        except Exception:
            pass

        # 2c) ACPI thermal zone via Get-CimInstance (more reliable on newer
        # PowerShell than Get-WmiObject, doesn't need legacy WMI provider)
        try:
            r = subprocess.run(ps + [
                "$z = Get-CimInstance -Namespace root/wmi "
                "-ClassName MSAcpi_ThermalZoneTemperature -ErrorAction SilentlyContinue "
                "| Select-Object -ExpandProperty CurrentTemperature -First 1; if ($z) { $z }"
            ], capture_output=True, text=True, timeout=3)
            if r.returncode == 0 and r.stdout.strip():
                # tenths of Kelvin
                k10 = float(r.stdout.strip().splitlines()[0])
                c = k10 / 10.0 - 273.15
                if 5 < c < 120:
                    return c
        except Exception:
            pass

        # 2d) ACPI thermal zone via legacy Get-WmiObject (some systems only
        # expose this provider through the old WMI API, not CIM)
        try:
            r = subprocess.run(ps + [
                "(Get-WmiObject -Namespace root/wmi "
                "-Class MSAcpi_ThermalZoneTemperature -ErrorAction SilentlyContinue"
                ").CurrentTemperature | Select-Object -First 1"
            ], capture_output=True, text=True, timeout=3)
            if r.returncode == 0 and r.stdout.strip():
                k10 = float(r.stdout.strip().splitlines()[0])
                c = k10 / 10.0 - 273.15
                if 5 < c < 120:
                    return c
        except Exception:
            pass

        return -1.0


# ── Singleton accessor ────────────────────────────────────────────────────────

_monitor: Optional[SystemMonitor] = None


def get_monitor() -> SystemMonitor:
    global _monitor
    if _monitor is None:
        _monitor = SystemMonitor()
    return _monitor


# ── CLI smoke test ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import json
    mon = get_monitor()
    time.sleep(2.2)  # let the thread collect at least one real sample
    print(json.dumps(mon.snapshot_dict(), indent=2))
