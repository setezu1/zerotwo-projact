"""
wake_word.py — Wake word detection for Zero Two
Architecture:
  - SLEEP mode : wake word engine owns the mic, Gemini gets NOTHING
  - ACTIVE mode: Gemini owns the mic, wake word monitors transcript for sleep phrases
  - Auto-sleep : after ACTIVE_TIMEOUT seconds of no user speech, returns to SLEEP

Wake phrases : "hey zero two", "zero two", "wake up zero two", "hello zero two"
Sleep phrases: "go to sleep", "sleep mode", "goodbye zero two"

Backends (tried in order):
  1. vosk         -- best offline, no API key needed (run vosk_setup.py once)
  2. speech_recognition -- uses Google STT (needs internet)
  3. energy       -- last resort, any loud sound wakes (not phrase-specific)

Also provides ClapDetector: an independent double-clap activation listener
(clap, clap -> wake) that runs alongside any of the backends above.
"""

from __future__ import annotations

import os, sys, threading, time
from pathlib import Path
from typing import Callable


class Mode:
    SLEEP     = "SLEEP"
    ACTIVE    = "ACTIVE"
    EXECUTION = "EXECUTION"


_WAKE_PHRASES  = ["hey zero two", "zero two", "wake up zero two",
                  "wake zero two", "hey zero", "hello zero two"]
_SLEEP_PHRASES = ["go to sleep", "sleep mode", "goodbye zero two",
                  "zero two sleep", "sleep now", "goodbye"]

ACTIVE_TIMEOUT = 45.0  # seconds before auto-sleep


class WakeWordEngine:
    def __init__(
        self,
        on_wake:    Callable[[], None] | None = None,
        on_sleep:   Callable[[], None] | None = None,
        on_execute: Callable[[], None] | None = None,
        sample_rate: int  = 16000,
        enabled:     bool = True,
    ):
        self._on_wake    = on_wake
        self._on_sleep   = on_sleep
        self._on_execute = on_execute
        self._sr         = sample_rate
        self._enabled    = enabled
        self._mode       = Mode.SLEEP
        self._running    = False
        self._lock       = threading.Lock()
        self._backend    = "none"
        self._mic_threshold: int = 2000

        self._last_user_speech: float = time.time()
        self._auto_sleep_tmr: threading.Timer | None = None

        self._vosk_model = None
        self._vosk_rec   = None
        self._sr_engine  = None
        self._init_backend()

    def _init_backend(self):
        # Try vosk (offline)
        try:
            from vosk import Model, KaldiRecognizer
            model_path = Path(__file__).parent / "models" / "vosk-model-small-en"
            if not model_path.exists():
                try:
                    from vosk_setup import ensure_model
                    ensure_model(silent=True)
                except Exception:
                    pass
            if model_path.exists():
                self._vosk_model = Model(str(model_path))
                self._vosk_rec   = KaldiRecognizer(self._vosk_model, self._sr)
                self._backend    = "vosk"
                print("[WakeWord] OK vosk (offline) backend ready")
                return
        except Exception:
            pass

        # Try speech_recognition (Google STT)
        try:
            import speech_recognition as sr
            self._sr_engine = sr.Recognizer()
            self._sr_engine.energy_threshold         = 400
            self._sr_engine.dynamic_energy_threshold = True
            self._sr_engine.pause_threshold          = 0.6
            self._backend = "speech_recognition"
            print("[WakeWord] OK speech_recognition backend ready")
            return
        except Exception:
            pass

        self._backend = "energy"
        print("[WakeWord] WARNING energy-only backend")

    @property
    def mode(self) -> str:
        with self._lock:
            return self._mode

    def start(self):
        if not self._enabled:
            print("[WakeWord] Disabled in settings")
            return
        if self._running:
            return
        self._running = True
        threading.Thread(target=self._loop, daemon=True, name="WakeWord").start()
        print(f"[WakeWord] Started in SLEEP mode ({self._backend})")
        print("[WakeWord] Say 'Hey Zero Two' to activate")

    def stop(self):
        self._running = False
        self._cancel_auto_sleep()
        print("[WakeWord] Stopped")

    def notify_user_spoke(self):
        """Call this when user speech arrives — resets auto-sleep timer."""
        self._last_user_speech = time.time()
        self._reset_auto_sleep()

    def notify_sleep_phrase(self, text: str):
        """Call this with incoming transcript text while ACTIVE."""
        if self._mode == Mode.ACTIVE:
            if any(p in text.lower() for p in _SLEEP_PHRASES):
                print(f"[WakeWord] Sleep phrase in transcript: '{text}'")
                self._transition(Mode.SLEEP)

    def force_wake(self):
        self._transition(Mode.ACTIVE)

    def force_sleep(self):
        self._transition(Mode.SLEEP)

    def _reset_auto_sleep(self):
        self._cancel_auto_sleep()
        if self._mode == Mode.ACTIVE:
            self._auto_sleep_tmr = threading.Timer(ACTIVE_TIMEOUT, self._auto_sleep_fire)
            self._auto_sleep_tmr.daemon = True
            self._auto_sleep_tmr.start()

    def _cancel_auto_sleep(self):
        if self._auto_sleep_tmr:
            self._auto_sleep_tmr.cancel()
            self._auto_sleep_tmr = None

    def _auto_sleep_fire(self):
        if self._mode == Mode.ACTIVE:
            print(f"[WakeWord] No speech for {ACTIVE_TIMEOUT}s -- auto-sleeping")
            self._transition(Mode.SLEEP)

    def _transition(self, new_mode: str):
        with self._lock:
            old = self._mode
            self._mode = new_mode
        if old == new_mode:
            return
        print(f"[WakeWord] {old} -> {new_mode}")
        if new_mode == Mode.ACTIVE:
            self._reset_auto_sleep()
            if self._on_wake:
                threading.Thread(target=self._on_wake, daemon=True).start()
        elif new_mode == Mode.SLEEP:
            self._cancel_auto_sleep()
            if self._on_sleep:
                threading.Thread(target=self._on_sleep, daemon=True).start()
        elif new_mode == Mode.EXECUTION:
            self._cancel_auto_sleep()
            if self._on_execute:
                threading.Thread(target=self._on_execute, daemon=True).start()

    def _loop(self):
        if self._backend == "vosk":
            self._loop_vosk()
        elif self._backend == "speech_recognition":
            self._loop_sr()
        else:
            self._loop_energy()

    def _loop_vosk(self):
        try:
            import sounddevice as sd
            import json as _json
            BLOCK = 4000
            print("[WakeWord] vosk mic open")
            with sd.RawInputStream(
                samplerate=self._sr, channels=1, dtype="int16", blocksize=BLOCK
            ) as stream:
                while self._running:
                    data, _ = stream.read(BLOCK)
                    if self._mode == Mode.SLEEP:
                        if self._vosk_rec.AcceptWaveform(bytes(data)):
                            result = _json.loads(self._vosk_rec.Result())
                            text = result.get("text", "").lower().strip()
                            if text:
                                print(f"[WakeWord] vosk: '{text}'")
                                self._check_wake(text)
                    time.sleep(0.005)
        except Exception as e:
            print(f"[WakeWord] vosk error: {e} -- energy fallback")
            self._backend = "energy"
            self._loop_energy()

    def _loop_sr(self):
        import speech_recognition as sr
        mic = sr.Microphone(sample_rate=self._sr)
        print("[WakeWord] speech_recognition mic open")
        while self._running:
            if self._mode != Mode.SLEEP:
                time.sleep(0.5)
                continue
            try:
                with mic as source:
                    self._sr_engine.adjust_for_ambient_noise(source, duration=0.2)
                    audio = self._sr_engine.listen(source, timeout=3, phrase_time_limit=4)
                try:
                    text = self._sr_engine.recognize_google(audio).lower().strip()
                    print(f"[WakeWord] sr: '{text}'")
                    self._check_wake(text)
                except sr.UnknownValueError:
                    pass
                except sr.RequestError:
                    print("[WakeWord] Google STT offline -- energy fallback")
                    self._backend = "energy"
                    self._loop_energy()
                    return
            except Exception:
                time.sleep(0.5)

    def _loop_energy(self):
        try:
            import sounddevice as sd
            import numpy as np
            BLOCK         = 4096
            CONFIRM       = 4
            SILENCE_RESET = 25
            loud_frames   = 0
            silence_frames= 0
            armed         = True
            print("[WakeWord] energy backend running -- speak loudly to wake")
            with sd.InputStream(
                samplerate=self._sr, channels=1, dtype="int16", blocksize=BLOCK
            ) as stream:
                while self._running:
                    data, _ = stream.read(BLOCK)
                    if self._mode != Mode.SLEEP:
                        time.sleep(0.05)
                        continue
                    THRESH = getattr(self, "_mic_threshold", 2000)
                    rms = float(np.sqrt(np.mean(
                        np.frombuffer(data, dtype=np.int16).astype(np.float32) ** 2
                    )))
                    if rms > THRESH:
                        loud_frames += 1
                        silence_frames = 0
                        if armed and loud_frames >= CONFIRM:
                            print(f"[WakeWord] energy trigger rms={rms:.0f}")
                            self._transition(Mode.ACTIVE)
                            armed = False
                            loud_frames = 0
                    else:
                        loud_frames = max(0, loud_frames - 1)
                        silence_frames += 1
                        if silence_frames >= SILENCE_RESET:
                            armed = True
                    time.sleep(0.01)
        except Exception as e:
            print(f"[WakeWord] energy error: {e}")

    def _check_wake(self, text: str):
        """Only called in SLEEP mode — checks for wake phrase."""
        if any(p in text for p in _WAKE_PHRASES):
            print(f"[WakeWord] WAKE PHRASE DETECTED: '{text}'")
            self._transition(Mode.ACTIVE)


# ─────────────────────────────────────────────────────────────────────────────
# Clap Detector — double-clap activation, runs alongside WakeWordEngine
# ─────────────────────────────────────────────────────────────────────────────
#
# A clap is a very short (~5-40ms), sharp amplitude transient followed by a
# fast decay — quite different from speech (sustained, modulated energy) or a
# dull thud/bump (slower attack, lower-frequency, longer decay).
#
# We require TWO such transients within a short window (a "double clap") to
# trigger activation. This single requirement removes the overwhelming
# majority of false positives (a dropped pen, a door, a cough, a single loud
# word) while still being fast and natural for the user — clap, clap, done.
#
# This runs as its own mic stream, independent of whichever STT backend
# WakeWordEngine picked, so it works even on the bare "energy" fallback and
# even when vosk/speech_recognition aren't installed.

CLAP_DOUBLE_WINDOW   = 1.2   # seconds — max gap between the two claps
CLAP_MIN_GAP         = 0.08  # seconds — min gap (debounce same-clap echo)
CLAP_COOLDOWN        = 1.5   # seconds — ignore everything right after a trigger


class ClapDetector:
    """
    Listens for a double-clap pattern and calls on_double_clap() when found.
    Designed to run only while the assistant is asleep / not actively
    listening — call start()/stop() in lock-step with that state, or pass an
    is_paused callable that returns True when detection should pause.
    """

    def __init__(
        self,
        on_double_clap: Callable[[], None] | None = None,
        sensitivity: int = 60,
        sample_rate: int = 16000,
        enabled: bool = False,
        is_paused: Callable[[], bool] | None = None,
    ):
        self._on_double_clap = on_double_clap
        self._sr             = sample_rate
        self._enabled        = enabled
        self._running        = False
        self._is_paused      = is_paused or (lambda: False)
        self.set_sensitivity(sensitivity)
        self._last_clap_t: float = 0.0
        self._last_trigger_t: float = 0.0

    def set_sensitivity(self, sensitivity: int):
        """
        sensitivity: 0-100 (UI slider). Higher = easier to trigger
        (lower amplitude threshold required, looser sharpness check).
        """
        sensitivity = max(0, min(100, int(sensitivity)))
        self._sensitivity = sensitivity
        # Amplitude threshold: scale from ~6000 (low sens) down to ~1200 (high sens)
        self._amp_threshold = 6000 - (sensitivity / 100.0) * 4800
        # Sharpness ratio: how much louder the peak must be vs the block's
        # running floor to count as a transient (claps spike hard then drop)
        self._sharp_ratio = 2.2 - (sensitivity / 100.0) * 0.9  # 2.2 .. 1.3

    def start(self):
        if not self._enabled:
            print("[ClapDetector] Disabled in settings")
            return
        if self._running:
            return
        self._running = True
        threading.Thread(target=self._loop, daemon=True, name="ClapDetector").start()
        print("[ClapDetector] Started -- clap twice quickly to wake")

    def stop(self):
        self._running = False
        print("[ClapDetector] Stopped")

    def set_enabled(self, enabled: bool):
        self._enabled = enabled
        if enabled:
            self.start()
        else:
            self.stop()

    def _loop(self):
        try:
            import sounddevice as sd
            import numpy as np
        except Exception as e:
            print(f"[ClapDetector] sounddevice/numpy unavailable: {e} -- disabled")
            return

        BLOCK = 1024  # ~64ms at 16kHz -- short enough to catch a clap transient
        floor_rms = 200.0  # adaptive noise floor

        try:
            with sd.InputStream(
                samplerate=self._sr, channels=1, dtype="int16", blocksize=BLOCK
            ) as stream:
                while self._running:
                    if not self._enabled or self._is_paused():
                        time.sleep(0.1)
                        continue

                    data, _ = stream.read(BLOCK)
                    samples = np.frombuffer(data, dtype=np.int16).astype(np.float32)
                    rms  = float(np.sqrt(np.mean(samples ** 2)) + 1e-6)
                    peak = float(np.max(np.abs(samples)))

                    now = time.time()

                    # Cooldown right after a successful trigger
                    if now - self._last_trigger_t < CLAP_COOLDOWN:
                        floor_rms = 0.9 * floor_rms + 0.1 * rms
                        time.sleep(0.005)
                        continue

                    is_transient = (
                        peak > self._amp_threshold
                        and peak > floor_rms * self._sharp_ratio
                    )

                    if is_transient:
                        gap = now - self._last_clap_t
                        if gap > CLAP_MIN_GAP:
                            if CLAP_MIN_GAP < gap <= CLAP_DOUBLE_WINDOW and self._last_clap_t > 0:
                                # Second clap within the window -- trigger!
                                print(f"[ClapDetector] DOUBLE CLAP detected (gap={gap:.2f}s, peak={peak:.0f})")
                                self._last_trigger_t = now
                                self._last_clap_t = 0.0
                                if self._on_double_clap:
                                    threading.Thread(target=self._on_double_clap, daemon=True).start()
                            else:
                                # First clap (or too-late second) -- start/restart window
                                self._last_clap_t = now
                        # don't fold a transient into the noise floor
                    else:
                        # Update adaptive floor only with quiet/normal audio
                        floor_rms = 0.95 * floor_rms + 0.05 * rms
                        floor_rms = max(80.0, min(floor_rms, 1500.0))

                    # Expire a stale single clap that never got its pair
                    if self._last_clap_t and (now - self._last_clap_t) > CLAP_DOUBLE_WINDOW:
                        self._last_clap_t = 0.0

                    time.sleep(0.005)
        except Exception as e:
            print(f"[ClapDetector] stream error: {e}")
