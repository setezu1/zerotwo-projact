"""
api_manager.py — Unified AI Provider Manager (Zero Two)
========================================================
Phase-1 module added by the v10 feature build.

Goals (per build checklist):
  • Single entry point for all text-completion calls.
  • Supports multiple providers: OpenAI, xAI (Grok), Gemini (existing).
  • Clean routing: a `selected_model` string maps to the correct provider.
  • Reads keys from config/api_keys.json — never hardcodes.
  • Auto-detects available providers from stored keys.
  • Falls back gracefully if a provider is unconfigured or fails.

Design notes:
  • This module DOES NOT replace ai_router.py — ai_router stays untouched
    so existing planner/agent code keeps working (SAFE MODE).
  • api_manager is a thin, modern facade for new UI/settings code, and adds
    xAI Grok support, which ai_router lacks.
  • A singleton (`get_manager()`) is provided so the UI can reload keys
    on save without re-instantiating.
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Optional


# ── Paths ─────────────────────────────────────────────────────────────────────

def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent


BASE_DIR    = _base_dir()
CONFIG_DIR  = BASE_DIR / "config"
KEYS_FILE   = CONFIG_DIR / "api_keys.json"
SETTINGS    = CONFIG_DIR / "settings.json"


# ── Model catalogue ──────────────────────────────────────────────────────────
# selected_model substring → provider
# This is a simple, robust mapper. Add entries here when new models appear.

_MODEL_MAP: list[tuple[str, str]] = [
    # (substring, provider)
    ("gpt",        "openai"),
    ("o1",         "openai"),
    ("o3",         "openai"),
    ("openai",     "openai"),

    ("grok",       "xai"),
    ("xai",        "xai"),

    ("gemini",     "gemini"),
    ("google",     "gemini"),

    ("claude",     "anthropic"),
    ("anthropic",  "anthropic"),
]

# Default model id per provider (used if user only picks a provider name)
_DEFAULT_MODEL = {
    "openai":    "gpt-4o-mini",
    "xai":       "grok-2-latest",
    "gemini":    "gemini-2.0-flash",
    "anthropic": "claude-3-5-haiku-latest",
}

# Models exposed in the UI dropdown
AVAILABLE_MODELS: list[str] = [
    # Gemini
    "gemini-2.5-flash",
    "gemini-2.0-flash",
    # OpenAI
    "gpt-4o",
    "gpt-4o-mini",
    # xAI / Grok
    "grok-2-latest",
    "grok-beta",
    # Anthropic (still supported through ai_router fallback)
    "claude-3-5-sonnet",
]


# ── Safe key / settings I/O ───────────────────────────────────────────────────

def _read_json(p: Path) -> dict:
    try:
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"[api_manager] WARN reading {p.name}: {e}")
    return {}


def _write_json(p: Path, data: dict) -> bool:
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return True
    except Exception as e:
        print(f"[api_manager] ERR writing {p.name}: {e}")
        return False


# ── Public key helpers (used by Settings UI) ─────────────────────────────────

def load_keys() -> dict:
    """Returns the full api_keys.json dict (or empty)."""
    return _read_json(KEYS_FILE)


def save_keys(updates: dict) -> bool:
    """
    Merge-save key updates into api_keys.json.
    Empty/whitespace values are IGNORED (will not wipe an existing key).
    """
    cfg = load_keys()
    changed = False
    for k, v in (updates or {}).items():
        if v is None:
            continue
        v = str(v).strip()
        if not v:
            continue
        cfg[k] = v
        changed = True
    if changed:
        return _write_json(KEYS_FILE, cfg)
    return True   # nothing to do, not an error


def has_key(provider: str) -> bool:
    keys = load_keys()
    return bool(keys.get(_key_field(provider), os.environ.get(_env_var(provider), "")))


def available_providers() -> list[str]:
    return [p for p in ("gemini", "openai", "xai", "anthropic") if has_key(p)]


def _key_field(provider: str) -> str:
    return {
        "gemini":    "gemini_api_key",
        "openai":    "openai_api_key",
        "xai":       "xai_api_key",
        "anthropic": "anthropic_api_key",
    }.get(provider, f"{provider}_api_key")


def _env_var(provider: str) -> str:
    return {
        "gemini":    "GEMINI_API_KEY",
        "openai":    "OPENAI_API_KEY",
        "xai":       "XAI_API_KEY",
        "anthropic": "ANTHROPIC_API_KEY",
    }.get(provider, provider.upper() + "_API_KEY")


# ── Routing logic ─────────────────────────────────────────────────────────────

def resolve_provider(selected_model: str) -> str:
    """Map a user-selected model string to a provider id."""
    m = (selected_model or "").lower().strip()
    for needle, prov in _MODEL_MAP:
        if needle in m:
            return prov
    return "gemini"   # safe default


def resolve_model_id(selected_model: str, provider: Optional[str] = None) -> str:
    """Return a concrete model id for the chosen provider."""
    sel = (selected_model or "").strip()
    prov = provider or resolve_provider(sel)
    # If user typed a real model id, use it as-is.
    # Otherwise fall back to provider default.
    if sel and any(c.isdigit() or c == "-" for c in sel) and sel.lower() != prov:
        return sel
    return _DEFAULT_MODEL.get(prov, sel or "gemini-2.0-flash")


# ── API Manager ───────────────────────────────────────────────────────────────

class APIManager:
    """
    Unified, clean text-completion entry point.

    Usage:
        mgr = get_manager()
        text, model_used = mgr.complete("Hello", selected_model="grok-2-latest")
    """

    def __init__(self):
        self._cache_keys: dict = {}
        self._cache_t = 0.0
        self.reload()

    # --- key + settings refresh ------------------------------------------------

    def reload(self) -> None:
        """Re-read keys & settings from disk. Call after Save Settings."""
        self._cache_keys = load_keys()
        self._cache_settings = _read_json(SETTINGS)
        self._cache_t = time.time()

    def get_key(self, provider: str) -> str:
        # Always read fresh — UI can update mid-session
        keys = load_keys()
        return keys.get(_key_field(provider), os.environ.get(_env_var(provider), ""))

    def selected_model(self) -> str:
        s = _read_json(SETTINGS)
        return s.get("ai_model", "gemini-2.0-flash")

    def active_provider(self) -> str:
        return resolve_provider(self.selected_model())

    def status(self) -> dict:
        return {
            "selected_model":  self.selected_model(),
            "active_provider": self.active_provider(),
            "available":       available_providers(),
            "model_catalog":   AVAILABLE_MODELS,
        }

    # --- main entry point ------------------------------------------------------

    def complete(
        self,
        prompt: str,
        system: str = "You are Zero Two, a helpful AI assistant.",
        selected_model: Optional[str] = None,
        max_tokens: int = 800,
        temperature: float = 0.7,
    ) -> tuple[str, str]:
        """
        Returns (response_text, model_used).
        Routes to the provider that matches `selected_model` (or settings).
        Falls back to ai_router.AIRouter on failure so existing behavior is preserved.
        """
        model = selected_model or self.selected_model()
        provider = resolve_provider(model)
        model_id = resolve_model_id(model, provider)

        try:
            if provider == "openai":
                text = self._call_openai(model_id, prompt, system, max_tokens, temperature)
            elif provider == "xai":
                text = self._call_xai(model_id, prompt, system, max_tokens, temperature)
            elif provider == "gemini":
                text = self._call_gemini(model_id, prompt, system, max_tokens, temperature)
            elif provider == "anthropic":
                text = self._call_anthropic(model_id, prompt, system, max_tokens, temperature)
            else:
                raise ValueError(f"Unknown provider: {provider}")
            return text, f"{provider}/{model_id}"
        except Exception as e:
            print(f"[api_manager] Primary call failed ({provider}/{model_id}): {e}")
            # Graceful fallback through legacy ai_router (preserves existing flow)
            try:
                from ai_router import get_router
                text, used = get_router().complete(
                    prompt, system=system,
                    max_tokens=max_tokens, temperature=temperature,
                )
                return text, f"fallback:{used}"
            except Exception as e2:
                return (
                    f"[api_manager] All providers failed.\n"
                    f"Primary: {e}\nFallback: {e2}",
                    "none",
                )

    # --- provider implementations ---------------------------------------------

    def _call_openai(self, model_id, prompt, system, max_tokens, temperature) -> str:
        try:
            import openai  # type: ignore
        except ImportError as e:
            raise ImportError("openai package not installed — run: pip install openai") from e
        key = self.get_key("openai")
        if not key:
            raise ValueError("No OpenAI API key configured")
        client = openai.OpenAI(api_key=key)
        resp = client.chat.completions.create(
            model=model_id,
            messages=[
                {"role": "system", "content": system},
                {"role": "user",   "content": prompt},
            ],
            max_tokens=max_tokens,
            temperature=temperature,
        )
        return (resp.choices[0].message.content or "").strip()

    def _call_xai(self, model_id, prompt, system, max_tokens, temperature) -> str:
        """
        xAI Grok uses an OpenAI-compatible REST API.
        Endpoint: https://api.x.ai/v1
        Uses the `openai` python SDK with a custom base_url (no extra dependency).
        """
        try:
            import openai  # type: ignore
        except ImportError as e:
            raise ImportError(
                "openai package required for xAI calls — run: pip install openai"
            ) from e
        key = self.get_key("xai")
        if not key:
            raise ValueError("No xAI API key configured")
        client = openai.OpenAI(api_key=key, base_url="https://api.x.ai/v1")
        resp = client.chat.completions.create(
            model=model_id,
            messages=[
                {"role": "system", "content": system},
                {"role": "user",   "content": prompt},
            ],
            max_tokens=max_tokens,
            temperature=temperature,
        )
        return (resp.choices[0].message.content or "").strip()

    def _call_gemini(self, model_id, prompt, system, max_tokens, temperature) -> str:
        try:
            import google.generativeai as genai  # type: ignore
        except ImportError as e:
            raise ImportError(
                "google-generativeai not installed — run: pip install google-generativeai"
            ) from e
        key = self.get_key("gemini")
        if not key:
            raise ValueError("No Gemini API key configured")
        genai.configure(api_key=key)
        model = genai.GenerativeModel(
            model_name=model_id,
            system_instruction=system,
        )
        resp = model.generate_content(
            prompt,
            generation_config=genai.GenerationConfig(
                max_output_tokens=max_tokens,
                temperature=temperature,
            ),
        )
        return (resp.text or "").strip()

    def _call_anthropic(self, model_id, prompt, system, max_tokens, temperature) -> str:
        try:
            import anthropic  # type: ignore
        except ImportError as e:
            raise ImportError(
                "anthropic not installed — run: pip install anthropic"
            ) from e
        key = self.get_key("anthropic")
        if not key:
            raise ValueError("No Anthropic API key configured")
        client = anthropic.Anthropic(api_key=key)
        msg = client.messages.create(
            model=model_id,
            max_tokens=max_tokens,
            system=system,
            messages=[{"role": "user", "content": prompt}],
        )
        return msg.content[0].text.strip()


# ── Singleton ────────────────────────────────────────────────────────────────

# ── Provider status constants ─────────────────────────────────────────────────
class ProviderStatus:
    ONLINE   = "ONLINE"
    OFFLINE  = "OFFLINE"
    NO_KEY   = "NO KEY"
    INVALID  = "INVALID KEY"
    AUTH_FAIL= "AUTH FAILED"
    RATE_LIM = "RATE LIMITED"
    UNAVAIL  = "MODEL UNAVAILABLE"
    UNTESTED = "UNTESTED"


# ── Diagnostics store (module-level, survives reload) ─────────────────────────
_diag: dict = {
    p: {"status": ProviderStatus.UNTESTED,
        "last_ok": None, "last_fail": None,
        "last_error": "", "response_ms": -1}
    for p in ["openai","xai","gemini","anthropic","custom"]
}


def test_provider(provider: str, model_id: str = "") -> tuple[bool, str]:
    """
    Actually call the provider API. Update diagnostics.
    Returns (success, status_string).
    """
    import time as _t
    mgr = get_manager()
    key = mgr.get_key(provider)
    if not key:
        _diag.setdefault(provider, {})["status"] = ProviderStatus.NO_KEY
        return False, ProviderStatus.NO_KEY

    model_id = model_id or _DEFAULT_MODEL.get(provider, "")
    t0 = _t.time()
    try:
        if provider == "openai":
            resp = mgr._call_openai(model_id, "Reply: OK", "test", 5, 0.0)
        elif provider == "xai":
            resp = mgr._call_xai(model_id,    "Reply: OK", "test", 5, 0.0)
        elif provider == "gemini":
            resp = mgr._call_gemini(model_id,  "Reply: OK", "test", 5, 0.0)
        elif provider == "anthropic":
            resp = mgr._call_anthropic(model_id,"Reply: OK","test", 5, 0.0)
        else:
            return False, "Unknown provider"

        ms  = int((_t.time() - t0) * 1000)
        now = _t.strftime("%Y-%m-%d %H:%M:%S")
        _diag[provider].update({"status": ProviderStatus.ONLINE,
                                 "last_ok": now, "last_error": "",
                                 "response_ms": ms})
        return True, f"{ProviderStatus.ONLINE} ({ms} ms)"

    except Exception as e:
        ms  = int((_t.time() - t0) * 1000)
        err = str(e); now = _t.strftime("%Y-%m-%d %H:%M:%S")
        el  = err.lower()
        if any(x in err for x in ("401","invalid_api_key","Incorrect API")):
            status = ProviderStatus.INVALID
        elif any(x in err for x in ("403","permission","Forbidden")):
            status = ProviderStatus.AUTH_FAIL
        elif any(x in err for x in ("429","rate_limit","Too Many")):
            status = ProviderStatus.RATE_LIM
        elif "model" in el or "404" in err:
            status = ProviderStatus.UNAVAIL
        else:
            status = ProviderStatus.OFFLINE
        _diag[provider].update({"status": status, "last_fail": now,
                                  "last_error": err[:200], "response_ms": ms})
        return False, f"{status}: {err[:80]}"


def get_diagnostics() -> dict:
    """Full diagnostics dict for all providers."""
    mgr = get_manager()
    out = {}
    for p in ["openai","xai","gemini","anthropic"]:
        d = _diag.get(p, {})
        out[p] = {
            "label":       {"openai":"OpenAI","xai":"Grok (xAI)",
                            "gemini":"Gemini","anthropic":"Anthropic"}.get(p, p),
            "model":       _DEFAULT_MODEL.get(p, ""),
            "has_key":     bool(mgr.get_key(p)),
            "status":      d.get("status", ProviderStatus.UNTESTED),
            "last_ok":     d.get("last_ok"),
            "last_fail":   d.get("last_fail"),
            "last_error":  d.get("last_error",""),
            "response_ms": d.get("response_ms", -1),
        }
    return out


def which_model() -> str:
    """Return human-readable active provider and model."""
    mgr = get_manager()
    prov  = mgr.active_provider()
    model = mgr.selected_model()
    labels = {"openai":"OpenAI","xai":"Grok (xAI)","gemini":"Google Gemini","anthropic":"Anthropic Claude"}
    return f"{labels.get(prov, prov)} — {model}"


_manager: Optional[APIManager] = None


def get_manager() -> APIManager:
    global _manager
    if _manager is None:
        _manager = APIManager()
    return _manager


def reload_manager() -> None:
    """Called by the Settings UI after Save — refreshes cached state."""
    get_manager().reload()


# ── CLI smoke test ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    mgr = get_manager()
    print("Status:", json.dumps(mgr.status(), indent=2))
    print("Available providers:", available_providers())
