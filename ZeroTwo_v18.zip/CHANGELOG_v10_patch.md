# Zero Two v10 — Patch Notes (rebrand + UI fixes)

## 1. Full rebrand to **Zero Two**
Every user-visible string referencing **MIKU**, **MARK XXV**, **MARK XXXIX**, **Mark 39**, or **Mark 100** has been replaced with **Zero Two**.

Files updated:
- `main.py`, `ui.py`, `ai_router.py`, `confirm_dialog.py`, `autostart.py`,
  `vosk_setup.py`, `setup.py`, `agent/error_handler.py`, `agent/planner.py`,
  `readme.md`, `PROJECT_STATUS.md`, `PROJECT_AUDIT_REPORT.md`,
  `actions/game_updater.py`
- Wake phrase default now `"hey zero two"` (was `"hey miku"`)
- Autostart identifiers: `com.zerotwo.ai.plist`, `zerotwo.desktop`,
  `/tmp/zerotwo.log` (was `com.miku.ai.*`)
- Trusted device list now `{"ZERO-TWO-PC", "localhost", "home-pc"}`
- Setup banner: shows the Zero Two logo and ends with
  "Run 'python main.py' to start Zero Two."

Words deliberately preserved (false positives, NOT brand names):
- `markdown`, `marker`, `mark_zone` (technical terms in prompts/code)

## 2. Settings UI — Models look DIFFERENT now
**Before:** Single dropdown with seven model strings that all looked the same.
**After:**
- Two-row layout: **Provider** selector + **Model** selector that **cascades**
  (model list filters when you change provider).
- Provider entries show colored dots: 🟢 Gemini · 🔵 OpenAI · ⚫ Grok · 🟣 Anthropic.
- Each model shows a friendly name (e.g. *Gemini 2.5 Flash*) instead of the raw id.
- Live description hint appears below the model picker
  (e.g. "ⓘ  Latest, fastest — best default").
- Saved as both `ai_model` (id) and `ai_provider` (provider key) in `settings.json`.

## 3. Title-bar active-provider pill (new)
A colored pill in the top-right corner now shows the live active provider and
short model id, updated every 3 s — so you can see at a glance which AI is
actually answering you (e.g. `🟢 GEMINI · gemini-2.5-flash`).

## 4. Temperature — now actually works on Windows
The old code only tried `MSAcpi_ThermalZoneTemperature`, which most modern
desktop motherboards do not implement (so the dashboard always showed
**N/A**). New probing order:

1. `psutil.sensors_temperatures()` (Linux/macOS — works out of the box).
2. **LibreHardwareMonitor WMI** (`root/LibreHardwareMonitor`) — works on every
   modern Windows machine *if you have LHM installed and running*.
3. **OpenHardwareMonitor WMI** (`root/OpenHardwareMonitor`) — legacy fallback.
4. ACPI thermal zone (last resort, often missing on desktops).
5. macOS `osx-cpu-temp` CLI if installed.

If all probes fail, the card shows **N/A** with a tooltip explaining how to fix
it on Windows ("install LibreHardwareMonitor and keep it running").

The inline `_SysMetrics` in `ui.py` now also delegates to `system_monitor` for
temperature, so there is **one canonical source** instead of two diverging ones.

## 5. System Metrics widget — visibly live
- Larger, more prominent header with letter-spacing.
- Live HH:MM:SS timestamp updated every 1.5 s so you can see the panel is
  actually refreshing.
- LIVE dot blinks (alternates GREEN / dim-green) every cycle.
- Temperature value is **color-coded**:
  green `<60 °C` · yellow `<80 °C` · red `≥80 °C`.
- Refresh errors are now logged (`print("[ui] CoreMetrics refresh error: …")`)
  instead of being silently swallowed.
