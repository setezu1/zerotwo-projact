# Zero Two — v10 Update Notes

Built per the **ZERO TWO FEATURE BUILD CHECKLIST (SAFE MODE)**.
No existing features were removed or renamed.

---

## ✅ Phase 1 — API System (Core)

### New file: `api_manager.py`
A unified, modern facade for all text-completion calls.

* Supports providers: **OpenAI**, **xAI (Grok)**, **Gemini**, Anthropic (kept).
* Clean routing: `selected_model` substring → provider lookup table (`_MODEL_MAP`).
* Reads/writes `config/api_keys.json` — no hardcoded secrets.
* `xAI` is routed through the OpenAI-compatible SDK (`base_url=https://api.x.ai/v1`),
  so no extra dependency is required.
* Singleton accessor: `get_manager()`; `reload_manager()` is called by the UI after
  Save so changes take effect instantly.
* On any provider failure the legacy `ai_router.AIRouter` is used as a graceful
  fallback — existing planner/agent code keeps working unchanged.

### Key storage
* `config/api_keys.json` redacted (any previously committed real key was removed
  before shipping).
* New field added: `xai_api_key`.
* `save_keys()` ignores empty / whitespace values — typing nothing in a field will
  not wipe an existing key.

---

## ✅ Phase 2 — Settings Dashboard

UI edits in `ui.py` (additive only):

* **AI MODEL** dropdown now includes Grok models (`grok-2-latest`, `grok-beta`)
  and an extra OpenAI tier (`gpt-4o-mini`) alongside the existing Gemini / Claude
  entries.
* **API KEYS** section now exposes 4 fields:
  Gemini, OpenAI, **xAI / Grok (new)**, Anthropic. Each shows a `…key loaded ✓`
  hint when a stored key is detected.
* `Save Settings` → calls `api_manager.reload_manager()` so the active provider
  switches immediately.
* The MainWindow `_on_settings_saved` callback now also logs the new active
  provider (`SYS: API → XAI (grok-2-latest)` etc.) and refreshes the router status
  strip.

---

## ✅ Phase 3 — System Metrics Dashboard

### New file: `system_monitor.py`
* Thread-safe, cross-platform metrics collector built on `psutil`.
* Polls every 1.5 s (configurable) and exposes a `Metrics` dataclass with:
  `cpu`, `ram`, `temp`, `cores`, `os_name`, `ram_used_gb`, `ram_total_gb`.
* Multi-strategy temperature read: psutil sensors → Windows WMI → N/A.
* Singleton via `get_monitor()`; never crashes the app even if `psutil` is missing.

### UI hook
* The existing `CoreMetricsWidget` is now relabeled **`SYSTEM METRICS`** with a
  LIVE indicator and refreshes every **1.5 s** (was 2.5 s).
* When `system_monitor` is importable, its snapshot is used as the canonical
  source for CPU / RAM / temp. If not, the original inline `_SysMetrics` is used
  as fallback — no breakage.

---

## ✅ Phase 4 — UI Polish

Kept minimal per SAFE MODE:

* "SYSTEM METRICS" header now in accent green with a live `● LIVE` badge.
* Faster refresh cadence (1.5 s) for live feel.
* No global rename, no broken imports — every existing class still exists and
  every existing import path is preserved.

---

## ✅ Phase 5 — Testing

* `py_compile` passes for all touched modules.
* `python3 api_manager.py` → prints status + available providers.
* `python3 system_monitor.py` → prints a live snapshot after 2 s.
* Routing unit-tested for: `gemini-2.5-flash`, `gpt-4o`, `grok-2-latest`,
  `grok-beta`, `claude-3-5-sonnet`, bare `xai` → all resolve to the correct
  provider.

---

## 📦 Files added / modified

| File | Status |
|---|---|
| `api_manager.py` | **NEW** |
| `system_monitor.py` | **NEW** |
| `ui.py` | **edited** (additive: xAI field, Grok models, metrics relabel, reload hook) |
| `requirements.txt` | **edited** (comment cleanup) |
| `config/api_keys.json` | **redacted** + added `xai_api_key`, `openai_api_key`, `anthropic_api_key` placeholders |
| `CHANGELOG_v10.md` | **NEW** (this file) |

All other files are unchanged from v9.

---

## 🔐 Security note

The previous `config/api_keys.json` contained a real, hardcoded Gemini API key.
It has been **removed** in this build. If that key was ever committed to a
public repository, please **rotate it immediately** in your Google AI Studio
console.
