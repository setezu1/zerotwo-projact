"""
vosk_setup.py — Auto-download the small Vosk English model for offline wake word.

Run once:  python vosk_setup.py
Or call:   ensure_model()  from wake_word.py or main.py

Downloads to:  <project>/models/vosk-model-small-en-us-0.15/
~55 MB compressed, ~120 MB extracted.
"""

from __future__ import annotations

import os
import sys
import zipfile
import urllib.request
from pathlib import Path

MODEL_URL  = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
MODEL_NAME = "vosk-model-small-en-us-0.15"

def _base_dir() -> Path:
    return Path(sys.executable).parent if getattr(sys, "frozen", False) \
        else Path(__file__).resolve().parent

MODELS_DIR  = _base_dir() / "models"
MODEL_PATH  = MODELS_DIR / MODEL_NAME
LINK_PATH   = MODELS_DIR / "vosk-model-small-en"   # symlink / alias used by wake_word.py


def is_installed() -> bool:
    return MODEL_PATH.exists() and any(MODEL_PATH.iterdir())


def ensure_model(silent: bool = False) -> bool:
    """
    Download and extract model if not already present.
    Returns True if model is available after this call.
    """
    if is_installed():
        if not silent:
            print(f"[VoskSetup] ✅ Model already at {MODEL_PATH}")
        _make_link()
        return True

    print("[VoskSetup] 📥 Downloading Vosk small-EN model (~55 MB)…")
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    zip_path = MODELS_DIR / f"{MODEL_NAME}.zip"

    try:
        _download(MODEL_URL, zip_path)
        print("[VoskSetup] 📦 Extracting…")
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(MODELS_DIR)
        zip_path.unlink()
        _make_link()
        print(f"[VoskSetup] ✅ Model installed at {MODEL_PATH}")
        return True
    except Exception as e:
        print(f"[VoskSetup] ❌ Download failed: {e}")
        print("  You can manually download from:")
        print(f"  {MODEL_URL}")
        print(f"  Extract to: {MODELS_DIR}")
        return False


def _download(url: str, dest: Path):
    """Download with progress bar."""
    def _reporthook(count, block_size, total_size):
        if total_size > 0:
            pct = int(count * block_size * 100 / total_size)
            bar = "█" * (pct // 5) + "░" * (20 - pct // 5)
            print(f"\r  [{bar}] {pct}%", end="", flush=True)
    urllib.request.urlretrieve(url, dest, _reporthook)
    print()  # newline after progress


def _make_link():
    """Create the vosk-model-small-en alias that wake_word.py uses."""
    if LINK_PATH.exists() or LINK_PATH.is_symlink():
        return
    try:
        # On Windows use junction/copy; on Unix use symlink
        if sys.platform == "win32":
            import shutil
            if not LINK_PATH.exists():
                shutil.copytree(MODEL_PATH, LINK_PATH)
        else:
            LINK_PATH.symlink_to(MODEL_PATH)
        print(f"[VoskSetup] 🔗 Alias created: {LINK_PATH.name} → {MODEL_NAME}")
    except Exception as e:
        print(f"[VoskSetup] ⚠️  Could not create alias: {e}")
        print(f"  Manually rename {MODEL_NAME} → vosk-model-small-en in models/")


if __name__ == "__main__":
    print("=" * 50)
    print("  ZERO TWO — Vosk Offline Model Setup")
    print("=" * 50)
    ok = ensure_model()
    if ok:
        print("\n✅ Wake word detection is ready (offline mode).")
        print("   Restart ZERO TWO to activate vosk backend.")
    else:
        print("\n⚠️  Setup failed. Wake word will use SpeechRecognition (online) or energy fallback.")
    sys.exit(0 if ok else 1)
